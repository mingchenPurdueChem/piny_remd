void analysis_cp(CLASS *,BONDED *,GENERAL_DATA *,CP *,ANALYSIS *);

void analysis_cp_pimd(CLASS *,BONDED *,GENERAL_DATA *,CP *,ANALYSIS *);

