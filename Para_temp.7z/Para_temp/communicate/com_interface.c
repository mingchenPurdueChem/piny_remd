/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: comm_interface.c                             */
/*                                                                          */
/* Subprogram contains MPI utils and communication routines for interface   */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_par.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_cp.h"
#include "../proto_defs/proto_communicate_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_communicate_local.h"

#define DEBUG_ME_OFF

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void communicate_interface(CLASS *class,BONDED *bonded,CP *cp,
                GENERAL_DATA *general_data,NULL_INTER_PARSE *null_inter_parse,
                CLASS_PARSE *class_parse,CP_PARSE *cp_parse,
                FILENAME_PARSE *filename_parse)

/*=======================================================================*/
  {/*begin routine */
/*=======================================================================*/
/*             Local variable declarations                                */

#include "../typ_defs/typ_mask.h"

  int pimd_on,cp_on,natm_mall,natm_typ_mall;
  int npara_temps     = general_data->tempering_ctrl.npara_temps;
  int npara_temps_max = general_data->tempering_ctrl.npara_temps_proc_max;
  int myid            = class->communicate_m.myid;
  MPI_Comm world      = class->communicate_m.world;

/*=======================================================================*/
/*            Output                                                     */

  if(myid==0){
     PRINT_LINE_STAR;
     printf("Communicating the interface\n");
     PRINT_LINE_DASH;printf("\n");
  }/*endif*/

/*=======================================================================*/
/*            General_Data                                               */

/*	printf("about begin communicating \n");*/

  Barrier(world);
  communicate_general_data(general_data,cp,world,myid);
  Barrier(world);
  
  cp_on = general_data->simopts.cp_min+general_data->simopts.cp_wave_min
        +general_data->simopts.cp+general_data->simopts.cp_wave
        +general_data->simopts.debug_cp+general_data->simopts.cp_pimd
        +general_data->simopts.debug_cp_pimd+general_data->simopts.cp_wave_pimd
        +general_data->simopts.cp_wave_min_pimd;

  pimd_on = general_data->simopts.pimd + general_data->simopts.cp_pimd 
          + general_data->simopts.cp_wave_pimd 
          + general_data->simopts.cp_wave_min_pimd 
          + general_data->simopts.debug_pimd 
          + general_data->simopts.debug_cp_pimd;

	printf("general data communicated \n");

/*=======================================================================*/
/*           Class                                                     */

   Barrier(world);
   communicate_class_info(class,general_data,class_parse);
   Barrier(world);
#ifdef DEBUG_ME
  printf("Com interface : step 2 %d\n",myid);fflush(stdout);
#endif

   if(myid!=0){
     mall_class(class,general_data,class_parse,pimd_on);    
   }/*endif*/
#ifdef DEBUG_ME
  printf("Com interface : step 2.25 %d\n",myid);fflush(stdout);
#endif

   Barrier(world);
   communicate_class_data(class,general_data,class_parse,pimd_on);
   Barrier(world);
#ifdef DEBUG_ME
  printf("Com interface : step 2.5 %d\n",myid);fflush(stdout);
#endif

   Barrier(world);
   communicate_class_list(class,general_data,class_parse,pimd_on);
   Barrier(world);
#ifdef DEBUG_ME
  printf("Com interface : step 3 %d\n",myid);fflush(stdout);
#endif


/*=======================================================================*/
/*            Bonded                                                     */

   Barrier(world);
   communicate_bonded_info(bonded,null_inter_parse,world,npara_temps,
                           npara_temps_max,myid); 
   Barrier(world);
#ifdef DEBUG_ME
  printf("Com interface : step 4 %d\n",myid);fflush(stdout);
#endif

   if(myid!=0){
       mall_bond(bonded,null_inter_parse,npara_temps_max,myid); 
   }/*endif*/
#ifdef DEBUG_ME
  printf("Com interface : step 4.5 %d\n",myid);fflush(stdout);
#endif

   Barrier(world);
   communicate_bonded_data(bonded,null_inter_parse,world); 
   Barrier(world);
#ifdef DEBUG_ME
  printf("Com interface : step 5 %d\n",myid);fflush(stdout);
#endif

/*=======================================================================*/
/*            CP                                                         */

   Barrier(world);
   communicate_cp_info(cp,cp_parse,world,myid); 
   Barrier(world);
#ifdef DEBUG_ME
  printf("Com interface : step 6 %d\n",myid);fflush(stdout);
#endif

   if(cp_on==1){
     natm_mall     = class->clatoms_info.natm_mall;
     natm_typ_mall = class->atommaps.natm_typ_mall;
     Barrier(world);
     communicate_cp_data(cp,natm_mall,natm_typ_mall,world,myid);
     Barrier(world);
   }/*endif cp_on==1*/
#ifdef DEBUG_ME
  printf("Com interface : step 7 %d\n",myid);fflush(stdout);
#endif

/*=======================================================================*/
/* Filename parse : too lazy to make a routine                           */

   Barrier(world);
    if(myid!=0){
      filename_parse->dnamei  = (char *)cmalloc(MAXWORD*sizeof(char));
      filename_parse->dnameci = (char *)cmalloc(MAXWORD*sizeof(char));
    }/*endif*/
    Bcast(&(filename_parse->dnamei[0]),MAXWORD,MPI_CHAR,0,world);
    Bcast(&(filename_parse->dnameci[0]),MAXWORD,MPI_CHAR,0,world);
    Bcast(&(filename_parse->def_vps_name),MAXWORD,MPI_CHAR,0,world);
    Bcast(&(filename_parse->user_vps_name),MAXWORD,MPI_CHAR,0,world);
   Barrier(world);
#ifdef DEBUG_ME
   printf("Comm interface step 8 %d\n",myid);fflush(stdout);
#endif

/*=======================================================================*/
/*         More Output                                                   */

   if(myid==0){
      printf("\n");PRINT_LINE_DASH;
      printf("Completed communicating the interface\n");
      PRINT_LINE_STAR;printf("\n");fflush(stdout);
   }/*endif*/

/*------------------------------------------------------------------------*/
} /*end routine*/ 
/*==========================================================================*/











