/*--------------------------------------------------------------------------*/
/* test_energy_cp.c */

void test_force_cp(CLASS *, BONDED *, GENERAL_DATA *,CP *,int ,
                   double *, double *, double * ,int );

/*--------------------------------------------------------------------------*/
/* test_energy_cp_pimd.c */

void test_force_cp_pimd(CLASS *, BONDED *, GENERAL_DATA *,CP *,int ,
                         double *, double *, double * ,int );



