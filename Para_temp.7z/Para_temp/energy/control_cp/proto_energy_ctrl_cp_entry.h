/*--------------------------------------------------------------------------*/

void cp_energy_control(CLASS *, BONDED *, GENERAL_DATA *,CP *, int );

void test_energy_cp(CLASS *, BONDED *, GENERAL_DATA *,CP *, int );

/*--------------------------------------------------------------------------*/

void cp_energy_control_pimd(CLASS *, BONDED *, GENERAL_DATA *,CP *, int );

void test_energy_cp_pimd(CLASS *, BONDED *, GENERAL_DATA *,CP *, int );



