/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: switch_pt                                    */
/*                                                                          */
/* This subprogram performs the switching within the control_** structure   */
/*                                                                          */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/


#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typ_mask.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_vel_sampl_class_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_temper_entry.h"
#include "../proto_defs/proto_temper_md.h"
#include "../proto_defs/proto_temper_local.h"
#include "../proto_defs/proto_output_entry.h"

#define DEBUG_RAPH_PAR_OFF

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void md_switch_pt(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                int toggle,char *opt)
/*=======================================================================*/
  {/*begin routine*/
/*=======================================================================*/

  CP *cp;
  control_switch_pt(class, bonded,general_data, cp, toggle, opt);

/*=======================================================================*/
  }/*end routine*/
/*=======================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void cp_switch_pt(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                CP *cp,int toggle,char *opt)
/*=======================================================================*/
  {/*begin routine*/
/*=======================================================================*/

  control_switch_pt(class, bonded,general_data, cp, toggle, opt);

/*=======================================================================*/
  }/*end routine*/
/*=======================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void control_switch_pt(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                     CP *cp,int toggle,char *opt)
/*=======================================================================*/
  {/*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"

  int i,j,k,m,n,ip,ipp,ioff,iii;
  int ipt,jpt;
  int cp_opt,pimd,ifound,iflag_mass;
  int yaynay = 0;

  double prob,arg,xxx;
  double e_i,e_j,beta_i,beta_j;
  double expo,rand;
  double coastal,xx;
  double eharm_ii,eharm_jj,eharm_ij,eharm_ji;

/*=======================================================================*/

  STAT_AVG *stat_avg           = general_data->stat_avg;
  STATEPOINT *statepoint       = general_data->statepoint;
  CLATOMS_POS *clatoms_pos     = class->clatoms_pos;
  THERM_POS *therm_class       = class->therm_class;
  THERM_POS *therm_bead        = class->therm_bead;
  THERM_INFO *therm_info_class = class->therm_info_class;
  THERM_INFO *therm_info_bead  = class->therm_info_bead;
  CPCOEFFS_POS *cp_pos;           /* set below */
  CPTHERM_POS *cptherm_pos;       /* set below */
  COMMUNICATE *communicate_m   = &(class->communicate_m);
  COMMUNICATE *communicate     = &(class->communicate);

/*=======================================================================*/

  int iadd                     = 0;
  int mytoggle                 = toggle;

  int pi_beads                 = general_data->simopts.pi_beads;
  int rsmpl_opt                = general_data->tempering_ctrl.rsmpl_opt;
  int npara_temps              = general_data->simopts.npara_temps;
  int npara_temps_proc         = general_data->simopts.npara_temps_proc;
  int npara_temps_proc_off     = general_data->simopts.npara_temps_proc_off;
  int ioff_pt                  = general_data->simopts.npara_temps_proc_off;
  int ipt_st                   = ioff_pt+1;
  int ipt_end                  = ioff_pt+npara_temps_proc;

  int natm_tot                 = class->clatoms_info.natm_tot;
  int natm_mall                = class->clatoms_info.natm_mall;
  int pi_beads_proc            = class->clatoms_info.pi_beads_proc;
  int pi_beads_proc_st         = class->clatoms_info.pi_beads_proc_st;

  double *qseed                = &(class->vel_samp_class.qseed);
  double *rand_vec             = stat_avg[1].rand_vec;

  int myid                     = communicate->myid;
  int myid_forc                = communicate->myid_forc;
  int myid_state               = communicate->myid_state;
  int myid_bead                = communicate->myid_bead;

  int np                       = communicate_m->np;
  int myid_m                   = communicate_m->myid;
  int np_beads                 = communicate_m->np_beads;
  int np_temper                = communicate_m->np_temper;
  int myid_temper              = communicate_m->myid_temper;
  MPI_Comm  comm_temper        = communicate_m->comm_temper;

  int nswitch                  = (int) (general_data->tempering_ctrl.nswitch);

  int start_proc;
  start_proc                   = (pi_beads_proc_st == 1 ? 2:1);

  char sss[100];
  FILE *fp;

/*=======================================================================*/
/* Parallel Error and Warning */

  if(np!=1){

    if(myid_m==0){
      printf("$$$$$$$$$$$$$$$$$_warning_$$$$$$$$$$$$$$$$$$$$\n");
      printf("Internal warning : Multi-proc switching \n");
      printf("is under development. Proceed at your peril!\n");
      printf("$$$$$$$$$$$$$$$$$_warning_$$$$$$$$$$$$$$$$$$$$\n");
      fflush(stdout);
    }/*endif*/
    if(rsmpl_opt==0){
      if(myid_m==0){
        printf("Sorry : Not yet for PT without vel rsmpl.\n");
        printf("        The NHC communication needs love!\n");
        fflush(stdout);
      }/*endif*/
      Finalize();
      exit(1);
    }/*endif : death by resampling*/
#ifdef DEBUG_RAPH_PAR
    if(myid_m==0){
      fp = fopen("../RANDOM/rand.in","w");
      for(i=1;i<=15;i++){
        for(j=1;j<=15;j++){
          fprintf(fp,"%.5g ",ran_essl(qseed));
	}/*endfor*/
        fprintf(fp,"\n");
      }/*endfor*/
      fclose(fp);
    }/*endif*/
#endif
  }/*end : parallel errors and warnings*/

/*=======================================================================*/
/* Determine simulation type, set the options and dig out cp structures  */

  ifound=0; cp_opt=0; pimd = 0;
  if(strcasecmp(opt,"md")     ==0){ifound=1;                };
  if(strcasecmp(opt,"pimd")   ==0){ifound=1;         pimd=1;};
  if(strcasecmp(opt,"cp")     ==0){ifound=1;cp_opt=1;       };
  if(strcasecmp(opt,"cp_pimd")==0){ifound=1;cp_opt=1;pimd=1;};
  if(ifound!=1){
    printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
    printf("Internal error in switch controller. Call Raph!\n");
    printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
    fflush(stdout);
    exit(1);
  }/*end error*/

  if(cp_opt==1){
    cp_pos      = cp->cpcoeffs_pos;
    cptherm_pos = cp->cptherm_pos;
    if(myid_m==0){
      printf("Sorry : Not yet for PT-cp.\n");
      printf("        The Psi communication needs love!\n");
      fflush(stdout);
    }/*endif*/
    Finalize();
    exit(1);
  }/*endif*/

/*==========================================================================*/
/* Get random numbers and the switching loop variables                      */

#ifdef DEBUG_RAPH_PAR
     sprintf(sss,"../RANDOM/rand.in.%d",myid_m);
     fp = cfopen(sss,"r");
     for(i=1;i<=nswitch+1;i++){
       for(j=0;j<15;j++){
          fscanf(fp,"%lf",&xxx);
          if(j<=npara_temps+1){rand_vec[j]=xxx;}
	}/*endfor*/
        readtoendofline(fp);
      }/*endfor*/
      fclose(fp);
      printf("rand_full: %d ",myid_m);
      for(i=0;i<=npara_temps+1;i++){
        printf("%g ",rand_vec[i]);
      }/*endfor*/
      printf("\n");fflush(stdout);
#else
  for(i=0;i<=npara_temps+1;i++){
    rand_vec[i]=ran_essl(qseed);
  }/*endfor*/
#endif



  if(npara_temps_proc != npara_temps){
    /* 1-2 : 3-4 : 5-6 ...  */
    if(toggle==1){
      if((ipt_st%2)==1){
        mytoggle = 1; iadd=0;
        if((ipt_end%2)==1){iadd=1;}
      }else{
        mytoggle=0; iadd=0;
        if((ipt_end%2)==1){iadd=1;}
      }/*endif*/
    }/*endif*/
    /* 2-3 : 4-5 : 6-7 ... */
    if(toggle==2){
      if((ipt_st%2)==1){
        mytoggle = 0; iadd=0;
        if((ipt_end%2)==0){iadd=1;}
      }else{
        mytoggle=1; iadd=1;
        if((ipt_end%2)==1){iadd=0;}
      }/*endif*/
    }/*endif*/
  }/*endif : done with the switching logic*/

#ifdef DEBUG_RAPH_PAR
  printf("myid_m %d myid %d toggle %d mytog %d add %d st %d end %d\n",
          myid_m,myid,toggle,mytoggle,iadd,ipt_st,ipt_end);
  fflush(stdout);
#endif

/*==========================================================================*/
/* Communicate to your friends                                              */
#ifdef DEBUG_RAPH_PAR
  printf("rand: myid_m %d ipt_st %d ipt_nd %d rand[ist] %g rand_me[end+1] %g\n",
        myid_m,ipt_st,ipt_end,rand_vec[ipt_st],rand_vec[(ipt_end+1)]);
  fflush(stdout);
#endif
  if(np>1){
  switch_communicate_stat_avg(communicate_m,communicate,stat_avg,
                           npara_temps,npara_temps_proc,ipt_st,ipt_end);


  switch_communicate_atoms(natm_mall,pimd,npara_temps_proc,
                           pi_beads_proc,clatoms_pos, 
                           comm_temper,myid_temper,np_temper,
                           myid_m,myid_bead,myid_forc);
#ifdef DEBUG_RAPH_PAR
  k = 1 - pi_beads_proc;
  m = 1 + pi_beads_proc*(npara_temps_proc-1);
  n = 1 + pi_beads_proc*(npara_temps_proc);
  i = natm_tot;
  printf("atoms: myid_m=%d x[%d]=%g x[1]=%g x[%d]=%g x[%d]=%g\n",
          myid_m,k,
          clatoms_pos[k].x[1],clatoms_pos[1].x[1],m,clatoms_pos[m].x[1],n,
          clatoms_pos[n].x[1]);
  printf("origins: myid_m=%d o[%d]=%d o[1]=%d o[%d]=%d o[%d]=%d\n",
          myid_m,k,
          clatoms_pos[k].origin,clatoms_pos[1].origin,m,clatoms_pos[m].origin,n,
          clatoms_pos[n].origin);
  if(pimd==1){
    printf("pforcs: myid_m=%d x[%d]=%g x[1]=%g x[%d]=%g x[%d]=%g\n",
            myid_m,k,
            clatoms_pos[k].fxt[1],clatoms_pos[1].fxt[1],m,clatoms_pos[m].fxt[1],n,
            clatoms_pos[n].fxt[1]);
  }/*endif*/
  fflush(stdout);
#endif

#ifdef JUNK
  switch_communicate_state();
#endif
  }/*endif*/
/*==========================================================================*/
/* Lets take a look */

#ifdef DEBUG_RAPH_PAR
  if(npara_temps!=npara_temps_proc){  
    for(ipt=0;ipt<=npara_temps_proc+1;ipt++){
      e_i =   (stat_avg[ipt].vintert +
               stat_avg[ipt].vintrat);
      printf("ipt=%d e_i=%g kT=%g\n",ipt+ioff_pt,e_i,statepoint[ipt].t_ext);
    }/*endfor*/
  }else{
    for(ipt=1;ipt<=npara_temps;ipt++){
      e_i =   (stat_avg[ipt].vintert +
              stat_avg[ipt].vintrat);
      printf("ipt=%d e_i=%g kT=%g\n",ipt,e_i,statepoint[ipt].t_ext);
    }/*endfor*/
  }/*endif*/
#endif

/*==========================================================================*/
/* Switcheroony */

/* In multilevel parallel : only myid_state==0 or myid_forc==0 or myid_bead==0    */
/*                          have the juice to accept or reject.                   */
/*                          However, they still have to be involved in the        */
/*                          communication. So maybe it makes sense to give them   */
/*                          the juice rather than dealing with some communication */
/*                          to them to join the dance                             */
/*                          So lets update their stat_avg from myid_xxx=0         */

  for(i=0;i<=npara_temps_proc){move_accepted[i]=0;}
  for(ipt=mytoggle;ipt<npara_temps_proc+iadd;ipt+=2){
    jpt = ipt+1;
   /*-----------------------------------------------------------------------*/
   /* Determine the acceptance probablity                                   */
    e_i    = get_switch_energy(&(stat_avg[ipt]),opt,rsmpl_opt);
    e_j    = get_switch_energy(&(stat_avg[jpt]),opt,rsmpl_opt);
    beta_i = BOLTZ/(statepoint[ipt].t_ext);
    beta_j = BOLTZ/(statepoint[jpt].t_ext);
    arg    = (beta_i-beta_j)*(e_i-e_j);
    if(pimd==1){
      get_pimd_harm_energy(&stat_avg[ipt],beta_i,beta_j,&eharm_ii,&eharm_ij);
      get_pimd_harm_energy(&stat_avg[jpt],beta_j,beta_i,&eharm_jj,&eharm_ji);
      arg += ( beta_i*(eharm_ii - eharm_ji)
              -beta_j*(eharm_ij - eharm_jj) );
#ifdef DEBUG_RAPH_PAR
      printf("pimd testing : %.10g %.10g : %.10g %.10g\n",eharm_ij,eharm_ji,
                                                          eharm_ii,eharm_jj);
      if(np_beads==1){
      /* broken for np_beads>1 : how sad!! */
        pimd_harm_energy(class,general_data,ipt,beta_i,&eharm_ii);
        pimd_harm_energy(class,general_data,jpt,beta_j,&eharm_jj);
        eharm_ii = stat_avg[ipt].kin_harm;
        eharm_jj = stat_avg[jpt].kin_harm;
        printf("pimd testing : %.10g %.10g : %.10g %.10g\n",eharm_ij,eharm_ji,
                                                            eharm_ii,eharm_jj);
      }/*endif*/
#endif
    }/*endif*/
    expo = exp(arg);
    prob = expo/(1.0+expo); /* the frenkel way */
   /*-----------------------------------------------------------------------*/
   /* Draw a random number and switch if necesary                          */
#ifdef DEBUG_RAPH_PAR
    printf("switching: %d %d on proc %d using prob %.10g rand %.10g\n",
	   ipt+ioff_pt,jpt+ioff_pt,myid_m,prob,rand_vec[jpt+ioff_pt]);
#endif
    if(( ipt+ioff_pt != 0) && (jpt+ioff_pt != npara_temps +1) ){
      if(prob>rand_vec[jpt+ioff_pt]){
        move_accepted[ipt]=1;
#ifdef DEBUG_RAPH_PAR
        printf("accept:myid %d yay %d %d\n",myid_m,ipt+ioff_pt,jpt+ioff_pt);
#endif
	yaynay += 1;
        accept_switch_atoms(clatoms_pos,therm_class,therm_bead,
                            therm_info_class,
                            therm_info_bead,ipt,jpt,
                            opt,rsmpl_opt,pi_beads_proc,pi_beads_proc_st);
        stat_avg[ipt].nacc += 1.0;
        stat_avg[jpt].nacc += 1.0;
      }else{
        printf("accept:myid %d nay %d %d\n",myid_m,ipt+ioff_pt,jpt+ioff_pt);
      }/*endif*/
      stat_avg[ipt].ntest += 1.0;
      stat_avg[jpt].ntest += 1.0;
#ifdef DEBUG_RAPH_PAR
    }else{
      printf("accept:myid %d neither %d %d\n",myid_m,ipt+ioff_pt,jpt+ioff_pt);
#endif
    }/*endif : We have a permissible move */
  }/*end for actual switching loop*/
  (general_data->tempering_ctrl.nswitch) += 1.0; /* up-date no matter what */

/*==========================================================================*/
/* CP on-proc switches */

  if(cp_opt==1){

    for(ipt=mytoggle;ipt<npara_temps_proc+iadd;ipt+=2){
      jpt = ipt+1;
      if(move_accepted[ipt]=1){
        if(ipt >=1 && jpt >=1 && ipt <=npara_temps_proc && jpt <= npara_temps_proc){
          accept_switch_wave(cp_pos,cptherm_pos,ipt,jpt,opt,rsmpl_opt,pi_beads);
        }/*endif*/
      }/*endif*/
    }/*endfor*/
    /* make all up and down switches : copy out if move is accepted only */
    if(npara_temps_proc != npara_temps){
      comm_switch_wave(iadd,mytoggle,npara_temps_proc,npara_temps,move_accepted,cp);
    }/*endif*/

  }/*endif : cp_opt==on*/

/*==========================================================================*/
/* Coast to coast update and f(T) for optimizations*/

  /* count left end coastals */
  if(ipt_st==1){
    if(clatoms_pos[1].idirect==2) {stat_avg[1].coastal+=1.0;}
    clatoms_pos[1].idirect  = 1;
  }/*endif*/

  /*count right end coastals */
  if(ipt_end==npara_temps){
    ip=(npara_temps_proc-1)*pi_beads_proc+1;
    if(clatoms_pos[ip].idirect==1){stat_avg[npara_temps_proc].coastal+=1.0;}
    clatoms_pos[ip].idirect = 2;
  }/*endif */

  /* update the Troyer f(T) */
  for(ipt=1;ipt<=npara_temps_proc;ipt++){
    ip  = (ipt-1)*pi_beads_proc+1;
    iii = clatoms_pos[ip].idirect;
    printf("direct : ipt %d %g : idirect %d : %d\n",ipt+ioff_pt,
            general_data->tempering_ctrl.nswitch,clatoms_pos[ip].idirect,ipt_st);
    stat_avg[ipt].ndirect[iii] += 1.0;
  }/*endfor ipt*/

/*==========================================================================*/
/* resample velocities if so required */
#ifndef DEBUG_RAPH_PAR
   if(rsmpl_opt==1){
     if(myid_m==0){
      PRINT_LINE_STAR;
      printf("Sampling atomic and NHC velocities...");
     }/*endif*/
     for(ipt=1;ipt<=npara_temps_proc;ipt++){
      control_vx_smpl(class,bonded,&(general_data->ensopts),
                  &(general_data->simopts),general_data,
                  general_data->error_check_on,ipt,0);
      control_vnhc_smpl(class,general_data,ipt,0);
     }/*end_for*/
     if(myid_m==0){
      printf("done\n");
      PRINT_LINE_STAR;printf("\n");
     }/*endif*/
   }/*endif resample*/
#endif
/*==========================================================================*/
/* Reinitialize NHCs (ALWAYS) */

   for(ipt=1;ipt<=npara_temps_proc;ipt++){
    iflag_mass = 1;
    ioff = (ipt-1)*pi_beads_proc+1;
    if(pi_beads_proc_st==1){
      init_NHC_par(&(class->clatoms_info),&(class->clatoms_pos[ioff]),
           &(class->therm_info_class[ipt]),&(class->therm_class[ipt]),
           &(class->int_scr),iflag_mass,&(class->class_comm_forc_pkg));
    }/*endif*/
    iflag_mass = 2;
    for(ipp=start_proc;ipp<=pi_beads_proc;ipp++){
     ip = (ipt-1)*pi_beads_proc + ipp;
     init_NHC_par(&(class->clatoms_info),&(class->clatoms_pos[ip]),
               &(class->therm_info_bead[ipt]),&(class->therm_bead[ip]),
               &(class->int_scr),iflag_mass,&(class->class_comm_forc_pkg));
    }/*endfor*/
   }/*endor */

/*==========================================================================*/
/* Output to the screen */

  for(ipt=1;ipt<=npara_temps_proc;ipt++){
   jpt = ipt+ioff_pt;
   if(myid==0){
     fp = cfopen(general_data->tempering_screen_out[ipt].fname,"a");
     fprintf(fp,"\n"); 
     fprintf(fp,"============================================================\n");
     fprintf(fp,"Switch Step : %g\n",general_data->tempering_ctrl.nswitch);
     fprintf(fp,"   Switching %s temperers now:\n",((toggle==1)? ("odd") : ("even") ));
     if(jpt==1){
       coastal = stat_avg[1].coastal;
       fprintf(fp,"   Total number of coastal transits arriving left: %g\n",coastal);
       if(coastal>0){
        fprintf(fp,"   Switches per left coastal transit : %g\n",
                general_data->tempering_ctrl.nswitch/coastal);
       }/*endif*/
     }/*endif*/
     if(jpt==npara_temps){
       coastal = stat_avg[npara_temps_proc].coastal;
       fprintf(fp,"   Total number of coastal transits arriving right: %g\n",coastal);
       if(coastal>0){
        fprintf(fp,"   Switches per right coastal transit : %g\n",
                general_data->tempering_ctrl.nswitch/coastal);
       }/*endif*/
     }/*endif*/
     xx = (100.0*stat_avg[ipt].nacc)/(MAX(stat_avg[ipt].ntest,1.0));
     fprintf(fp,"     Switch accept ratio walker %d : %g\n",jpt,xx);
     fprintf(fp,"Completed Switch Step : %g\n",general_data->tempering_ctrl.nswitch);
     if(np != np_temper){
       fprintf(fp,"This is a slight lie in parallel - I'm proc %d, and I made %d switches\n",
	       myid_m,yaynay);
     }/*endif*/
     fprintf(fp,"============================================================\n");
     fprintf(fp,"\n");
     fflush(fp);
     fclose(fp);   
   }/*endif*/
  }/*endfor : ipt*/

/*==========================================================================*/

   travel_histo(clatoms_pos,stat_avg,&(general_data->tempering_ctrl),
                pi_beads,pi_beads_proc,myid_m,np_temper,comm_temper);

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void accept_switch_atoms(CLATOMS_POS *clatoms_pos, THERM_POS *therm_class,
                      THERM_POS *therm_bead,
                      THERM_INFO *therm_info_class,
                      THERM_INFO *therm_info_bead,
                      int ippt,int jppt,char *opt,int rsmpl,
                      int pi_beads_proc,int pi_beads_proc_st)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
#include "../typ_defs/typ_mask.h"

     int iii,ip,ifound,cp=0,pimd=0;
     int ipt,jpt;    
     int start_proc;

     double *clatoms_temp,**nhc_temp;

     start_proc = (pi_beads_proc_st == 1 ? 2:1);

/*-----------------------------------------------------------------------*/

     ifound=0;
     if(strcasecmp(opt,"md")     ==0){             ifound=1;};
     if(strcasecmp(opt,"pimd")   ==0){pimd=1;      ifound=1;};
     if(strcasecmp(opt,"cp")     ==0){cp=1;        ifound=1;};
     if(strcasecmp(opt,"cp_pimd")==0){cp=1;pimd=1; ifound=1;};
     if(ifound!=1){
       printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
       printf("internal error in switch energy. call Raph.!\n");
       printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
       fflush(stdout);
       exit(1);
     }/*end error*/

/*-----------------------------------------------------------------------*/

     for(ip=1;ip<=pi_beads_proc;ip++){
       ipt = ip+(ippt-1)*pi_beads_proc;
       jpt = ip+(jppt-1)*pi_beads_proc;
       
       /* take the WHOLE chunk of memory */
       switch_point_dble(clatoms_pos[ipt].x,clatoms_pos[jpt].x);
       switch_point_dble(clatoms_pos[ipt].y,clatoms_pos[jpt].y);
       switch_point_dble(clatoms_pos[ipt].z,clatoms_pos[jpt].z);
       switch_point_dble(clatoms_pos[ipt].fx,clatoms_pos[jpt].fx);
       switch_point_dble(clatoms_pos[ipt].fy,clatoms_pos[jpt].fy);
       switch_point_dble(clatoms_pos[ipt].fz,clatoms_pos[jpt].fz);
       switch_point_dble(clatoms_pos[ipt].vx,clatoms_pos[jpt].vx);
       switch_point_dble(clatoms_pos[ipt].vy,clatoms_pos[jpt].vy);
       switch_point_dble(clatoms_pos[ipt].vz,clatoms_pos[jpt].vz);

       switch_val_int(&(clatoms_pos[ipt].origin),&(clatoms_pos[jpt].origin));
       switch_val_int(&(clatoms_pos[ipt].idirect),&(clatoms_pos[jpt].idirect));

       if(pimd==1){
        switch_point_dble(clatoms_pos[ipt].fxt,clatoms_pos[jpt].fxt);
        switch_point_dble(clatoms_pos[ipt].fyt,clatoms_pos[jpt].fyt);
        switch_point_dble(clatoms_pos[ipt].fzt,clatoms_pos[jpt].fzt);
        switch_point_dble(clatoms_pos[ipt].fxm,clatoms_pos[jpt].fxm);
        switch_point_dble(clatoms_pos[ipt].fym,clatoms_pos[jpt].fym);
        switch_point_dble(clatoms_pos[ipt].fzm,clatoms_pos[jpt].fzm);
        switch_point_dble(clatoms_pos[ipt].xmod,clatoms_pos[jpt].xmod);
        switch_point_dble(clatoms_pos[ipt].ymod,clatoms_pos[jpt].ymod);
        switch_point_dble(clatoms_pos[ipt].zmod,clatoms_pos[jpt].zmod);
       }/*endif*/

       if( rsmpl==0 ){
        /*need index loop to rescale by ratio sqrt(qi/qj)*/
        if(ip==1 && start_proc==1){
          switch_val_dbledble_scale(therm_class[ippt].v_nhc,
                                 therm_class[jppt].v_nhc,
                                 therm_info_class[ippt].num_nhc,
                                 therm_info_class[jppt].num_nhc,
                                 therm_info_class[ippt].len_nhc,
                                 therm_info_class[jppt].len_nhc,
                                 therm_info_class[ippt].mass_nhc,
                                 therm_info_class[jppt].mass_nhc);
        }else{
          switch_val_dbledble_scale(therm_bead[ipt].v_nhc,
                                 therm_bead[jpt].v_nhc,
                                 therm_info_bead[ipt].num_nhc,
                                 therm_info_bead[jpt].num_nhc,
                                 therm_info_bead[ipt].len_nhc,
                                 therm_info_bead[jpt].len_nhc,
                                 therm_info_bead[ipt].mass_nhc,
                                 therm_info_bead[jpt].mass_nhc);
        }/*endif*/
       }/*endif : noresmpl*/

     }/*endfor all the shiny beads*/

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void accept_switch_wave(CPCOEFFS_POS *cp_pos,CPTHERM_POS *therm_pos,
                      int ippt,int jppt,char *opt,int rsmpl,int pi_beads)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
#include "../typ_defs/typ_mask.h"

     int iii,ip,pimd=0;
     int ipt,jpt;    
     double *vtemp;
     double temp;

     if(strcasecmp(opt,"cp_pimd")==0){pimd=1;}
/*-----------------------------------------------------------------------*/

     for(ip=1;ip<=pi_beads;ip++){
       ipt = ip+(ippt-1)*pi_beads;
       jpt = ip+(jppt-1)*pi_beads;
       
       switch_point_dble(cp_pos[ipt].cre_up,   cp_pos[jpt].cre_up);
       switch_point_dble(cp_pos[ipt].cim_up,   cp_pos[jpt].cim_up);
       switch_point_dble(cp_pos[ipt].cre_dn,   cp_pos[jpt].cre_dn);
       switch_point_dble(cp_pos[ipt].cim_dn,   cp_pos[jpt].cim_dn);
        
       switch_point_dble(cp_pos[ipt].vcre_up,  cp_pos[jpt].vcre_up);
       switch_point_dble(cp_pos[ipt].vcim_up,  cp_pos[jpt].vcim_up);
       switch_point_dble(cp_pos[ipt].vcre_dn,  cp_pos[jpt].vcre_dn);
       switch_point_dble(cp_pos[ipt].vcim_dn,  cp_pos[jpt].vcim_dn);
        
       switch_point_dble(cp_pos[ipt].fcre_up,  cp_pos[jpt].fcre_up);
       switch_point_dble(cp_pos[ipt].fcim_up,  cp_pos[jpt].fcim_up);
       switch_point_dble(cp_pos[ipt].fcre_dn,  cp_pos[jpt].fcre_dn);
       switch_point_dble(cp_pos[ipt].fcim_dn,  cp_pos[jpt].fcim_dn);
        
       switch_point_dble(cp_pos[ipt].ksmat_up, cp_pos[jpt].ksmat_up);
       switch_point_dble(cp_pos[ipt].ksmat_dn, cp_pos[jpt].ksmat_dn);
       switch_point_dble(cp_pos[ipt].ksmat_eig_up,cp_pos[jpt].ksmat_eig_up);
       switch_point_dble(cp_pos[ipt].ksmat_eig_dn,cp_pos[jpt].ksmat_eig_dn);
        
       switch_point_dble(cp_pos[ipt].norbmat_up,cp_pos[jpt].norbmat_up);
       switch_point_dble(cp_pos[ipt].norbmat_dn,cp_pos[jpt].norbmat_dn);
       switch_point_dble(cp_pos[ipt].norbmati_up,cp_pos[jpt].norbmati_up);
       switch_point_dble(cp_pos[ipt].norbmati_dn,cp_pos[jpt].norbmati_dn);
        
       switch_point_dble(cp_pos[ipt].ovmat_eigv_up,cp_pos[jpt].ovmat_eigv_up);
       switch_point_dble(cp_pos[ipt].ovmat_eigv_dn,cp_pos[jpt].ovmat_eigv_dn);

       switch_val_dble(&(cp_pos[ipt].max_diag),&(cp_pos[jpt].max_diag));
       switch_val_dble(&(cp_pos[ipt].max_off_diag),&(cp_pos[jpt].max_off_diag));
       switch_val_dble(&(cp_pos[ipt].ks_offset),&(cp_pos[jpt].ks_offset));
/*-----------------------------------------------------------------------*/

       switch_val_dble(&(therm_pos[ipt].c_nhc_massiv),
                       &(therm_pos[jpt].c_nhc_massiv));
       switch_point_dbledble(therm_pos[ipt].c_nhc,therm_pos[jpt].c_nhc);
       switch_point_dbledble(therm_pos[ipt].vc_nhc,therm_pos[jpt].vc_nhc);
       switch_point_dbledble(therm_pos[ipt].fc_nhc,therm_pos[jpt].fc_nhc);
     }/*endfor beadloop*/                  

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
double get_switch_energy(STAT_AVG *stat_avg,char *opt,int rsmpl)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/

     int ifound;
     int cp=0,pimd=0;
     double e_i;

/*-----------------------------------------------------------------------*/
     ifound=0;
     if(strcasecmp(opt,"md")     ==0){             ifound=1;};
     if(strcasecmp(opt,"pimd")   ==0){pimd=1;      ifound=1;};
     if(strcasecmp(opt,"cp")     ==0){cp=1;        ifound=1;};
     if(strcasecmp(opt,"cp_pimd")==0){cp=1;pimd=1; ifound=1;};
     if(ifound!=1){
       printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
       printf("internal error in switch energy. call Raph.!\n");
       printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@\n");
       fflush(stdout);
       exit(1);
     }/*end error*/
/*-----------------------------------------------------------------------*/
     e_i =   (stat_avg->vintert + stat_avg->vintrat);
     if(cp==1){
        e_i +=( stat_avg->cp_ehart
             + stat_avg->cp_eext 
             + stat_avg->cp_exc  
             + stat_avg->cp_eke 
             + stat_avg->cp_enl);
     }/*endif cp*/
/*-----------------------------------------------------------------------*/
     if(rsmpl==0){
       e_i+=(stat_avg->kinet + stat_avg->kinet_nhc);
       if(pimd==1){
        e_i += stat_avg->kinet_nhc_bead;
       }/*endif pimd*/
       if(cp==1){
        e_i +=( stat_avg->kinet_cp
              + stat_avg->kinet_nhc_cp);
       }/*endif cp*/
     }/*end rsmpl opt */

/*-----------------------------------------------------------------------*/
     return e_i;
/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*==========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void travel_histo(CLATOMS_POS *clatoms_pos, STAT_AVG *stat_avg,
                  TEMPERING_CTRL *tempering_ctrl,
                  int pi_beads, int pi_beads_proc,int myid_m, int np, 
                  MPI_Comm comm)

/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
#include "../typ_defs/typ_mask.h"

     int npara_temps      = tempering_ctrl->npara_temps;
     int npara_temps_proc = tempering_ctrl->npara_temps_proc;
     int ioff_para        = tempering_ctrl->npara_temps_proc_off;
     int history_frq      = tempering_ctrl->history_frq;
     int nswitch          = (int)(tempering_ctrl->nswitch);

     int *origin          = tempering_ctrl->origin;
     int *origin_tmp      = tempering_ctrl->origin_temp;
     int *index           = tempering_ctrl->index;

     double *kT           = tempering_ctrl->t_ext;
     double *ndirect1     = tempering_ctrl->ndirect1;
     double *ndirect2     = tempering_ctrl->ndirect2;
     double *ndirect1_tmp = tempering_ctrl->ndirect1_tmp;
     double *ndirect2_tmp = tempering_ctrl->ndirect2_tmp;

     int i,ip;
     int nsend,nrecv;
     double fun;
     FILE *fp;

/*========================================================================*/

  for(i=1;i<=npara_temps_proc;i++){
     ip = (i-1)*pi_beads_proc+1;
     origin[i] = clatoms_pos[ip].origin;
     ndirect1[i] = stat_avg[i].ndirect[1];
     ndirect2[i] = stat_avg[i].ndirect[2];
  }/*endif*/

  if(np>1){
    Barrier(comm);
      for(i=1;i<=npara_temps_proc;i++){origin_tmp[i]   = origin[i];}
      for(i=1;i<=npara_temps_proc;i++){ndirect1_tmp[i] = ndirect1[i];}
      for(i=1;i<=npara_temps_proc;i++){ndirect2_tmp[i] = ndirect2[i];}
      nsend = npara_temps_proc;   nrecv = npara_temps_proc;
      Allgather(&origin_tmp[1],  nsend,MPI_INT,   &origin[1],  nrecv,
                MPI_INT,0,comm);
      Allgather(&ndirect1_tmp[1],nsend,MPI_DOUBLE,&ndirect1[1],nrecv,
                MPI_DOUBLE,0,comm);
      Allgather(&ndirect2_tmp[1],nsend,MPI_DOUBLE,&ndirect2[1],nrecv,
                MPI_DOUBLE,0,comm);
    Barrier(comm);
  }/*endif*/

#ifdef DEBUG_RAPH_PAR
    for(i=1;i<=npara_temps;i++){
      printf("toyer: %d : %d %d %g %g\n",myid_m,i,origin[i],ndirect1[i],ndirect2[i]);
    }/*endfor*/
#endif
/*========================================================================*/

  for(i=1;i<=npara_temps;i++){
    index[i]  = i;
    origin_tmp[i] = origin[i];
  }/*endif*/

  if(npara_temps>1){sort_commence(npara_temps, origin, index);}

  if( (nswitch%history_frq==0) && (myid_m==0) ){
     fp = cfopen(tempering_ctrl->history_name,"a");
       for(i=1;i<=npara_temps;i++){
         fprintf(fp,"%d ",index[i]);
       }/*endfor*/
       fprintf(fp,"  |  ");
       for(i=1;i<=npara_temps;i++){
         fprintf(fp,"%3d ",origin_tmp[i]);
       }/*endfor*/
       fprintf(fp,"\n");
     fflush(fp);
     fclose(fp);
  }/*end print*/

/*-----------------------------------------------------------------------*/
/* troyer f(T) file printing. */

  if(nswitch%history_frq==0){
    if(myid_m==0){
       fp = cfopen(tempering_ctrl->troyer_name,"o");
         for(i=1;i<=npara_temps;i++){
           fun = ndirect1[i]/MAX(1.0,ndirect1[i]+ndirect2[i]);
          fprintf(fp,"%g %g %g %g\n",kT[i],fun,ndirect1[i],ndirect2[i]);
         }/*endfor*/
       fflush(fp);
       fclose(fp);
    }/*endif*/
  }/*endif*/

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void compute_wgt_frenkel(CLASS *class, GENERAL_DATA *general_data,char *opt)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
#include "../typ_defs/typ_mask.h"

   int npara_temps        = general_data->tempering_ctrl.npara_temps;
   int npara_temps_proc   = general_data->tempering_ctrl.npara_temps_proc;
   double **wgt_f         = general_data->tempering_ctrl.wgt_f;
   double *t_ext          = general_data->tempering_ctrl.t_ext_m;
   STAT_AVG *stat_avg     = general_data->stat_avg;
   STAT_AVG *stat_avg_tmp = general_data->stat_avg_tmp;

   int    nsend_dbl       = stat_avg[1].nsend_dbl;
   double *data           = stat_avg[1].data_us;
   double *data_tmp       = stat_avg[1].data_ds;
   int np                 = class->communicate_m.np_temper;
   int myid_m             = class->communicate_m.myid;
   MPI_Comm  comm         = class->communicate_m.comm_temper;

   int nsend, nrecv;
   int ipt,jpt,i,j;
   int pimd;
   double psum;
   double e_i,e_j,beta_i,beta_j,expo,prob,arg;
   double eharm_ii,eharm_jj;
   double eharm_ij,eharm_ji;
   double rpara_temps;

/*============================================================================*/
/* Allgather the stat_avg variables : Only proc myid_m==0 needs to be correct */

   if(np>1){
     j = 1;
     for(i=1;i<=npara_temps_proc;i++){
       stat_avg_pack(data_tmp,stat_avg,j,i);
       j+=nsend_dbl;
     }/*endfor*/
     nsend = nsend_dbl*npara_temps_proc;
     nrecv = nsend_dbl*npara_temps_proc;
     Barrier(comm);
     Allgather(&data_tmp[1],nsend,MPI_DOUBLE,&data[1],nrecv,
               MPI_DOUBLE,0,comm);
     Barrier(comm);
     j = 1;
     for(i=1;i<=npara_temps;i++){
       stat_avg_unpack(data,stat_avg_tmp,j,i);
       j+=nsend_dbl;
     }/*endfor*/
     stat_avg = stat_avg_tmp;
   }/*endif*/

/*========================================================================*/
/* Compute the Frenkel weights */

  pimd = 0;
  if(strcasecmp(opt,"pimd")   ==0){pimd=1;};
  if(strcasecmp(opt,"cp_pimd")==0){pimd=1;};

  rpara_temps = 1.0/((double)(npara_temps-1));
  for(ipt=1;ipt<=npara_temps;ipt++){
    psum=0.0;
    for(jpt=1;jpt<=npara_temps;jpt++){
      e_i    = get_switch_energy(&(stat_avg[ipt]),opt,1);
      e_j    = get_switch_energy(&(stat_avg[jpt]),opt,1);
      beta_i = BOLTZ/t_ext[ipt];
      beta_j = BOLTZ/t_ext[jpt];
      arg    = (beta_i-beta_j)*(e_i-e_j);
      if(pimd==1){
        get_pimd_harm_energy(&stat_avg[ipt],beta_i,beta_j,&eharm_ii,&eharm_ij);
        get_pimd_harm_energy(&stat_avg[jpt],beta_j,beta_i,&eharm_jj,&eharm_ji);
        arg += ( beta_i*(eharm_ii - eharm_ji)
                -beta_j*(eharm_ij - eharm_jj) );
      }/*endif*/
      expo = exp(arg);
      wgt_f[ipt][jpt] = rpara_temps*expo/(1.0+expo); /* the frenkel way */
      if(ipt!=jpt){psum+=rpara_temps/(1.0+expo);}
    }/*enfor jpt*/
    wgt_f[ipt][ipt] = psum;
  }/*endfor ipt*/

  write_frenkel_wgt(class,general_data,"md");

/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
 void switch_point_dble(double *b,double *a)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
     double *c;
/*-----------------------------------------------------------------------*/
     c=b;
     b=a;
     a=c;
/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
 void switch_point_dbledble(double **b,double **a)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
     double **c;
/*-----------------------------------------------------------------------*/
     c=b;
     b=a;
     a=c;
/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
 void switch_val_dbledble_scale(double **v_i,double **v_j,int num_i,
                            int num_j,int len_i,int len_j,
                            double **mass_i,double **mass_j)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
     int m,k;
     double c,rat_ij;
/*-----------------------------------------------------------------------*/
/* for the NHC switching, even though there are no nhc's in the name*/
     if((num_i!=num_j) || (len_i != len_j)){
       printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
       printf("internal error in switch NHC scale. don't call Raph.!\n");
       printf("@@@@@@@@@@@@@@@@@_error_@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
       fflush(stdout);
       exit(1);
     }/*end error*/

     for(k=1;k<=num_i;k++){
       for(m=1;m<=len_i;m++){
        c=v_i[m][k];
        rat_ij=sqrt(mass_i[m][k]/mass_j[m][k]);
        v_i[m][k]=v_j[m][k]/rat_ij;
        v_j[m][k]=c*rat_ij;
       }/*endfor m*/
     }/*endfor k*/
/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
 void switch_point_int(int *b,int *a)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
     int *c;
/*-----------------------------------------------------------------------*/
     c=b;
     b=a;
     a=c;
/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
 void switch_point_intint(int **b,int **a)
/*========================================================================*/
   { /*begin Routine */
/*-----------------------------------------------------------------------*/
     int **c;
/*-----------------------------------------------------------------------*/
     c=b;
     b=a;
     a=c;
/*-----------------------------------------------------------------------*/
  }/*end routine*/
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
 void switch_val_int(int *b,int *a){
   int c;
   c    = b[0];
   b[0] = a[0];
   a[0] = c;
 }
/*========================================================================*/


/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/
void switch_val_dble(double *b,double *a){
   double c;
   c    = b[0];
   b[0] = a[0];
   a[0] = c;
 }
/*========================================================================*/

/*========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*========================================================================*/

void get_pimd_harm_energy(STAT_AVG *stat_avg,double beta_i,double beta_j,
                          double *eharm_ii,double *eharm_ij){

   double rat  = (beta_i/beta_j);  
   eharm_ii[0] = (stat_avg->kin_harm);
   eharm_ij[0] = eharm_ii[0]*rat*rat; 
      /* (tau_i*beta_i)/(beta_j*tau_j)  = (beta_i/beta_j)^2 */
 }
/*========================================================================*/


