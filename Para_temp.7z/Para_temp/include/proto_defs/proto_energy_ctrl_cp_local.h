#include "../../energy/control_cp/proto_energy_ctrl_cp_local.h"
