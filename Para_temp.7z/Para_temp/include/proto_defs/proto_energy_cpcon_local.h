#include "../../energy/cp_con/proto_energy_cpcon_local.h"
