#include "../../interface/coords_cp/proto_coords_cp_local.h"
