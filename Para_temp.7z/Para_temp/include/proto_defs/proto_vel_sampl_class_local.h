#include "../../interface/vel_sampl_class/proto_vel_sampl_class_local.h"
