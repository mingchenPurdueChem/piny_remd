#include "../../energy/inter/real_space/proto_real_space_entry.h"
