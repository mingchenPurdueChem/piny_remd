#include "../../interface/vel_sampl_cp/proto_vel_sampl_cp_local.h"
