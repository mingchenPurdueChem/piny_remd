#include "../../energy/cp_con/proto_energy_cpcon_entry.h"
