#include "../../interface/cp_ewald/proto_cp_ewald_entry.h"
