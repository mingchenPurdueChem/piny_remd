#include "../../analysis/proto_analysis_local_entry.h"
