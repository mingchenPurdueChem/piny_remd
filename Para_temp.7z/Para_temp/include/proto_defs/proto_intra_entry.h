#include "../../energy/intra/proto_intra_entry.h"
