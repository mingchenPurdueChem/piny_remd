#ifndef PARALLEL
  int MPI_INT    = 1;
  int MPI_DOUBLE = 1;
  int MPI_CHAR = 1;
  int MPI_MAX = 1;
  int MPI_MIN = 1;
  int MPI_SUM = 1;
  int MPI_ANY_TAG = 1;
  int MPI_ANY_SOURCE = 1;
  int *MPI_BOTTOM = {0};
#endif  
