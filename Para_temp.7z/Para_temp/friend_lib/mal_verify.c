#include "standard_include.h"
#include "../proto_defs/proto_friend_lib_entry.h"

void mal_verify(int n){}

