 /*==========================================================================*/
 /*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
 /*==========================================================================*/
 /*                                                                          */
 /*                         PI_MD:                                           */
 /*             The future of simulation technology                          */
 /*             ------------------------------------                         */
 /*                   Routine :   zero_sys.c                                 */
 /*                                                                          */
 /* The routine to zero all the integer elements of structure class         */
 /*                                                                          */
 /*==========================================================================*/
 /*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
 /*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_par.h"
#include "../proto_defs/proto_parse_local.h"

  void zero_sys(CLASS *class,GENERAL_DATA *general_data, int hello)

{/*begin routine*/

/* some local variables  */
  int npara_temps   = general_data->simopts.npara_temps_proc_max;
  int ipt=1;
  int i,ii,j;


/* zero general_data->stat_avg  */
  for(ipt=1;ipt<=npara_temps;ipt++){
    general_data->stat_avg[ipt].vintert = 0;
    general_data->stat_avg[ipt].aivintert = 0;
    general_data->stat_avg[ipt].avintert = 0;
    general_data->stat_avg[ipt].vintrat = 0;
    general_data->stat_avg[ipt].aivintrat = 0;
    general_data->stat_avg[ipt].avintrat = 0;
    general_data->stat_avg[ipt].vbondt = 0;
    general_data->stat_avg[ipt].vbendt = 0;
    general_data->stat_avg[ipt].vtorst = 0;
    general_data->stat_avg[ipt].vonfot = 0;
    general_data->stat_avg[ipt].vbend_bndt = 0;
    general_data->stat_avg[ipt].vbend_bnd_bond = 0;
    general_data->stat_avg[ipt].vbend_bnd_bend = 0;
    general_data->stat_avg[ipt].vreal = 0;
    general_data->stat_avg[ipt].vrecip = 0;
    general_data->stat_avg[ipt].vvdw = 0;
    general_data->stat_avg[ipt].vcoul = 0;
    general_data->stat_avg[ipt].vlong = 0;
    general_data->stat_avg[ipt].vbond_free = 0;
    general_data->stat_avg[ipt].vbend_free = 0;
    general_data->stat_avg[ipt].vtors_free = 0;
    general_data->stat_avg[ipt].kinet = 0;
    general_data->stat_avg[ipt].aikinet = 0;
    general_data->stat_avg[ipt].akinet = 0;
    general_data->stat_avg[ipt].kinet_v = 0;
    general_data->stat_avg[ipt].aikinet_v = 0;
    general_data->stat_avg[ipt].akinet_v = 0;
    general_data->stat_avg[ipt].vol = 0;
    general_data->stat_avg[ipt].aivol = 0;
    general_data->stat_avg[ipt].avol = 0;
    general_data->stat_avg[ipt].kinet_nhc = 0;
    general_data->stat_avg[ipt].aikinet_nhc = 0;
    general_data->stat_avg[ipt].akinet_nhc = 0;
    general_data->stat_avg[ipt].kinet_nhc_bead = 0;
    general_data->stat_avg[ipt].aikinet_nhc_bead = 0;
    general_data->stat_avg[ipt].akinet_nhc_bead = 0;
    general_data->stat_avg[ipt].vpot_v = 0;
    general_data->stat_avg[ipt].vpotnhc = 0;
    general_data->stat_avg[ipt].aiter_shake = 0;
    general_data->stat_avg[ipt].aiter_ratl = 0;
    general_data->stat_avg[ipt].iter_23 = 0;
    general_data->stat_avg[ipt].iter_33 = 0;
    general_data->stat_avg[ipt].iter_46 = 0;
    general_data->stat_avg[ipt].iter_43 = 0;
    general_data->stat_avg[ipt].iter_21 = 0;
    general_data->stat_avg[ipt].aiter_23 = 0;
    general_data->stat_avg[ipt].aiter_33 = 0;
    general_data->stat_avg[ipt].aiter_46 = 0;
    general_data->stat_avg[ipt].aiter_21 = 0;
    general_data->stat_avg[ipt].aiter_43 = 0;
    general_data->stat_avg[ipt].iter_23r = 0;
    general_data->stat_avg[ipt].iter_33r = 0;
    general_data->stat_avg[ipt].iter_46r = 0;
    general_data->stat_avg[ipt].iter_43r = 0;
    general_data->stat_avg[ipt].iter_21r = 0;
    general_data->stat_avg[ipt].aiter_23r = 0;
    general_data->stat_avg[ipt].aiter_33r = 0;
    general_data->stat_avg[ipt].aiter_46r = 0;
    general_data->stat_avg[ipt].aiter_21r = 0;
    general_data->stat_avg[ipt].aiter_43r = 0;
    general_data->stat_avg[ipt].acella = 0;
    general_data->stat_avg[ipt].acellb = 0;
    general_data->stat_avg[ipt].acellc = 0;
    general_data->stat_avg[ipt].aicella = 0;
    general_data->stat_avg[ipt].aicellb = 0;
    general_data->stat_avg[ipt].aicellc = 0;
    general_data->stat_avg[ipt].acellab = 0;
    general_data->stat_avg[ipt].acellbc = 0;
    general_data->stat_avg[ipt].acellac = 0;
    general_data->stat_avg[ipt].aicellab = 0;
    general_data->stat_avg[ipt].aicellbc = 0;
    general_data->stat_avg[ipt].aicellac = 0;
    general_data->stat_avg[ipt].apress = 0;
    general_data->stat_avg[ipt].aipress = 0;
    general_data->stat_avg[ipt].press_inter = 0;
    general_data->stat_avg[ipt].press_intra = 0;
    general_data->stat_avg[ipt].apress_inter = 0;
    general_data->stat_avg[ipt].aipress_inter = 0;
    general_data->stat_avg[ipt].apress_intra = 0;
    general_data->stat_avg[ipt].aipress_intra = 0;
    general_data->stat_avg[ipt].press_kin = 0;
    general_data->stat_avg[ipt].apress_kin = 0;
    general_data->stat_avg[ipt].aipress_kin = 0;
    general_data->stat_avg[ipt].econv0 = 0;
    general_data->stat_avg[ipt].econv = 0;
    general_data->stat_avg[ipt].cpu1 = 0;
    general_data->stat_avg[ipt].cpu2 = 0;
    general_data->stat_avg[ipt].acpu = 0;
    general_data->stat_avg[ipt].cpu_now = 0;
    general_data->stat_avg[ipt].updates = 0;
    general_data->stat_avg[ipt].updates_w = 0;
    general_data->stat_avg[ipt].kinet_cp = 0;
    general_data->stat_avg[ipt].aikinet_cp = 0;
    general_data->stat_avg[ipt].akinet_cp = 0;
    general_data->stat_avg[ipt].kinet_nhc_cp = 0;
    general_data->stat_avg[ipt].aikinet_nhc_cp = 0;
    general_data->stat_avg[ipt].akinet_nhc_cp = 0;
    general_data->stat_avg[ipt].vpotnhc_cp = 0;
    general_data->stat_avg[ipt].cp_ehart = 0;
    general_data->stat_avg[ipt].aicp_ehart = 0;
    general_data->stat_avg[ipt].acp_ehart = 0;
    general_data->stat_avg[ipt].cp_eext = 0;
    general_data->stat_avg[ipt].aicp_eext = 0;
    general_data->stat_avg[ipt].acp_eext = 0;
    general_data->stat_avg[ipt].cp_exc = 0;
    general_data->stat_avg[ipt].cp_muxc = 0;
    general_data->stat_avg[ipt].aicp_exc = 0;
    general_data->stat_avg[ipt].acp_exc = 0;
    general_data->stat_avg[ipt].cp_eke = 0;
    general_data->stat_avg[ipt].aicp_eke = 0;
    general_data->stat_avg[ipt].acp_eke = 0;
    general_data->stat_avg[ipt].cp_enl = 0;
    general_data->stat_avg[ipt].aicp_enl = 0;
    general_data->stat_avg[ipt].acp_enl = 0;
    general_data->stat_avg[ipt].aiter_shake_cp = 0;
    general_data->stat_avg[ipt].aiter_ratl_cp = 0;
    general_data->stat_avg[ipt].maxfc = 0;
    general_data->stat_avg[ipt].maxf = 0;
    general_data->stat_avg[ipt].pi_ke_prim = 0;
    general_data->stat_avg[ipt].pi_ke_vir = 0;
    general_data->stat_avg[ipt].api_ke_prim = 0;
    general_data->stat_avg[ipt].api_ke_vir = 0;
    general_data->stat_avg[ipt].aipi_ke_prim = 0;
    general_data->stat_avg[ipt].aipi_ke_vir = 0;
    general_data->stat_avg[ipt].kin_harm = 0;
    general_data->stat_avg[ipt].akin_harm = 0;
    general_data->stat_avg[ipt].aikin_harm = 0;
    general_data->stat_avg[ipt].iter_shake = 0;
  }/* end for */

/* zero clatoms_info */
  class->clatoms_info.natm_tot           = 0;        
  class->clatoms_info.nfree              = 0;              
  class->clatoms_info.nchrg              = 0;              
  class->clatoms_info.natm_mall          = 0;    
  class->clatoms_info.nchrg_mall         = 0;


/* zero element to ghost_atoms.ghost_atoms_info  */
    class->ghost_atoms.nghost_tot    = 0;        
    class->ghost_atoms.natm_comp_max = 0;     
    class->ghost_atoms.nghost_mall   = 0;
    class->ghost_atoms.nghost_old    = 0;
    class->ghost_atoms.ncomp_mall    = 0;  
    class->ghost_atoms.ncomp_old     = 0;  


/* zero elements of atommaps.atommaps_info  */
    class->atommaps.nmol_typ      = 0;            
    class->atommaps.nres_typ      = 0;            
    class->atommaps.natm_typ      = 0;            
    class->atommaps.nfreeze       = 0;             
    class->atommaps.nfreeze_mall  = 0;
    class->atommaps.nres_max      = 0;    
    class->atommaps.nres_typ_max  = 0;
    class->atommaps.nres_tot      = 0;
    class->atommaps.nres_sum      = 0;
    class->atommaps.natm_typ_mall = 0;

    
/* zero nbr_list.nbr_list_info */
    for(ipt=1;ipt<=npara_temps;ipt++){
      class->nbr_list.verlist[ipt].iver_count       = 0;
      class->nbr_list.verlist[ipt].nver_lst         = 0;           
      class->nbr_list.verlist[ipt].nver_lst_res     = 0;       
      class->nbr_list.lnklist[ipt].ilnk_init        = 0;          
      class->nbr_list.lnklist[ipt].ncell_a          = 0;
      class->nbr_list.lnklist[ipt].ncell_b          = 0;
      class->nbr_list.lnklist[ipt].ncell_c          = 0;
      class->nbr_list.lnklist[ipt].lnk_list_dim     = 0;           
      class->nbr_list.lnklist[ipt].nshft_lnk        = 0;              
      class->nbr_list.lnklist[ipt].nshft_lnk_res    = 0;        
    }/* end for */  

/* zero interact.interact_info  */
    class->interact.nter_typ        = 0;   
    class->interact.ninter_mall     = 0;
    class->interact.nsplin_mall_tot = 0;
  
/* zero ewald.ewald_info  */
    general_data->ewald.nktot          = 0; 
    general_data->ewald.nktot_res      = 0; 
    general_data->ewald.nktot_mall     = 0;      
    general_data->ewald.nktot_res_mall = 0;  

/* zero part_mesh.part_mesh_info  */
    class->part_mesh.ngrid_a          = 0;
    class->part_mesh.ngrid_b          = 0;
    class->part_mesh.ngrid_c          = 0;
    class->part_mesh.ngrid_a_res      = 0;
    class->part_mesh.ngrid_b_res      = 0;
    class->part_mesh.ngrid_c_res      = 0;
    class->part_mesh.ninterp_mall     = 0;    
    class->part_mesh.ninterp_tot_mall = 0;   

}/*end routine*/










