/*---------------------------------------------------------------*/
/* Control_inter_params.c */

void control_inter_params(INTERACT *,SPLINE_PARSE *,
                          FILENAME_PARSE *,double ,int ,
                          int ,int ,NAME [],int [],
		          int ,int ,double *,int,int,MPI_Comm,int ,int);

void inter_coef(DICT_WORD *,char [],char [], DATA_BASE_ENTRIES *,
                     CATM_LAB *,int );

/*---------------------------------------------------------------*/













