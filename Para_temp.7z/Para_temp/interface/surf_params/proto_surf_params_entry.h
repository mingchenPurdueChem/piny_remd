
void control_surf_params(SURFACE *, FILENAME_PARSE *, int , 
                         NAME *, double *, int , MPI_Comm , int ); 

