/*-------------------------------------------------------------------------*/
/*       Velocity resampling routines                                      */

void sampl_vc(CPOPTS *,CPCOEFFS_INFO *,CPCOEFFS_POS *,
	      STATEPOINT *,int *,int *,double *,COMMUNICATE *,
              CP_COMM_STATE_PKG *,CP_COMM_STATE_PKG *,int);

void sampl_vcnhc(CPTHERM_INFO *,CPTHERM_POS *,CPSCR *,CPOPTS *,
		 int, int *,int *,double *,CPCOEFFS_INFO *,int ,int);








