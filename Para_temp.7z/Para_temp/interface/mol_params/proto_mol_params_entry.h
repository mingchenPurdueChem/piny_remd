void control_mol_params(CLASS *class,GENERAL_DATA *general_data,
                        BONDED *bonded,CP *cp,
			CLASS_PARSE *class_parse,CP_PARSE *cp_parse,
			FREE_PARSE *,FILENAME_PARSE *filename_parse);

