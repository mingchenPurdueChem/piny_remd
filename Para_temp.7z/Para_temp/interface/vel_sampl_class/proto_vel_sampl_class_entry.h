/*-------------------------------------------------------------------------*/
/*       Controls                                                          */

void control_vx_smpl(CLASS *,BONDED *,ENSOPTS *,SIMOPTS *,
                     GENERAL_DATA *,int,int,int );

void control_vnhc_smpl(CLASS *,GENERAL_DATA *,int,int );

void control_vx_scale(CLASS *,SIMOPTS *,double *,int );

void control_vnhc_scale(CLASS *,GENERAL_DATA *general_data,double,int );

void zero_com_vx(CLASS *);

/*-------------------------------------------------------------------------*/







