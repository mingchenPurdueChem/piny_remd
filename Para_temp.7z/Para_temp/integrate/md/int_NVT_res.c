/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: int_NVE_res                                  */
/*                                                                          */
/* This subprogram integrates the system using Vel Verlet RESPA             */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../proto_defs/proto_integrate_md_entry.h"
#include "../proto_defs/proto_integrate_md_local.h"
#include "../proto_defs/proto_intra_con_entry.h"
#include "../proto_defs/proto_energy_ctrl_entry.h"

void check_for_NaN(int,int,double*,double*,double*,char*,GENERAL_DATA*,CLASS*);

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void int_NVT_res(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/
/*             Local variable declarations                                */

  /*    int ipt=1;*/
    char stuff[1024];
    int i,ipart,iflag,ifirst=1;
    int exit_flag=0;
    double dt,dti2,dti,tol_glob,tmp,tmp2;
    int ir_tra,ir_tor,ir_ter;
    int ix_now;
    int nres_tra,nres_tor,nres_ter;
    int int_res_ter,iii;
    int natm_tot,ichain,inhc;
    int iflag_mass = 1;
    int anneal_opt = general_data->simopts.anneal_opt;
    double anneal_target_temp = general_data->simopts.ann_target_temp;
    double ann_rate = general_data->simopts.ann_rate;
    int     num_nhc = class->therm_info_class[ipt].num_nhc;
    int     len_nhc = class->therm_info_class[ipt].len_nhc;
    double **therm_v_nhc    = class->therm_class[ipt].v_nhc;
    double **therm_gkt      = class->therm_info_class[ipt].gkt;
    double **therm_mass_nhc = class->therm_info_class[ipt].mass_nhc;
    double *clatoms_xold = class->clatoms_pos[1].xold;
    double *clatoms_yold = class->clatoms_pos[1].yold;
    double *clatoms_zold = class->clatoms_pos[1].zold;
    double *clatoms_x    = class->clatoms_pos[1].x;
    double *clatoms_y    = class->clatoms_pos[1].y;
    double *clatoms_z    = class->clatoms_pos[1].z;
    double *clatoms_vx   = class->clatoms_pos[1].vx;
    double *clatoms_vy   = class->clatoms_pos[1].vy;
    double *clatoms_vz   = class->clatoms_pos[1].vz;
    double *clatoms_fx   = class->clatoms_pos[1].fx;
    double *clatoms_fy   = class->clatoms_pos[1].fy;
    double *clatoms_fz   = class->clatoms_pos[1].fz;
    double *clatoms_mass = class->clatoms_info.mass;
    int myatm_start      = class->clatoms_info.myatm_start;
    int myatm_end        = class->clatoms_info.myatm_end;
    int np_forc        = class->class_comm_forc_pkg.num_proc;
    MPI_Comm comm_forc = class->class_comm_forc_pkg.comm;
    int myid_m         = class->communicate_m.myid;
    int itime          = general_data->timeinfo.itime;

/*==========================================================================*/
/* 0) Useful constants                                                      */

    natm_tot = class->clatoms_info.natm_tot;
    int_res_ter = general_data->timeinfo.int_res_ter;
    nres_tra = (general_data->timeinfo.nres_tra);
    nres_tor = (general_data->timeinfo.nres_tor);
    nres_ter = (general_data->timeinfo.nres_ter);
    dt   = (general_data->timeinfo.dt);
    dti  = dt/((double)(nres_ter*nres_tor*nres_tra));
    dti2 = dti/2.0;
    if(general_data->timeinfo.ix_respa==1){
      class->therm_info_class[ipt].dt_nhc   = dt;
    /*endif*/}
    if(general_data->timeinfo.ix_respa==2){
      class->therm_info_class[ipt].dt_nhc  = dt/((double)(nres_ter));
    /*endif*/}
    if(general_data->timeinfo.ix_respa==3){
      class->therm_info_class[ipt].dt_nhc  = dt/((double)(nres_ter*nres_tor));
    /*endif*/}
    if(general_data->timeinfo.ix_respa==4){
      class->therm_info_class[ipt].dt_nhc  = dt/((double)(
                                         nres_ter*nres_tor*nres_tra));
    /*endif*/}
    class->therm_info_class[ipt].dti_nhc  = (class->therm_info_class[ipt].dt_nhc)/
                              ( (double)(class->therm_info_class[ipt].nres_nhc) );
    set_yosh(class->therm_info_class[ipt].nyosh_nhc,
             class->therm_info_class[ipt].dti_nhc,class->therm_info_class[ipt].wdti,
             class->therm_info_class[ipt].wdti2,class->therm_info_class[ipt].wdti4,
             class->therm_info_class[ipt].wdti8,
             class->therm_info_class[ipt].wdti16);

    zero_constrt_iters(&(general_data->stat_avg[ipt]));
    general_data->timeinfo.exit_flag = 0;

/*==========================================================================*/

/* #define _GLENN_ */
#ifdef _GLENN_
  tmp = 0.0;
  for(ipart=myatm_start;ipart<=(myatm_end);ipart++){
   tmp += clatoms_mass[ipart]*clatoms_vx[ipart]*clatoms_vx[ipart];
   tmp += clatoms_mass[ipart]*clatoms_vy[ipart]*clatoms_vy[ipart];
   tmp += clatoms_mass[ipart]*clatoms_vz[ipart]*clatoms_vz[ipart];
  }/*endfor*/
  printf("myid_m %d %d: Top_v %g\n",myid_m,itime,tmp);

  tmp = 0.0;
  for(ipart=myatm_start;ipart<=(myatm_end);ipart++){
   tmp += clatoms_fx[ipart]*clatoms_fx[ipart];
   tmp += clatoms_fy[ipart]*clatoms_fy[ipart];
   tmp += clatoms_fz[ipart]*clatoms_fz[ipart];
  }/*endfor*/
  printf("myid_m %d %d: Top_f %g\n",myid_m,itime,tmp);
#endif

/*==========================================================================*/
/* I) Loop over inter RESPA                                                 */

    for(ir_ter=1;ir_ter<=nres_ter;ir_ter++){

/*==========================================================================*/
/*==========================================================================*/
/* II) Loop over tors RESPA                                                 */

      for(ir_tor=1;ir_tor<=nres_tor;ir_tor++){

/*==========================================================================*/
/*==========================================================================*/
/* III) Loop over intra RESPA                                               */

        for(ir_tra=1;ir_tra<=nres_tra;ir_tra++){
           general_data->timeinfo.ir_ter = ir_ter;
           general_data->timeinfo.ir_tor = ir_tor;
           general_data->timeinfo.ir_tra = ir_tra;
/*==========================================================================*/
/* 1) Evolve system from t=0 to dt/2                                        */
   /*-----------------------------------------------------------------------*/
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   "positions.nvt_res_b4_int",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   "velocities.nvt_res_b4_int",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   "forces.nvt_res_b4_int",general_data,class);
   /*-----------------------------------------------------------------------*/

    int_0_to_dt2_nvt(class,bonded,general_data,ir_tra,ir_tor,ir_ter,dti,ipt);

   /*-----------------------------------------------------------------------*/
     sprintf(stuff,"positions.nvt_res_dt2_int.%d.%d.%d",ir_tra,ir_tor,ir_ter);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   stuff,general_data,class);
     sprintf(stuff,"velocities.nvt_res_dt2_int.%d.%d.%d",ir_tra,ir_tor,ir_ter);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                    stuff,general_data,class);
     sprintf(stuff,"forces.nvt_res_dt2_int.%d.%d.%d",ir_tra,ir_tor,ir_ter);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                    stuff,general_data,class);
   /*-----------------------------------------------------------------------*/

/*==========================================================================*/
/* 2) Get the new energy/force                                              */

          (class->energy_ctrl.iget_full_inter) = 0;
          (class->energy_ctrl.iget_res_inter) = 0;
          (class->energy_ctrl.iget_full_intra) = 0;
          (class->energy_ctrl.iget_res_intra)  = 1;
          if((ir_ter==nres_ter)&&(ir_tor==nres_tor)&&(ir_tra==nres_tra))
             {(class->energy_ctrl.iget_full_inter) = 1;}
          if((int_res_ter==1)&&(ir_tor==nres_tor)&&(ir_tra==nres_tra))
             {(class->energy_ctrl.iget_res_inter) = 1;}
          if(ir_tra==nres_tra)
             {(class->energy_ctrl.iget_full_intra) = 1;}

          energy_control(class,bonded,general_data,ipt);
#ifdef _GLENN_
 if((ir_ter==nres_ter)&&(ir_tor==nres_tor)&&(ir_tra==nres_tra)){
  tmp = 0.0;
  for(ipart=myatm_start;ipart<=(myatm_end);ipart++){
   tmp += clatoms_fx[ipart]*clatoms_fx[ipart];
   tmp += clatoms_fy[ipart]*clatoms_fy[ipart];
   tmp += clatoms_fz[ipart]*clatoms_fz[ipart];
  }/*endfor*/
  printf("myid_m %d %d: Mid_f %g\n",myid_m,itime,tmp);
 }
#endif

/*==========================================================================*/
/* 3) Evolve system from dt/2 to dt                                         */
   /*-----------------------------------------------------------------------*/
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   "positions.nvt_res_dt2e_int",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   "velocities.nvt_res_dt2e_int",general_data,class);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   "forces.nvt_res_dt2e_int",general_data,class);
   /*-----------------------------------------------------------------------*/

        int_dt2_to_dt_nvt(class,bonded,general_data,ir_tra,ir_tor,ir_ter,dti,ipt);

   /*-----------------------------------------------------------------------*/
     sprintf(stuff,"positions.nvt_res_a_int.%d.%d.%d",ir_tra,ir_tor,ir_ter);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].x,
		   class->clatoms_pos[ipt].y,class->clatoms_pos[ipt].z,
                   stuff,general_data,class);
     sprintf(stuff,"velocities.nvt_res_a_int.%d.%d.%d",ir_tra,ir_tor,ir_ter);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].vx,
		   class->clatoms_pos[ipt].vy,class->clatoms_pos[ipt].vz,
                   stuff,general_data,class);
     sprintf(stuff,"forces.nvt_res_a_int.%d.%d.%d",ir_tra,ir_tor,ir_ter);
     check_for_NaN(natm_tot,ipt,class->clatoms_pos[ipt].fx,
		   class->clatoms_pos[ipt].fy,class->clatoms_pos[ipt].fz,
                   stuff,general_data,class);
   /*-----------------------------------------------------------------------*/

/*==========================================================================*/
        /*endfor:ir_tra*/}
      /*endfor:ir_tor*/}
    /*endfor:ir_ter*/}

/*==========================================================================*/
/* 4) Scale by annealing factor                                          */

  iflag=0;
  if(anneal_opt == 1){
    anneal_class(class,ann_rate,iflag,iflag_mass,anneal_target_temp,&exit_flag,ipt);
    general_data->timeinfo.exit_flag = exit_flag;
  }/*endif*/

/*==========================================================================*/

#ifdef _GLENN_
  tmp = 0.0;
  for(ipart=myatm_start;ipart<=(myatm_end);ipart++){
   tmp += clatoms_mass[ipart]*clatoms_vx[ipart]*clatoms_vx[ipart];
   tmp += clatoms_mass[ipart]*clatoms_vy[ipart]*clatoms_vy[ipart];
   tmp += clatoms_mass[ipart]*clatoms_vz[ipart]*clatoms_vz[ipart];
  }/*endfor*/
  printf("myid_m %d %d: Bottom_v %g\n",myid_m,itime,tmp);

  tmp = 0.0;
  for(ipart=myatm_start;ipart<=(myatm_end);ipart++){
   tmp += clatoms_fx[ipart]*clatoms_fx[ipart];
   tmp += clatoms_fy[ipart]*clatoms_fy[ipart];
   tmp += clatoms_fz[ipart]*clatoms_fz[ipart];
  }/*endfor*/
  printf("myid_m %d %d: Bottom_f %g\n",myid_m,itime,tmp);
#endif

/*==========================================================================*/
/* 5) Finalize                                                              */

   int_final_class(class,bonded,general_data,iflag,ipt);


/*==========================================================================*/
/*
      printf("x(1),y(1),z(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[1].x[1],
                                         class->clatoms_pos[1].y[1],
                                         class->clatoms_pos[1].z[1]); 
      printf("vx(1),vy(1),vz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[1].vx[1],
                                         class->clatoms_pos[1].vy[1],
                                         class->clatoms_pos[1].vz[1]); 
      printf("fx(1),fy(1),fz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[1].fx[1],
                                         class->clatoms_pos[1].fy[1],
                                         class->clatoms_pos[1].fz[1]); 
      printf("v_nhc[1][1],v_nhc[2,1] %.13g %.13g\n",
                                         class->therm_class.v_nhc[1][1],
                                         class->therm_class.v_nhc[2][1]); 
      printf("x_nhc[1][1],x_nhc[2][1] %.13g %.13g\n",
                                         class->therm_class.x_nhc[1][1],
                                         class->therm_class.x_nhc[2][1]); 
      scanf("%d",&iii);
*/ 
/*-------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/







