/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: int_NVT                                      */
/*                                                                          */
/* This subprogram integrates the system using Vel Verlet                   */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_cp.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../proto_defs/proto_integrate_cp_entry.h"
#include "../proto_defs/proto_integrate_cp_local.h"
#include "../proto_defs/proto_integrate_md_entry.h"
#include "../proto_defs/proto_integrate_md_local.h"
#include "../proto_defs/proto_energy_cpcon_entry.h"
#include "../proto_defs/proto_energy_ctrl_cp_entry.h"
#include "../proto_defs/proto_intra_con_entry.h"
#include "../proto_defs/proto_energy_ctrl_entry.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_coords_local.h"

/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
void int_NVT_cp(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
		CP *cp,int ipt)
/*========================================================================*/
{/*begin routine*/
/*========================================================================*/
/*             Local variable declarations                                */ 
  /*    int ipt=1;*/

    int iii;
    int i,ip=1,ipart,icoef,is,iflag,ifirst=1;
    int exit_flag=0;
    int natm_tot,ichain,inhc;
    double dt,dt2,tol_glob;
    int iflag_mass = 1;


    int ir_tra = 1;
    int ir_tor = 1;
    int ir_ter = 1;
    int anneal_opt = general_data->simopts.anneal_opt;
    double anneal_target_temp = general_data->simopts.ann_target_temp;
    double ann_rate = general_data->simopts.ann_rate;
    int     num_nhc = class->therm_info_class[ipt].num_nhc;
    int     len_nhc = class->therm_info_class[ipt].len_nhc;
    double **therm_v_nhc    = class->therm_class[ipt].v_nhc;
    double **therm_gkt      = class->therm_info_class[ipt].gkt;
    double **therm_mass_nhc = class->therm_info_class[ipt].mass_nhc;
    double *class_clatoms_xold = class->clatoms_pos[ipt].xold;
    double *class_clatoms_yold = class->clatoms_pos[ipt].yold;
    double *class_clatoms_zold = class->clatoms_pos[ipt].zold;
    double *class_clatoms_x    = class->clatoms_pos[ipt].x;
    double *class_clatoms_y    = class->clatoms_pos[ipt].y;
    double *class_clatoms_z    = class->clatoms_pos[ipt].z;
    double *class_clatoms_vx   = class->clatoms_pos[ipt].vx;
    double *class_clatoms_vy   = class->clatoms_pos[ipt].vy;
    double *class_clatoms_vz   = class->clatoms_pos[ipt].vz;
    double *class_clatoms_fx   = class->clatoms_pos[ipt].fx;
    double *class_clatoms_fy   = class->clatoms_pos[ipt].fy;
    double *class_clatoms_fz   = class->clatoms_pos[ipt].fz;
    double *class_clatoms_mass = class->clatoms_info.mass;

    int myid_state           = class->communicate.myid_state;
    int np_states            = class->communicate.np_states;
    int np_forc              = class->communicate.np_forc;
    MPI_Comm comm_states     = class->communicate.comm_states;
/*==========================================================================*/
#define DEBUG_RAPH_OFF
#ifdef DEBUG_RAPH
      printf("top ipt=%d\n",ipt);
      printf("x(1),y(1),z(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].x[1],
                                         class->clatoms_pos[ipt].y[1],
                                         class->clatoms_pos[ipt].z[1]); 
      printf("vx(1),vy(1),vz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].vx[1],
                                         class->clatoms_pos[ipt].vy[1],
                                         class->clatoms_pos[ipt].vz[1]); 
      printf("fx(1),fy(1),fz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].fx[1],
                                         class->clatoms_pos[ipt].fy[1],
                                         class->clatoms_pos[ipt].fz[1]); 
      printf("v_nhc[1][1],v_nhc[2,1] %.13g %.13g\n",
                                         class->therm_class[ipt].v_nhc[1][1],
                                         class->therm_class[ipt].v_nhc[2][1]); 
      printf("x_nhc[1][1],x_nhc[2][1] %.13g %.13g\n",
                                         class->therm_class[ipt].x_nhc[1][1],
                                         class->therm_class[ipt].x_nhc[2][1]); 
      printf("kinet_nhc %.10g\n",general_data->stat_avg[ipt].kinet_nhc);
      printf("coeffs %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].cre_up[1],cp->cpcoeffs_pos[ipt].cim_up[1]);
      printf("coef vels %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].vcre_up[1],cp->cpcoeffs_pos[ipt].vcim_up[1]);
      printf("coef forces %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].fcre_up[1],cp->cpcoeffs_pos[ipt].fcim_up[1]);
#endif
/*==========================================================================*/
/* 0) Useful constants                                                      */

    general_data->timeinfo.exit_flag = 0;
    natm_tot = class->clatoms_info.natm_tot;
    (general_data->timeinfo.int_res_tra)    = 0;
    (general_data->timeinfo.int_res_ter)    = 0;
    dt  = (general_data->timeinfo.dt);
    dt2 = (general_data->timeinfo.dt)/2.0;
    class->therm_info_class[ipt].dt_nhc  = dt;
    class->therm_info_class[ipt].dti_nhc = dt/( (double)(
                             class->therm_info_class[ipt].nres_nhc) );
  if(myid_state==0 || np_forc > 1){
    set_yosh(class->therm_info_class[ipt].nyosh_nhc,
             class->therm_info_class[ipt].dti_nhc ,class->therm_info_class[ipt].wdti,
             class->therm_info_class[ipt].wdti2,class->therm_info_class[ipt].wdti4,
             class->therm_info_class[ipt].wdti8,
             class->therm_info_class[ipt].wdti16);
  }/*endif*/
    general_data->stat_avg[ipt].iter_shake    = 0; 
    general_data->stat_avg[ipt].iter_ratl     = 0; 

    general_data->stat_avg[ipt].iter_23r = 0.0;
    general_data->stat_avg[ipt].iter_33r = 0.0;
    general_data->stat_avg[ipt].iter_46r = 0.0;
    general_data->stat_avg[ipt].iter_23 = 0.0;
    general_data->stat_avg[ipt].iter_33 = 0.0;
    general_data->stat_avg[ipt].iter_46 = 0.0;



/*==========================================================================*/
/* I) CP:  The first half                                                   */

  int_0_to_dt2_cp(class,bonded,general_data,cp,ipt);


/*==========================================================================*/
/* II) Atoms: The first half                                                */

  if( (myid_state==0) || (np_forc > 1) ){
   if(general_data->simopts.cp == 1){
    int_0_to_dt2_nvt(class,bonded,general_data,ir_tra,ir_tor,ir_ter,dt,ipt);
   }/*endif*/
  }/*endif*/

/*==========================================================================*/
/* III) Atoms: The first half                                                */

  if(np_states > 1 && np_forc==1 ){
    comm_coord_class_state(class,general_data,1,1,0,0,ipt);
  }/* endif */

/*==========================================================================*/
/* IV) Get the new energy/force                                             */

    (class->energy_ctrl.iget_full_inter)= 1;
    (class->energy_ctrl.iget_res_inter) = 0;
    (class->energy_ctrl.iget_full_intra)= 1;
    (class->energy_ctrl.iget_res_intra) = 0;

     cp_energy_control(class,bonded,general_data,cp,ipt);

    if(cp->cpopts.cp_gauss == 1){
     add_gauss_force(&(cp->cpcoeffs_info),&(cp->cpcoeffs_pos[ipt]),
		     &(cp->cpscr.cpscr_ovmat),&(cp->cpopts));
    }/*endif*/
/*==========================================================================*/
#ifdef DEBUG_RAPH
      printf("mid ipt=%d\n",ipt);
      printf("x(1),y(1),z(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].x[1],
                                         class->clatoms_pos[ipt].y[1],
                                         class->clatoms_pos[ipt].z[1]); 
      printf("vx(1),vy(1),vz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].vx[1],
                                         class->clatoms_pos[ipt].vy[1],
                                         class->clatoms_pos[ipt].vz[1]); 
      printf("fx(1),fy(1),fz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].fx[1],
                                         class->clatoms_pos[ipt].fy[1],
                                         class->clatoms_pos[ipt].fz[1]); 
      printf("v_nhc[1][1],v_nhc[2,1] %.13g %.13g\n",
                                         class->therm_class[ipt].v_nhc[1][1],
                                         class->therm_class[ipt].v_nhc[2][1]); 
      printf("x_nhc[1][1],x_nhc[2][1] %.13g %.13g\n",
                                         class->therm_class[ipt].x_nhc[1][1],
                                         class->therm_class[ipt].x_nhc[2][1]); 
      printf("kinet_nhc %.10g\n",general_data->stat_avg[ipt].kinet_nhc);
      printf("coeffs %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].cre_up[1],cp->cpcoeffs_pos[ipt].cim_up[1]);
      printf("coef vels %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].vcre_up[1],cp->cpcoeffs_pos[ipt].vcim_up[1]);
      printf("coef forces %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].fcre_up[1],cp->cpcoeffs_pos[ipt].fcim_up[1]);
#endif
/*==========================================================================*/
/* V) Atoms: Second half                                                    */

  if((myid_state == 0) || (np_forc > 1) ){
    if(general_data->simopts.cp==1){
     int_dt2_to_dt_nvt(class,bonded,general_data,ir_tra,ir_tor,ir_ter,dt,ipt);
   }/*endif : cp_on*/
  }/*endif : myid=0*/

/*==========================================================================*/
/* VI) CP: second half                                                      */

  int_dt2_to_dt_cp(class,bonded,general_data,cp,ipt);

/*==========================================================================*/
/* VII) Scale by annealing factor                                          */

 iflag=0;
 if(myid_state == 0 || np_forc > 1){
  if(anneal_opt == 1){
    anneal_class(class,ann_rate,iflag,iflag_mass,anneal_target_temp,&exit_flag,ipt);
    general_data->timeinfo.exit_flag = exit_flag;
  }/*endif:ann_rate*/
 }/*endif:myid=0*/

/*==========================================================================*/
/* VIII) Finalize                                                              */

  if(myid_state == 0 || np_forc > 1){
   int_final_class(class,bonded,general_data,iflag,ipt);
  }/* endif */

/*==========================================================================*/
#ifdef DEBUG_RAPH
      printf("bot ipt=%d\n",ipt);
      printf("x(1),y(1),z(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].x[1],
                                         class->clatoms_pos[ipt].y[1],
                                         class->clatoms_pos[ipt].z[1]); 
      printf("vx(1),vy(1),vz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].vx[1],
                                         class->clatoms_pos[ipt].vy[1],
                                         class->clatoms_pos[ipt].vz[1]); 
      printf("fx(1),fy(1),fz(1) %.13g %.13g %.13g\n",
                                         class->clatoms_pos[ipt].fx[1],
                                         class->clatoms_pos[ipt].fy[1],
                                         class->clatoms_pos[ipt].fz[1]); 
      printf("v_nhc[1][1],v_nhc[2,1] %.13g %.13g\n",
                                         class->therm_class[ipt].v_nhc[1][1],
                                         class->therm_class[ipt].v_nhc[2][1]); 
      printf("x_nhc[1][1],x_nhc[2][1] %.13g %.13g\n",
                                         class->therm_class[ipt].x_nhc[1][1],
                                         class->therm_class[ipt].x_nhc[2][1]); 
      printf("kinet_nhc %.10g\n",general_data->stat_avg[ipt].kinet_nhc);
      printf("coeffs %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].cre_up[1],cp->cpcoeffs_pos[ipt].cim_up[1]);
      printf("coef vels %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].vcre_up[1],cp->cpcoeffs_pos[ipt].vcim_up[1]);
      printf("coef forces %.13g %.13g\n",
           cp->cpcoeffs_pos[ipt].fcre_up[1],cp->cpcoeffs_pos[ipt].fcim_up[1]);
#endif
/*--------------------------------------------------------------------------*/
/*end routine*/}
/*==========================================================================*/


