/*-------------------------------------------------------------------------*/
/* Min_CG.c */

void shake_minf(CLASS *,BONDED *,double );

void shake_ming(CLASS *,BONDED *,double );

void shake_minx(CLASS *,BONDED *,double );

/*-------------------------------------------------------------------------*/
/* dline_min.c  */

void dline_min(CLASS *,BONDED *,GENERAL_DATA *,double *);

void get_new_move(double *,double *,double ,double ,double ,double ,double ,
                  double  ,double  ,double ,double ,double ,double ,double ,
                  double ,double );

/*-------------------------------------------------------------------------*/
