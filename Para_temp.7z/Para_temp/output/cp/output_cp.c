/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/
/*                                                                          */
/*                         PI_MD:                                           */
/*             The future of simulation technology                          */
/*             ------------------------------------                         */
/*                     Module: output_cp                                    */
/*                                                                          */
/* This subprogram provides output for a CP on the                          */ 
/* ground state Born-Oppenheimer GGA-LDA surface                            */
/*                                                                          */
/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

#include "standard_include.h"
#include "../typ_defs/typedefs_class.h"
#include "../typ_defs/typedefs_bnd.h"
#include "../typ_defs/typedefs_gen.h"
#include "../typ_defs/typedefs_cp.h"
#include "../proto_defs/proto_output_cp_entry.h"
#include "../proto_defs/proto_output_cp_local.h"
#include "../proto_defs/proto_energy_cpcon_entry.h"
#include "../proto_defs/proto_friend_lib_entry.h"
#include "../proto_defs/proto_math.h"
#include "../proto_defs/proto_output_local.h"
#include "../proto_defs/proto_communicate_wrappers.h"
#include "../proto_defs/proto_temper_entry.h"


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void output_cp(CLASS *class,GENERAL_DATA *general_data,BONDED *bonded,
	       CP *cp,int ipt)

/*==========================================================================*/
{/*begin routine*/
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"

  double etot,econv_now; 
  double vtot,avtot,pnow; 
  double apnow;
  double nhc_div;
  double a,b,c,tab,tac,tbc; 
  double deth;
  double c_div,c_nhc_div;

/*         Local Pointers                             */
  int exit_flag         = general_data->timeinfo.exit_flag;
  int myid              = class->communicate.myid;
  int nproc             = class->communicate.np;
  MPI_Comm world        = class->communicate.world;
  int np_states         = cp->communicate.np_states;
  int igo;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;


/*=====================================================================*/
/* 0) Adjust form of CP vectors */

 if(general_data->timeinfo.itime!=0 && np_states> 1){
   igo=1;
   if((general_data->timeinfo.itime % 
       general_data->filenames.iwrite_dump)==0 || exit_flag == 1){
    control_coef_transpose_bck(cp,3,ipt);
    igo=0;
   }/*endif*/

   if((general_data->timeinfo.itime % 
         general_data->filenames.iwrite_confc) == 0 && igo==1) {
    control_coef_transpose_bck(cp,1,ipt);
   }/*endif*/

 }/*endif*/

/*=====================================================================*/
/*  I)Open File option :                                               */

  if(myid == 0){   
    if(((general_data->timeinfo.itime)==0)&&((
         general_data->filenames.ifile_open))==1){
          initial_fopen_cp(class,general_data,bonded,cp,ipt);
    }/*endif*/
  }/* endif */
  if(nproc>1){Barrier(world);}

/*=======================================================================*/
/*  II) Write Initial Energies to screen                                 */

  if(myid == 0){   
    if(general_data->timeinfo.itime==0 && general_data->simopts.debug_cp == 0){
      initial_output_cp(class,general_data,bonded,cp,ipt);
    }/*endif*/
  }/* endif */
  if(nproc>1){Barrier(world);}

/*=======================================================================*/
/* II) Calculate some dinky quantities                                   */

  if(myid == 0){   
   if((general_data->timeinfo.itime)!=0){
     if((general_data->timeinfo.itime % 
         general_data->filenames.iwrite_screen) == 0 || 
        (general_data->timeinfo.itime % 
         general_data->filenames.iwrite_inst)==0 ||
         (exit_flag == 1)){
       get_cell(general_data->cell.hmat,&a,&b,&c,&tab,&tbc,&tac);
       dink_quant_calc_cp(class, general_data,cp,&etot,&econv_now,&vtot, 
                          &avtot,
                          &deth,&pnow, &apnow,&nhc_div,&c_div,&c_nhc_div,ipt);
     } /*endif*/
  }/*endif*/
 }/* endif */
 if(nproc>1){Barrier(world);}

/*=======================================================================*/
/*  III) Write to the output to screen                                   */

  if(myid == 0){   
   if((general_data->timeinfo.itime) != 0){
    if((general_data->timeinfo.itime % 
        general_data->filenames.iwrite_screen) == 0 ||
        (exit_flag == 1)){ 
     screen_write_cp(class,general_data,bonded,cp,
                     etot,econv_now,vtot,avtot,deth,pnow, apnow,
                     nhc_div,a,b,c,tab,tbc,tac,c_div,c_nhc_div,ipt);
    }/*endif*/
   }/*endif*/
  }/*endif*/
  if(nproc>1){Barrier(world);}

/*======================================================================*/
/* IV) Write to the output to dump file                                 */ 

  if((general_data->timeinfo.itime!=0)){
    if((general_data->timeinfo.itime % 
        general_data->filenames.iwrite_dump)==0 ||
        (exit_flag == 1)){
      write_dump_file_cp(class,bonded,general_data,cp,ipt);
    }/*endif*/
  }/*endif*/

/*======================================================================*/
/* V) Write to the output to free energy                                */ 

  if(myid == 0){   
   if((general_data->timeinfo.itime)!=0&&(general_data->simopts.cp==1)){
    if((general_data->timeinfo.itime % 
        general_data->filenames.iwrite_dump) == 0){
      write_free_energy_file(class,bonded,general_data,ipt);
    }/*endif*/
   }/*endif*/
  }/*endif*/
  if(nproc>1){Barrier(world);}

/*======================================================================*/
/* V) Write to the kseigs                                               */ 

  if((general_data->timeinfo.itime)!=0  && 
     (general_data->simopts.cp==1 || general_data->simopts.cp_wave==1 )){
    if((general_data->timeinfo.itime % 
        general_data->filenames.iwrite_kseigs) == 0){
        write_kseigs_file_cp(general_data,cp,ipt);
    }/*endif*/
  }/*endif*/
  if(nproc>1){Barrier(world);}

/*======================================================================*/
/* VI) Write to the ELF file                                             */ 

  if(cp->cpcoeffs_info.cp_elf_calc_frq > 0){
   if((general_data->timeinfo.itime)!=0 && 
     (general_data->simopts.cp==1 || general_data->simopts.cp_wave==1 )){
     if((general_data->timeinfo.itime % 
         cp->cpcoeffs_info.cp_elf_calc_frq) == 0){
          write_elf_file_cp(general_data,cp,ipt);
     }/*endif*/
   } /*endif*/
  }/* endif */
  if(nproc>1){Barrier(world);}

/*====================================================================*/
/* VII) Write to the config files                          */

  if((general_data->timeinfo.itime)!=0){
    write_config_files_cp(class,bonded,general_data,cp,ipt);
  }/*endif*/

/*======================================================================*/
/* VIII) Write to the inst avgs to inst file                            */

  if(myid == 0){   
   if((general_data->timeinfo.itime)!=0){
    if((general_data->timeinfo.itime % 
        general_data->filenames.iwrite_inst) == 0 ){
      write_inst_file_cp(class,general_data,cp,etot,a,b,c,tac,tab,tbc,ipt);
    }/*endif*/
   }/*endif*/
  }/*endif*/
  if(nproc>1){Barrier(world);}

/*======================================================================*/
/* IX) Readjust form of CP vectors                                    */

 if(general_data->timeinfo.itime!=0 && np_states> 1){
   igo=1;
   if((general_data->timeinfo.itime % 
       general_data->filenames.iwrite_dump)==0 || exit_flag == 1){
    control_coef_transpose_fwd(cp,3,ipt);
    igo=0;
   }/*endif*/

   if((general_data->timeinfo.itime % 
         general_data->filenames.iwrite_confc) == 0 && igo==1) {
    control_coef_transpose_fwd(cp,1,ipt);
   }/*endif*/
 }/*endif*/

/*==========================================================================*/
     }/*end routine*/
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void initial_output_cp(CLASS *class,GENERAL_DATA *general_data,
		       BONDED *bonded,CP *cp,int ipt)

/*==========================================================================*/

{/* begin routine */

#include "../typ_defs/typ_mask.h"

  int pi_beads = class->clatoms_info.pi_beads;
  int ncons,np_tot,npairs,nsh_tot;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  double c_div,nhc_div,c_nhc_div;
  FILE *fp;

  NAME tname;
  int  npara_temps      = cp->cpopts.npara_temps;
  double eu_conv = 1.0;
  if(general_data->filenames.iwrite_units==0){eu_conv = 1.0;}
  if(general_data->filenames.iwrite_units==1){eu_conv = KCAL;}
  if(general_data->filenames.iwrite_units==2){eu_conv = BOLTZ;}

/*=======================================================================*/
/* switch for || temping yes/no */

  if(npara_temps==1){
    fp=stdout;
  }else{
    fp = cfopen(general_data->tempering_screen_out[ipt].fname,"a");
  }/*endifelse*/

/*==========================================================================*/
/*  Calculate c_div                                                         */

  if(cp->cpopts.cp_lsda == 0) {
    if(cp->cpopts.cp_norb == 0) {
        ncons = (cp->cpcoeffs_info.nstate_up)*
                     ((cp->cpcoeffs_info.nstate_up)+1)/2;
    }else{ ncons = cp->cpcoeffs_info.nstate_up; }
    c_div = (double) (2*cp->cpcoeffs_info.ncoef*
                       cp->cpcoeffs_info.nstate_up-ncons);
  }/* endif */
  if(cp->cpopts.cp_lsda == 1) {
    if(cp->cpopts.cp_norb == 0) {
     ncons = (cp->cpcoeffs_info.nstate_up)*
            ((cp->cpcoeffs_info.nstate_up)+1)/2+ 
             (cp->cpcoeffs_info.nstate_dn)*
            ((cp->cpcoeffs_info.nstate_dn)+1)/2;
    } else { ncons = cp->cpcoeffs_info.nstate_up + cp->cpcoeffs_info.nstate_dn;
 }
    c_div = (double)(2*cp->cpcoeffs_info.ncoef*
                     (cp->cpcoeffs_info.nstate_up+
                      cp->cpcoeffs_info.nstate_dn)-ncons);
  } /* endif */

/*==========================================================================*/
/* Output stuff */

  if((general_data->simopts.cp==1)||(general_data->simopts.debug_cp==1)){
    fprintf(fp,"Initial total      energy  %.10g\n",
                         (general_data->stat_avg[ipt].vintert +
                            + general_data->stat_avg[ipt].vintrat
                            + general_data->stat_avg[ipt].cp_ehart
                            + general_data->stat_avg[ipt].cp_exc
                            + general_data->stat_avg[ipt].cp_eext
                            + general_data->stat_avg[ipt].cp_eke
                            + general_data->stat_avg[ipt].cp_enl)*eu_conv);
    fprintf(fp,"Initial intra      energy  %.10g\n",
                general_data->stat_avg[ipt].vintrat*eu_conv);
    fprintf(fp,"Initial inter      energy  %.10g\n",
                general_data->stat_avg[ipt].vintert*eu_conv);
    fprintf(fp,"Initial kinetic    energy  %.10g\n",
                general_data->stat_avg[ipt].kinet*eu_conv);
    if(class->energy_ctrl.isep_vvdw == 1) {
      fprintf(fp,"Initial VDW        energy  %.10g\n",
             general_data->stat_avg[ipt].vvdw*eu_conv);
      fprintf(fp,"Initial Coul       energy  %.10g\n",
             general_data->stat_avg[ipt].vcoul*eu_conv);
    }/*endif*/
    fprintf(fp,"Initial Bond         energy  %.10g\n",
                           general_data->stat_avg[ipt].vbondt*eu_conv);
    fprintf(fp,"Initial Bendbnd_bond energy  %.10g\n",
                           general_data->stat_avg[ipt].vbend_bnd_bond*eu_conv);
    fprintf(fp,"Initial Watts_bond energy  %.10g\n",
                           general_data->stat_avg[ipt].vbondt_watts*eu_conv);
    fprintf(fp,"Initial Total Bond   energy  %.10g\n",
                           (general_data->stat_avg[ipt].vbend_bnd_bond+
                            general_data->stat_avg[ipt].vbondt+
                            general_data->stat_avg[ipt].vbondt_watts)*eu_conv);
    fprintf(fp,"Initial Bend         energy  %.10g\n",
                           general_data->stat_avg[ipt].vbendt*eu_conv);
    fprintf(fp,"Initial Bendbnd_bend energy  %.10g\n",
                           general_data->stat_avg[ipt].vbend_bnd_bend*eu_conv);
    fprintf(fp,"Initial Watts_bend energy  %.10g\n",
                           general_data->stat_avg[ipt].vbendt_watts*eu_conv);
    fprintf(fp,"Initial Total Bend   energy  %.10g\n",
                           (general_data->stat_avg[ipt].vbend_bnd_bend+
                            general_data->stat_avg[ipt].vbendt+
                            general_data->stat_avg[ipt].vbendt_watts)*eu_conv);
    fprintf(fp,"Initial Torsion    energy  %.10g\n",
             general_data->stat_avg[ipt].vtorst*eu_conv);
    fprintf(fp,"Initial onefour    energy  %.10g\n",
             general_data->stat_avg[ipt].vonfot*eu_conv);
    fprintf(fp,"Initial surface    energy  %.10g\n",
             general_data->stat_avg[ipt].vsurft*eu_conv);
  }/*endif*/


    fprintf(fp,"Initial e-Energy   energy  %.10g\n",
                                (general_data->stat_avg[ipt].cp_ehart
                            + general_data->stat_avg[ipt].cp_exc
                            + general_data->stat_avg[ipt].cp_eext
                            + general_data->stat_avg[ipt].cp_eke
                            + general_data->stat_avg[ipt].cp_enl)*eu_conv);
    fprintf(fp,"Initial e-Hart+XC  energy  %.10g\n",
                            (general_data->stat_avg[ipt].cp_ehart
                            + general_data->stat_avg[ipt].cp_exc)*eu_conv);
    fprintf(fp,"Initial e-Hart+muXC-XC  energy  %.10g\n",
                                      (  general_data->stat_avg[ipt].cp_ehart
                                       + general_data->stat_avg[ipt].cp_muxc
                                 - general_data->stat_avg[ipt].cp_exc)*eu_conv);
    fprintf(fp,"Initial e-External energy  %.10g\n",
                                general_data->stat_avg[ipt].cp_eext*eu_conv);
    fprintf(fp,"Initial e-Nonlocal energy  %.10g\n",
                                general_data->stat_avg[ipt].cp_enl*eu_conv);
    fprintf(fp,"Initial e-Kinetic  energy  %.10g\n",
                                general_data->stat_avg[ipt].cp_eke*eu_conv);
    fprintf(fp,"Initial volume             %.10g\n",
                                   general_data->stat_avg[ipt].vol*BOHR*BOHR*BOHR);
   if(general_data->simopts.cp==1){
     fprintf(fp,"Initial Pressure      %.10g\n",
        (((general_data->ptens[ipt].tvten)[1]+(general_data->ptens[ipt].pvten_tot)[1]
      +(general_data->ptens[ipt].tvten)[5]+(general_data->ptens[ipt].pvten_tot)[5]
      +(general_data->ptens[ipt].tvten)[9]+(general_data->ptens[ipt].pvten_tot)[9])
                        /(3.0*(general_data->stat_avg[ipt].vol)*PCONV)));
     fprintf(fp,"Initial Atm temperature    %.10g\n",
            ((2.0*general_data->stat_avg[ipt].kinet*BOLTZ)/
           ((double)(class->clatoms_info.nfree))));
    }/*endif*/
    fprintf(fp,"Initial e-Temperature      %.10g\n",general_data->stat_avg[ipt].kinet_cp
                                             *2.0*BOLTZ/c_div);
/*==========================================================================*/
  /* NHC quantities                                                        */

  if(general_data->simopts.cp==1){
    if(general_data->ensopts.nvt==1){
      nhc_div = (double) ( class->therm_info_class[ipt].len_nhc*
                          (class->therm_info_class[ipt].num_nhc) );
      fprintf(fp,"Initial particle NHC temperature %.10g\n", 
            ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      if(pi_beads>1){
        nhc_div = (double) ( class->therm_info_bead[ipt].len_nhc*
                            (class->therm_info_bead[ipt].num_nhc) );
        fprintf(fp,"Initial bead NHC temperature %.10g\n", 
              ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      }/*endif*/
    }/*endif*/

    if(general_data->ensopts.npt_i==1){
      nhc_div = (double) ( class->therm_info_class[ipt].len_nhc*
                          (class->therm_info_class[ipt].num_nhc +1));
      fprintf(fp,"Initial NHC temperature %.10g\n", 
            ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      nhc_div = (double) ( class->therm_info_bead[ipt].len_nhc*
                          (class->therm_info_bead[ipt].num_nhc +1));
      if(pi_beads>1){
       fprintf(fp,"Initial bead NHC temperature %.10g\n", 
             ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
       fprintf(fp,"Initial Volume temperature %.10g\n",
             (2.0*general_data->stat_avg[ipt].kinet_v*BOLTZ)); 
     }/*endif*/
    }/*endif*/

    if(general_data->ensopts.npt_f==1){
      nhc_div = (double) ( class->therm_info_class[ipt].len_nhc*
                          (class->therm_info_class[ipt].num_nhc +1));
      fprintf(fp,"Initial NHC temperature %.10g\n", 
            ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      nhc_div = (double) ( class->therm_info_bead[ipt].len_nhc*
                          (class->therm_info_bead[ipt].num_nhc +1));
      fprintf(fp,"Initial bead NHC temperature %.10g\n", 
            ((2.0*general_data->stat_avg[ipt].kinet_nhc*BOLTZ)/nhc_div));
      fprintf(fp,"Initial Volume temperature %.10g\n",      
            ((2.0*general_data->stat_avg[ipt].kinet_v*BOLTZ)/9.0));
    }/*endif*/
  }/*endif*/

   if(cp->cptherm_info.num_c_nhc != 0) {
    c_nhc_div = (double) ((cp->cptherm_info.len_c_nhc)*
                          (cp->cptherm_info.num_c_nhc));
    fprintf(fp,"CP NHC Temperature  = %.10g\n",general_data->stat_avg[ipt].kinet_nhc_cp
                                 *BOLTZ*2.0/c_nhc_div);
    } /* endif */

/*==========================================================================*/
  /* Neighbor list quantities                                              */

  if(general_data->simopts.cp==1){
    if((class->nbr_list.iver)==1){
      npairs = class->nbr_list.verlist[ipt].nter[(class->clatoms_info.natm_tot)] 
       + class->nbr_list.verlist[ipt].jver_off[(class->clatoms_info.natm_tot)];
      np_tot = (class->clatoms_info.natm_tot)*
                       (class->clatoms_info.natm_tot-1)/2 
       - (bonded->excl.nlst);
      fprintf(fp,"Number of pairs = %d out of %d\n",npairs,np_tot);
      if(general_data->timeinfo.int_res_ter==1){
     npairs = class->nbr_list.verlist[ipt].nter_res[(class->clatoms_info.natm_tot)] 
       + class->nbr_list.verlist[ipt].jver_off_res[(class->clatoms_info.natm_tot)];
       fprintf(fp,"Number of pairs = %d out of %d\n",npairs,np_tot);
      }/*endif*/
    }/*endif*/

    if((class->nbr_list.ilnk)==1){
      nsh_tot = ((class->nbr_list.lnklist[ipt].ncell_a)*
                 (class->nbr_list.lnklist[ipt].ncell_b)*
               (class->nbr_list.lnklist[ipt].ncell_c)-1)/2 +
                 (((class->nbr_list.lnklist[ipt].ncell_a)*
                   (class->nbr_list.lnklist[ipt].ncell_b)*
                   (class->nbr_list.lnklist[ipt].ncell_c)-1) % 2) + 1;
      fprintf(fp,"ncell_a = %d, ncell_b = %d, ncell_c = %d natm_cell_max %d \n",
            class->nbr_list.lnklist[ipt].ncell_a,class->nbr_list.lnklist[ipt].ncell_b,
            class->nbr_list.lnklist[ipt].ncell_c,
            class->nbr_list.lnklist[ipt].natm_cell_max);
      fprintf(fp,"# of shifts = %d out of %d\n",
            class->nbr_list.lnklist[ipt].nshft_lnk,nsh_tot);
      if(general_data->timeinfo.int_res_ter==1){
       fprintf(fp,"# of respa shifts = %d out of %d\n",
              class->nbr_list.lnklist[ipt].nshft_lnk_res,nsh_tot);
      }/*endif*/
    }/*endif*/
  }/*endif*/

 fflush(fp);
 if(npara_temps>1){fclose(fp);}

/*==========================================================================*/
}/* end routine */
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void initial_fopen_cp(CLASS *class,GENERAL_DATA *general_data,
                                    BONDED *bonded,CP *cp,int ipt)

/*==========================================================================*/

{/* begin routine */
/*==========================================================================*/

#include "../typ_defs/typ_mask.h"

  int n=1,iii,ibinary,iwrite_now;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  NAME file_typ;
  FILE *fp_bond_free,*fp_bend_free,*fp_tors_free,*fp_rbar_free;
  FILE *fp_iname, *fp_cpname, *fp_cvname,*fp_dname,*fp_ccname,*fp_kseigs;
  FILE *fscreen,*fp_temper;
  NAME tname;
  int  npara_temps      = cp->cpopts.npara_temps;

/*==========================================================================*/
/*     AA) Open dump file                                          */

  if(iptoff==1 && npara_temps > 1){
    fp_temper = cfopen(general_data->tempering_ctrl.history_name,"w");
    fclose(fp_temper);
    fp_temper = cfopen(general_data->tempering_ctrl.wgt_name,"w");
    fclose(fp_temper);
    fp_temper = cfopen(general_data->tempering_ctrl.troyer_name,"w");
    fclose(fp_temper);
  }/*endif intial temper fopen*/

  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.dname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.dname);
  }/*endif*/

  fp_dname = cfopen(tname,"w");
  fclose(fp_dname);

/*==========================================================================*/
/*     A) Open inst avg file                                          */

 if(general_data->simopts.cp==1){ 
  ibinary    = 0; 
  iwrite_now = general_data->filenames.iwrite_inst;
  strcpy(file_typ,"ins_file");

  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.iname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.iname);
  }/*endif*/

  fp_iname   = cfopen(tname,"w");
  write_gen_header_cp(class,general_data,cp,fp_iname,ibinary,
                   iwrite_now,file_typ,ipt);
  fclose(fp_iname);
 }/*endif*/

/*==========================================================================*/
/*     B) Open atm vel conf file                                       */

  if(general_data->simopts.cp==1){ 
    ibinary    = general_data->filenames.iwrite_conf_binary;
    iwrite_now = general_data->filenames.iwrite_confv;
    strcpy(file_typ,"vel_file");

    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.cvname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.cvname);
    }/*endif*/

    fp_cvname  = cfopen(tname,"w");
    write_gen_header_cp(class,general_data,cp,fp_cvname,ibinary,
                     iwrite_now,file_typ,ipt);
    fclose(fp_cvname); 
  }/*endif*/

/*==========================================================================*/
/*     C) Open pos conf file                                           */

    ibinary    = general_data->filenames.iwrite_conf_binary;
    iwrite_now = general_data->filenames.iwrite_confp;
    strcpy(file_typ,"pos_file");

    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.cpname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.cpname);
    }/*endif*/

    fp_cpname  = cfopen(tname,"w");
    write_gen_header_cp(class,general_data,cp,fp_cpname,ibinary,
                     iwrite_now,file_typ,ipt);
    fclose(fp_cpname); 

/*======================================================================*/
/*     C) Open partial pos conf file                                    */

 if(general_data->simopts.cp==1){ 
  if((general_data->filenames.low_lim_par<=
      general_data->filenames.high_lim_par)){
   ibinary    = general_data->filenames.iwrite_conf_binary;
   iwrite_now = general_data->filenames.iwrite_par_confp;
   strcpy(file_typ,"par_file");

   if(npara_temps>1){
     sprintf(tname,"%s.%d",general_data->filenames.cpparname,iptoff);
   }else{
     strcpy(tname,general_data->filenames.cpparname);
   }/*endif*/

   fp_cpname = cfopen(tname,"w"); 
   write_gen_header_cp(class,general_data,cp,fp_cpname,ibinary,
                   iwrite_now,file_typ,ipt);
   fclose(fp_cpname); 
  }/*endif*/
 }/*endif*/

/*==========================================================================*/
/*     E) Open bond free energy file                                   */

 if(general_data->simopts.cp==1){ 
    if(bonded->bond_free[ipt].num>0){
      fp_bond_free  = cfopen(bonded->bond_free[ipt].file,"w");
      fclose(fp_bond_free);
    }/*endif*/
 }/*endif*/

/*==========================================================================*/
/*     F) Open bend free energy file                                    */

 if(general_data->simopts.cp==1){ 
    if(bonded->bend_free[ipt].num>0){
      fp_bend_free  = cfopen(bonded->bend_free[ipt].file,"w");
      fclose(fp_bend_free);
    }/*endif*/
 }/*endif*/

/*==========================================================================*/
/*     G) Open tors free energy file                                    */

 if(general_data->simopts.cp==1){ 
    if(bonded->tors_free[ipt].num>0){
      fp_tors_free  = cfopen(bonded->tors_free[ipt].file,"w");
      fclose(fp_tors_free);
    }/*endif*/
 }/*endif*/    

/*==========================================================================*/
/*     H) Open rbar_sig free energy file                                    */

 if(general_data->simopts.cp==1){ 
    if(bonded->rbar_sig_free[ipt].nfree>0){
      fp_rbar_free  = cfopen(bonded->rbar_sig_free[ipt].file,"w");
      fclose(fp_rbar_free);
    }/*endif*/
 }/*endif*/        

/*==========================================================================*/
/*     H) Open CP conf file (Must be unformatted due to hugeness of         */
/*          wave functions)                                                 */

 if(general_data->simopts.cp == 1){
   ibinary    = 1;
   iwrite_now = general_data->filenames.iwrite_confc;
   strcpy(file_typ,"cof_file");

   if(npara_temps>1){
     sprintf(tname,"%s.%d",general_data->filenames.ccname,iptoff);
   }else{
     strcpy(tname,general_data->filenames.ccname);
   }/*endif*/

   fp_ccname = cfopen(tname,"w");
   write_gen_header_cp(class,general_data,cp,fp_ccname,ibinary,
                   iwrite_now,file_typ,ipt);
   fclose(fp_ccname); 
 }
    
/*==========================================================================*/
/*  I) Open CP KS eigenvalues file                                          */

  if(cp->cpcoeffs_info.ks_rot_on == 1){

    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.ksname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.ksname);
    }/*endif*/

    fp_kseigs = cfopen(tname,"w");
    fprintf(fp_kseigs,
            "Nstate up,Nstate dn, LDA, LSDA, Nbeads,Dump freq,Ntime\n");
    fprintf(fp_kseigs,
            "%d  %d  %d  %d  %d  %d  %d\n",cp->cpcoeffs_info.nstate_up,
                                           cp->cpcoeffs_info.nstate_dn,
                                           cp->cpopts.cp_lda,
                                           cp->cpopts.cp_lsda,
                                           cp->cpcoeffs_info.pi_beads,
                                           cp->cpcoeffs_info.n_ks_rot,
                                           general_data->timeinfo.ntime);
    fclose(fp_kseigs);
  }/* endif */

/*==========================================================================*/
/*     L) Open and close || temp screen files                               */
    if(npara_temps>1){
      fscreen  = cfopen(general_data->tempering_screen_out[ipt].fname,"w");
      fclose(fscreen);
    }/*endif*/
    
    
/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void dink_quant_calc_cp(CLASS *class, GENERAL_DATA *general_data,
                        CP *cp,double *etot,
                        double *econv_now,double *vtot, double *avtot,
                        double *deth,double *pnow, double *apnow,
                        double *nhc_div,double *c_div,double *c_nhc_div,int ipt)

/*==========================================================================*/

{/* begin routine */

  int i,ncons;

#include "../typ_defs/typ_mask.h"

/*==========================================================================*/
 /*  Energy */

  (*etot) = general_data->stat_avg[ipt].kinet_cp + general_data->stat_avg[ipt].cp_ehart
          + general_data->stat_avg[ipt].cp_eext + general_data->stat_avg[ipt].cp_exc  
          + general_data->stat_avg[ipt].cp_eke + general_data->stat_avg[ipt].cp_enl;
  if(cp->cptherm_info.num_c_nhc > 0){
       (*etot) += ( general_data->stat_avg[ipt].kinet_nhc_cp 
                   +general_data->stat_avg[ipt].vpotnhc_cp );
  }/*endif:nhc_cp*/
  if(general_data->simopts.cp == 1) {
        (*etot) += ( (general_data->stat_avg[ipt].kinet) 
                    +(general_data->stat_avg[ipt].vintert) 
                    +(general_data->stat_avg[ipt].vintrat) );
        if((general_data->ensopts.nvt)==1)  
         {(*etot)     += ( (general_data->stat_avg[ipt].kinet_nhc) 
                          +(general_data->stat_avg[ipt].vpotnhc) );}
        if((general_data->ensopts.npt_i)==1)
         {(*etot)     += ( (general_data->stat_avg[ipt].kinet_nhc) 
                          +(general_data->stat_avg[ipt].vpotnhc)
                          +(general_data->stat_avg[ipt].kinet_v)   
                          +(general_data->stat_avg[ipt].vpot_v) );}
       if((general_data->ensopts.npt_f)==1)
         {(*etot)+= ( (general_data->stat_avg[ipt].kinet_nhc) 
                     +(general_data->stat_avg[ipt].vpotnhc)
                     +(general_data->stat_avg[ipt].kinet_v)   
                     +(general_data->stat_avg[ipt].vpot_v) );}

       if(((general_data->ensopts.npt_i+general_data->ensopts.npt_f)==1)&&
           (general_data->stat_avg[ipt].iswit_vdw<=0))
         {(*etot)+= (general_data->stat_avg[ipt].vlong);}
  }/* endif  cp on*/

  (*econv_now) = fabs((*etot)-general_data->stat_avg[ipt].econv0)/
                 fabs(general_data->stat_avg[ipt].econv0);


 /*==========================================================================*/
 /*  Volume and pressure                                                    */

  if(general_data->simopts.cp == 1) {

    (*vtot) = general_data->stat_avg[ipt].vintert + general_data->stat_avg[ipt].vintrat;
    (*avtot) = general_data->stat_avg[ipt].avintert+general_data->stat_avg[ipt].avintrat;
    (*deth) = getdeth(general_data->cell.hmat);
    for(i=1;i<=9;i++){
     general_data->stat_avg[ipt].apten_out[i]=(general_data->ptens[ipt].pvten_tot[i]
                            +general_data->ptens[ipt].tvten[i])/((*deth)*PCONV);
    }
    (*pnow)  = (general_data->stat_avg[ipt].apten_out[1]
            +  general_data->stat_avg[ipt].apten_out[5]
            +  general_data->stat_avg[ipt].apten_out[9])/(3.0);
    (*apnow) =  general_data->stat_avg[ipt].apress
               /(PCONV*((double)(general_data->timeinfo.itime)));

  }/*endif*/

 /*==========================================================================*/
 /*  NHC degrees of freedom                                                  */

  if(general_data->simopts.cp == 1) {
      (*nhc_div) = (double)((class->therm_info_class[ipt].len_nhc)*
                            (class->therm_info_class[ipt].num_nhc));
      if(general_data->ensopts.npt_f == 1 || general_data->ensopts.npt_i == 1){
       (*nhc_div) = (double) (class->therm_info_class[ipt].len_nhc*
                           (class->therm_info_class[ipt].num_nhc +1) );
      }/*endif*/
  }/*endif*/

/*==========================================================================*/
/*  Calculate c_div and c_nhc_div                                           */

  if(cp->cpopts.cp_lsda == 0) {
    if(cp->cpopts.cp_norb == 0) {
        ncons = (cp->cpcoeffs_info.nstate_up)*
                     ((cp->cpcoeffs_info.nstate_up)+1)/2;
    }else{ ncons = cp->cpcoeffs_info.nstate_up; }
    (*c_div) = (double) (2*cp->cpcoeffs_info.ncoef*
                           cp->cpcoeffs_info.nstate_up-ncons);
  }/* endif */

  if(cp->cpopts.cp_lsda == 1) {
    if(cp->cpopts.cp_norb == 0) {
     ncons = (cp->cpcoeffs_info.nstate_up)*((cp->cpcoeffs_info.nstate_up)+1)/2+ 
               (cp->cpcoeffs_info.nstate_dn)*
              ((cp->cpcoeffs_info.nstate_dn)+1)/2;
    } else { ncons = cp->cpcoeffs_info.nstate_up+cp->cpcoeffs_info.nstate_dn; }
    (*c_div) = (double) (2*cp->cpcoeffs_info.ncoef*
                         (cp->cpcoeffs_info.nstate_up+
                          cp->cpcoeffs_info.nstate_dn)
                         -ncons);
  } /* endif */

/*-------------*/
/* c_nhc_div */

   if(cp->cptherm_info.num_c_nhc != 0) {
     (*c_nhc_div) = (double) ((cp->cptherm_info.len_c_nhc)*
                              (cp->cptherm_info.num_c_nhc));
   }/* endif */

/*==========================================================================*/
    }/* end routine */
/*==========================================================================*/





/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void screen_write_cp(CLASS *class,GENERAL_DATA *general_data,
                     BONDED *bonded,CP *cp,
                     double etot,double econv_now,double vtot, 
                     double avtot,double deth,double pnow, double apnow,
                     double nhc_div,double a,double b,double c,
                     double tab,double tbc,double tac,double c_div,
                     double c_nhc_div,int ipt)

/*==========================================================================*/
{/* begin routine */
#include "../typ_defs/typ_mask.h"

 int npairs;
 int iii;

 int cp_lsda          = cp->cpopts.cp_lsda;
 int anneal_opt       = general_data->simopts.anneal_opt;
 int iptoff           = general_data->tempering_ctrl.npara_temps_proc_off + ipt;
 int npara_temps      = general_data->tempering_ctrl.npara_temps;
 int npara_temps_proc = general_data->tempering_ctrl.npara_temps_proc;

 static int count_norb=0;
 double atime,vol_div,atm_div;
 double updates_t,updates_true,updates_now; 
 double eelec;
 double aelec;
 FILE *fp;

/*=======================================================================*/
/* switch for || temping yes/no */
  if(npara_temps==1){
    fp=stdout;
  }else{
    fp = cfopen(general_data->tempering_screen_out[ipt].fname,"a");
  }/*endifelse*/


/*==========================================================================*/
/* Write to screen                                                          */

   atime = (double)(general_data->timeinfo.itime);
   eelec =                   (general_data->stat_avg[ipt].cp_ehart
                            + general_data->stat_avg[ipt].cp_exc
                            + general_data->stat_avg[ipt].cp_eext
                            + general_data->stat_avg[ipt].cp_eke
                            + general_data->stat_avg[ipt].cp_enl);
   aelec =                  (general_data->stat_avg[ipt].acp_ehart
                            + general_data->stat_avg[ipt].acp_exc
                            + general_data->stat_avg[ipt].acp_eext
                            + general_data->stat_avg[ipt].acp_eke
                            + general_data->stat_avg[ipt].acp_enl);


/*==========================================================================*/
/*     A) Standard                                                   */
   
   fprintf(fp,"\n");
   fprintf(fp,"********************************************************\n");
   fprintf(fp,"QUANTITY          =  INSTANTANEOUS    AVERAGE           \n");
   fprintf(fp,"--------------------------------------------------------\n");
   if(general_data->ensopts.nve==1)  fprintf(fp,"Ensemble          = NVE     \n");
   if(general_data->ensopts.nvt==1)  fprintf(fp,"Ensemble          = NVT     \n");
   if(general_data->ensopts.npt_i==1)fprintf(fp,"Ensemble          = NPT-ISO \n");
   if(general_data->ensopts.npt_f==1)fprintf(fp,"Ensemble          = NPT-FLEX\n");
   fprintf(fp,"Time step         = %.10g\n",(double)(general_data->timeinfo.itime));
   if(npara_temps>1){  fprintf(fp,"Temperer index    = %d\n",iptoff);}
   fprintf(fp,"----------------- \n");
   fprintf(fp,"Econv             = %.10g %.10g\n",( econv_now ),
                             ( general_data->stat_avg[ipt].econv/atime));
   if(cp->cpopts.cp_isok_opt == 1)
     fprintf(fp,"CP KE conv        = %.10g %.10g \n",
	    fabs((general_data->stat_avg[ipt].kinet_cp - general_data->stat_avg[ipt].cp_kconv0)/
		 general_data->stat_avg[ipt].cp_kconv0),general_data->stat_avg[ipt].cp_kconv/atime);
   if(general_data->simopts.cp==1){
      fprintf(fp,"----------------- \n");
      fprintf(fp,"Tot Energy        = %.10g %.10g\n",(general_data->stat_avg[ipt].kinet+vtot+eelec),
            (general_data->stat_avg[ipt].akinet+avtot+aelec)/atime);
      fprintf(fp,"----------------- \n");
      fprintf(fp,"Atm Energy        = %.10g %.10g\n",(general_data->stat_avg[ipt].kinet+vtot),
            (general_data->stat_avg[ipt].akinet+avtot)/atime);
      fprintf(fp,"Total Atm PE      = %.10g %.10g\n",(vtot),(avtot/atime));
      fprintf(fp,"Intermol Atm PE   = %.10g %.10g\n",(general_data->stat_avg[ipt].vintert),
            (general_data->stat_avg[ipt].avintert/atime));
      fprintf(fp,"Intramol Atm PE   = %.10g %.10g\n",(general_data->stat_avg[ipt].vintrat),
            (general_data->stat_avg[ipt].avintrat/atime));
      fprintf(fp,"Atm KE            = %.10g %.10g\n",(general_data->stat_avg[ipt].kinet),
            (general_data->stat_avg[ipt].akinet/atime));
      fprintf(fp,"----------------- \n");
      atm_div = (double)(class->clatoms_info.nfree);
      fprintf(fp,"Atm Deg. Free     = %.10g\n",atm_div); 
      fprintf(fp,"Atm Temperature   = %.10g %.10g \n",
            (general_data->stat_avg[ipt].kinet*2.0*BOLTZ/atm_div),
            (general_data->stat_avg[ipt].akinet*2.0*BOLTZ/(atm_div*atime)));
     
   }/* endif */
   fprintf(fp,"----------------- \n");
   fprintf(fp,"e-Energy          = %.10g %.10g\n",
                                (general_data->stat_avg[ipt].cp_ehart
                            + general_data->stat_avg[ipt].cp_exc
                            + general_data->stat_avg[ipt].cp_eext
                            + general_data->stat_avg[ipt].cp_eke
                            + general_data->stat_avg[ipt].cp_enl),
                                (general_data->stat_avg[ipt].acp_ehart
                            + general_data->stat_avg[ipt].acp_exc
                            + general_data->stat_avg[ipt].acp_eext
                            + general_data->stat_avg[ipt].acp_eke
                            + general_data->stat_avg[ipt].acp_enl)
                                 /atime);
   fprintf(fp,"e-Hartree + XC    = %.10g %.10g\n",(general_data->stat_avg[ipt].cp_ehart
                                      + general_data->stat_avg[ipt].cp_exc),
                                           (general_data->stat_avg[ipt].acp_ehart
                                     + general_data->stat_avg[ipt].acp_exc)
                                            /atime);
   fprintf(fp,"e-External PE     = %.10g %.10g\n",(general_data->stat_avg[ipt].cp_eext),
                                         (general_data->stat_avg[ipt].acp_eext)
                                            /atime);
   fprintf(fp,"e-Nonlocal PE     = %.10g %.10g\n",(general_data->stat_avg[ipt].cp_enl),
                                          (general_data->stat_avg[ipt].acp_enl)
                                            /atime);
   fprintf(fp,"e-Kinetic         = %.10g %.10g\n",(general_data->stat_avg[ipt].cp_eke),
                                          (general_data->stat_avg[ipt].acp_eke)
                                            /atime);
   fprintf(fp,"----------------- \n");
   fprintf(fp,"CP Fict KE        = %.10g %.10g\n",(general_data->stat_avg[ipt].kinet_cp),
                                           (general_data->stat_avg[ipt].akinet_cp/atime));

   fprintf(fp,"CP Temperature    = %.10g %.10g\n",(general_data->stat_avg[ipt].kinet_cp
                                          *2.0*BOLTZ/c_div),
                                           (general_data->stat_avg[ipt].akinet_cp
                                          *2.0*BOLTZ/(c_div*atime)));

   if(anneal_opt == 0){
    if(general_data->stat_avg[ipt].kinet_cp*2.0*BOLTZ/c_div>100.0*cp->cpopts.te_ext){
     printf("\n$$$$$$$$$$$$$$$-WARNING-$$$$$$$$$$$$$$$$$$$\n");
     printf("Your current CP temperature is greater than\n");
     printf("100 x the value set in the input file.\n");
     printf("Please reconsider your adiabaticity parameters\n");
     printf("and/or employ coefficient thermostats to control \n");
     printf("this quantity.\n");
     printf("$$$$$$$$$$$$$$$$-WARNING-$$$$$$$$$$$$$$$$$$$\n");
     fflush(stdout);
    }/*endif*/
   }/* endif */

   fprintf(fp,"CP Up Force:   avg: %.10g max: %.10g\n",general_data->stat_avg[ipt].fc_mag_up,
                                             general_data->stat_avg[ipt].fc_max_up);
   if(cp_lsda==1){
    fprintf(fp,"CP Dn Force:   avg: %.10g max: %.10g\n",general_data->stat_avg[ipt].fc_mag_dn,
                                             general_data->stat_avg[ipt].fc_max_dn);
   }/*endif*/

   fprintf(fp,"----------------- \n");

/*==========================================================================*/
/*     B.1) Extended Class                                          */

  if(general_data->simopts.cp==1){
   if((general_data->ensopts.nvt + general_data->ensopts.npt_i
      + general_data->ensopts.npt_f == 1)){
     fprintf(fp,"NHC Temperature   = %.10g %.10g\n",
           (general_data->stat_avg[ipt].kinet_nhc*2.0*BOLTZ/nhc_div),
            (general_data->stat_avg[ipt].akinet_nhc*2.0*BOLTZ
            /(nhc_div*atime)));
   }/*endif*/
   if((general_data->ensopts.npt_i +general_data->ensopts.npt_f == 1)) {
     vol_div = 1.0;
     if(general_data->ensopts.npt_f == 1) vol_div = 6.0;
     fprintf(fp,"Vol Temperature   = %.10g %.10g\n",
              (general_data->stat_avg[ipt].kinet_v*2.0*BOLTZ/vol_div),
              (general_data->stat_avg[ipt].akinet_v*2.0*BOLTZ/(atime*vol_div)));
   }/*endif*/
  }/* endif cp==1 */

/*==========================================================================*/
/*     B.2) Extended Coefs                                                  */

  if(cp->cptherm_info.num_c_nhc != 0) {
      fprintf(fp,"CP NHC Temp       = %.10g %.10g\n",
          (general_data->stat_avg[ipt].kinet_nhc_cp*2.0*BOLTZ)/c_nhc_div,
          (general_data->stat_avg[ipt].akinet_nhc_cp*2.0*BOLTZ)/(c_nhc_div*atime));
  }/* endif */

/*==========================================================================*/
/*     C)Pressure/Vol                                                      */

   if(general_data->simopts.cp == 1&&general_data->cell.iperd>=2
      && cp->cpopts.cp_ptens_calc == 1) {
       fprintf(fp,"Pressure          = %.10g %.10g\n",(pnow),( apnow));
       fprintf(fp,"Avg  P11,P22,P33  = %.10g %.10g %.10g \n",
              (general_data->stat_avg[ipt].apten[1]/(PCONV*atime)),
              (general_data->stat_avg[ipt].apten[5]/(PCONV*atime)),
              (general_data->stat_avg[ipt].apten[9]/(PCONV*atime)));
       fprintf(fp,"Inst P11,P22,P33  = %.10g %.10g %.10g \n",
              (general_data->stat_avg[ipt].apten_out[1]),
              (general_data->stat_avg[ipt].apten_out[5]),
              (general_data->stat_avg[ipt].apten_out[9]));
       fprintf(fp,"Avg  P12,P13,P23  = %.10g %.10g %.10g \n",
              (general_data->stat_avg[ipt].apten[4])/(PCONV*atime),
              (general_data->stat_avg[ipt].apten[7])/(PCONV*atime),
              (general_data->stat_avg[ipt].apten[8])/(PCONV*atime));
       fprintf(fp,"Inst P12,P13,P23  = %.10g %.10g %.10g \n",
              (general_data->stat_avg[ipt].apten_out[4]),
              (general_data->stat_avg[ipt].apten_out[7]),
              (general_data->stat_avg[ipt].apten_out[8]));
       fprintf(fp,"Avg  P21,P31,P32  = %.10g %.10g %.10g \n",
              (general_data->stat_avg[ipt].apten[2])/(PCONV*atime),
              (general_data->stat_avg[ipt].apten[3])/(PCONV*atime),
              (general_data->stat_avg[ipt].apten[6])/(PCONV*atime));
       fprintf(fp,"Inst P21,P31,P32  = %.10g %.10g %.10g \n",
              (general_data->stat_avg[ipt].apten_out[2]),
              (general_data->stat_avg[ipt].apten_out[3]),
              (general_data->stat_avg[ipt].apten_out[6]));
       fprintf(fp,"----------------- \n");
       fprintf(fp,"Volume            = %.10g %.10g\n",(deth*BOHR*BOHR*BOHR),
              (general_data->stat_avg[ipt].avol/atime)*BOHR*BOHR*BOHR);
       fprintf(fp,"Inst cell lths    = %.10g %.10g %.10g\n",(a*BOHR),(b*BOHR),(c*BOHR));
       fprintf(fp,"Avg  cell lths    = %.10g %.10g %.10g\n",    
              (general_data->stat_avg[ipt].acella/atime)*BOHR,
              (general_data->stat_avg[ipt].acellb/atime)*BOHR,
              (general_data->stat_avg[ipt].acellc/atime)*BOHR);
       fprintf(fp,"Inst cell angs    = %.10g %.10g %.10g\n",(tab),(tac),(tbc));
       fprintf(fp,"Avg  cell angs    = %.10g %.10g %.10g\n",
              (general_data->stat_avg[ipt].acellab/atime),
              (general_data->stat_avg[ipt].acellac/atime),
              (general_data->stat_avg[ipt].acellbc/atime));
   }/* endif */
   fprintf(fp,"----------------- \n");

/*==========================================================================*/
/*     D.1)Constraint CLassical                                            */

   if(bonded->constrnt.iconstrnt == 1) {
       if(general_data->simopts.cp==1){
        if(bonded->bond.ncon > 0) {
         fprintf(fp,"Shake iter        = %.10g %.10g\n",
               (double)(general_data->stat_avg[ipt].iter_shake),
               (general_data->stat_avg[ipt].aiter_shake/atime));
         fprintf(fp,"Rattle iter       = %.10g %.10g\n",
               (double)(general_data->stat_avg[ipt].iter_ratl),
               (general_data->stat_avg[ipt].aiter_ratl/atime));
        }
        if(bonded->grp_bond_con.num_21 > 0) {
        fprintf(fp,"Grp_21 shake iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_21,
               general_data->stat_avg[ipt].aiter_21/atime);
         fprintf(fp,"Grp_21 ratl iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_21r,
               general_data->stat_avg[ipt].aiter_21r/atime);
        }
        if(bonded->grp_bond_con.num_23 > 0) {
        fprintf(fp,"Grp_23 shake iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_23,
               general_data->stat_avg[ipt].aiter_23/atime);
         fprintf(fp,"Grp_23 ratl iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_23r,
               general_data->stat_avg[ipt].aiter_23r/atime);
        }
        if(bonded->grp_bond_con.num_33 > 0) {
         fprintf(fp,"Grp_33 shake iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_33,
               general_data->stat_avg[ipt].aiter_33/atime);
         fprintf(fp,"Grp_33 ratl iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_33r,
               general_data->stat_avg[ipt].aiter_33r/atime);
        }
        if(bonded->grp_bond_con.num_46 > 0) {
         fprintf(fp,"Grp_46 shake iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_46,
               general_data->stat_avg[ipt].aiter_46/atime);
         fprintf(fp,"Grp_46 ratl iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_46r,
               general_data->stat_avg[ipt].aiter_46r/atime);
        }
        if(bonded->grp_bond_con.num_43 > 0) {
         fprintf(fp,"Grp_43 shake iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_43,
               general_data->stat_avg[ipt].aiter_43/atime);
         fprintf(fp,"Grp_43 ratl iter = %.10g %.10g\n",
               general_data->stat_avg[ipt].iter_43r,
               general_data->stat_avg[ipt].aiter_43r/atime);
        }
         fprintf(fp,"----------------- \n");
       }/*endif*/
   }/*endif*/

/*==========================================================================*/
/*     D.2)Constraint Coef                                                 */

   if(!cp->cpopts.cp_norb) {
       fprintf(fp,"Orb shake iter    = %.10g %.10g\n",
                        (double)(general_data->stat_avg[ipt].iter_shake_cp),
                                (general_data->stat_avg[ipt].aiter_shake_cp/atime));
      fprintf(fp,"Orb rattle iter   = %.10g %.10g\n",
                        (double) (general_data->stat_avg[ipt].iter_ratl_cp),
                                 (general_data->stat_avg[ipt].aiter_ratl_cp/atime));
   }/*endif*/
   if(cp->cpopts.cp_norb > 0) {
      if(cp->cpopts.cp_norb == 2 || cp->cpopts.cp_norb == 3){
          fprintf(fp,"Max off diag      = %.10g\n",
                                  cp->cpcoeffs_info.max_off_diag);
      }/*endif*/
      if(cp->cpopts.cp_norb == 3){
          fprintf(fp,"Max diag          = %.10g\n",
                                  cp->cpcoeffs_info.max_diag);
      }/*endif*/
      fprintf(fp,"Rotations done    = %.10g\n",
                             general_data->stat_avg[ipt].count_diag_srot);
   }/*endif*/

/*==========================================================================*/
/*     D)Misc                                                         */

   if(class->nbr_list.iver == 1 && general_data->simopts.cp == 1){
      updates_t = general_data->stat_avg[ipt].updates;
      if(updates_t == 0) updates_t = 1;
      updates_now = (double ) (general_data->timeinfo.itime-
                               general_data->stat_avg[ipt].itime_update);
       updates_true = updates_t;
       npairs = class->nbr_list.verlist[ipt].nter[(class->clatoms_info.natm_tot)] 
            + class->nbr_list.verlist[ipt].jver_off[(class->clatoms_info.natm_tot)];
       fprintf(fp,"Inst steps/update = %.10g\n",updates_now);
       fprintf(fp,"Avg. steps/update = %.10g\n",(atime/updates_t));
       fprintf(fp,"Total list updates= %.10g\n",updates_true);
       fprintf(fp,"Number of pairs   = %d \n",npairs);
       fprintf(fp,"----------------- \n");
   }/*endif*/
   fprintf(fp,"Cpu time          = %.10g %.10g\n",(general_data->stat_avg[ipt].cpu_now),
           (general_data->stat_avg[ipt].acpu/atime));
   fprintf(fp,"--------------------------------------------------------\n");
   fprintf(fp,"\n"); 
   fprintf(fp,"********************************************************\n");
   fflush(fp);
/*==========================================================================*/

  if(iptoff==npara_temps_proc && npara_temps>1){
    printf("All temperers completed time step %d (a small lie in parallel).\n",
	   general_data->timeinfo.itime);
  }/*endif*/
  if(npara_temps>1){fclose(fp);}

/*==========================================================================*/
    }/* end routine */
/*==========================================================================*/





/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_dump_file_cp(CLASS *class,BONDED *bonded,GENERAL_DATA *general_data,
                        CP *cp,int ipt)

/*==========================================================================*/
{/* begin routine */

#include "../typ_defs/typ_mask.h"

 int i,j,ncoef_up,ncoef_dn,izero,ip;
 int pi_beads = class->clatoms_info.pi_beads;
 int pi_beads_proc = class->clatoms_info.pi_beads_proc;

 int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
 int iproc,ioff_re,ioff_im;
 double deth;
 FILE *fp_dname,*fp_dnamec;

 int cp_lsda        =cp->cpopts.cp_lsda;
 int nrecv,isoff;
 int is,igo,iii;

 int ibinary = cp->cpopts.iwrite_coef_binary;
 int cp_dual_grid_opt = cp->cpopts.cp_dual_grid_opt;
 double sx,sy,sz;
 double cp_box_center_tmp[4];
 double *cp_box_center = general_data->cell.cp_box_center;
 double *hmati         = general_data->cell.hmati;

 MPI_Status stat;

/* Local pointers */
 int myid       = class->communicate.myid;
 int np_states  = class->communicate.np_states;
 MPI_Comm world = class->communicate.world;
 int nproc      = class->communicate.np;
 NAME tname;
  int  npara_temps      = cp->cpopts.npara_temps;

/*==========================================================================*/

/*==========================================================================*/
/*==========================================================================*/
/* Open dump file                                                           */

 if(myid==0){

   if(npara_temps>1){
     sprintf(tname,"%s.%d",general_data->filenames.dname,iptoff);
     printf("%s.%d",general_data->filenames.dname,iptoff);
   }else{
     strcpy(tname,general_data->filenames.dname);
   }/*endif*/

  fp_dname = cfopen(tname,"o");

/*==========================================================================*/
/*     A)Atm positions                                               */

      fprintf(fp_dname,"natm_tot restart_typ itime ipt\n");
      fprintf(fp_dname,"%d restart_all %d %d\n",class->clatoms_info.natm_tot,
             general_data->timeinfo.itime,pi_beads,iptoff);
      fprintf(fp_dname,"atm pos, atm_typ, mol_typ mol_num\n");
       for(i=1;i<=class->clatoms_info.natm_tot;i++){
       fprintf(fp_dname,"%g %g %g %s %s %s %d\n",
              class->clatoms_pos[ipt].x[i],class->clatoms_pos[ipt].y[i],
                                         class->clatoms_pos[ipt].z[i],
              class->atommaps.atm_typ[class->atommaps.iatm_atm_typ[i]],
              class->atommaps.res_typ[class->atommaps.iatm_res_typ[i]],
              class->atommaps.mol_typ[class->atommaps.iatm_mol_typ[i]],
              class->atommaps.iatm_mol_num[i]);
       }/*endfor*/
/*==========================================================================*/
/*     B)Cell shape                                                 */

      if(general_data->ensopts.npt_i==0){
       deth = getdeth(general_data->cell.hmat);
       general_data->baro.x_lnv = log(deth)/3.0;
       general_data->baro.v_lnv = (general_data->par_rahman.vgmat[1]
                           + general_data->par_rahman.vgmat[5]
                           + general_data->par_rahman.vgmat[9])/3.0;
      }/*endif*/
    if( cp_dual_grid_opt >= 1){

      fprintf(fp_dname,"h matrix cp\n");
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat_cp[1],
             general_data->cell.hmat_cp[4],general_data->cell.hmat_cp[7]);
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat_cp[2],
             general_data->cell.hmat_cp[5],general_data->cell.hmat_cp[8]);
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat_cp[3],
             general_data->cell.hmat_cp[6],general_data->cell.hmat_cp[9]);

/* convert cp_box_center back into xtal coordinates*/
      fprintf(fp_dname,"cp box center\n");

    sx = cp_box_center[1];
    sy = cp_box_center[2];
    sz = cp_box_center[3];

    cp_box_center_tmp[1] =sx*hmati[1]+sy*hmati[4]+sz*hmati[7];
    cp_box_center_tmp[2] =sx*hmati[2]+sy*hmati[5]+sz*hmati[8];
    cp_box_center_tmp[3] =sx*hmati[3]+sy*hmati[6]+sz*hmati[9];

      fprintf(fp_dname,"%g %g %g\n",cp_box_center_tmp[1],cp_box_center_tmp[2],
                                    cp_box_center_tmp[3]);

    }/*endif cp_dual_grid_opt */

      fprintf(fp_dname,"h matrix\n");
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat[1],
             general_data->cell.hmat[4],general_data->cell.hmat[7]);
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat[2],
             general_data->cell.hmat[5],general_data->cell.hmat[8]);
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat[3],
             general_data->cell.hmat[6],general_data->cell.hmat[9]);
      fprintf(fp_dname,"h matrix for Ewald setup\n");
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat_ewd[1],
             general_data->cell.hmat_ewd[4],general_data->cell.hmat_ewd[7]);
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat_ewd[2],
             general_data->cell.hmat_ewd[5],general_data->cell.hmat_ewd[8]);
      fprintf(fp_dname,"%g %g %g\n",general_data->cell.hmat_ewd[3],
             general_data->cell.hmat_ewd[6],general_data->cell.hmat_ewd[9]);
      fprintf(fp_dname,"1/3 log(Vol)\n");
      fprintf(fp_dname,"%g\n",general_data->baro.x_lnv);

/*==========================================================================*/
/*    B.5)PT restart shanannigns                                            */

      if(npara_temps>1){
	fprintf(fp_dname,"origin direction troyer_left troyer_right\n");

        ip=1 + (ipt-1)*pi_beads_proc;  
	fprintf(fp_dname,"%d %d %.10g %.10g\n",
		class->clatoms_pos[ip].origin,
		class->clatoms_pos[ip].idirect,
		general_data->stat_avg[ipt].ndirect[1],
		general_data->stat_avg[ipt].ndirect[2]);
      }/*end if*/

/*==========================================================================*/
/*    C)Atm and Atm NHC Velocities                                   */

      fprintf(fp_dname,"atm vel\n");
       for(i=1;i<=class->clatoms_info.natm_tot;i++){
       fprintf(fp_dname,"%g %g %g\n",class->clatoms_pos[ipt].vx[i],
              class->clatoms_pos[ipt].vy[i],class->clatoms_pos[ipt].vz[i]);
       }/*endfor*/
      
      fprintf(fp_dname,"number of atm nhc, length of nhc\n");
      fprintf(fp_dname,"%d %d\n",class->therm_info_class[ipt].num_nhc,
             class->therm_info_class[ipt].len_nhc);
      fprintf(fp_dname,"atm nhc velocities\n");
      for(j=1;j<=(class->therm_info_class[ipt].len_nhc);j++){
       for(i=1;i<=(class->therm_info_class[ipt].num_nhc);i++){
         fprintf(fp_dname,"%g\n",class->therm_class[ipt].v_nhc[j][i]);
       } /*endfor*/
      }/*endfor*/


/*==========================================================================*/
/*    D)Vol and Vol NHC Velocities                             */

      fprintf(fp_dname,"vol velocities\n");
      fprintf(fp_dname,"%g %g %g\n",general_data->par_rahman.vgmat[1],
          general_data->par_rahman.vgmat[4],general_data->par_rahman.vgmat[7]);
      fprintf(fp_dname,"%g %g %g\n",general_data->par_rahman.vgmat[2],
          general_data->par_rahman.vgmat[5],general_data->par_rahman.vgmat[8]);
      fprintf(fp_dname,"%g %g %g\n",general_data->par_rahman.vgmat[3],
          general_data->par_rahman.vgmat[6],general_data->par_rahman.vgmat[9]);
      fprintf(fp_dname,"log(vol) velocity\n");
      fprintf(fp_dname,"%g\n",general_data->baro.v_lnv);
      fprintf(fp_dname,"vol nhc velocities\n");
      for(i=1;i<=(class->therm_info_class[ipt].len_nhc);i++){
       fprintf(fp_dname,"%g\n",general_data->baro.v_vol_nhc[i]);
      }/*endfor*/

/*==========================================================================*/
/*    E)Misc                                                    */

      ncoef_up = cp->cpcoeffs_info.ncoef;
      ncoef_dn = cp->cpcoeffs_info.ncoef;
      if(cp->cpopts.cp_lda==1){ncoef_dn=0;}
      fprintf(fp_dname,"dt=%g\n",general_data->timeinfo.dt);
      fprintf(fp_dname,"nfree=%d\n",class->clatoms_info.nfree);
      fprintf(fp_dname,"nve=%d nvt=%d npt_i=%d npt_f=%d nst=%d\n",
             general_data->ensopts.nve,  general_data->ensopts.nvt,  
             general_data->ensopts.npt_i,  general_data->ensopts.npt_f,  
             general_data->ensopts.nst);
      fprintf(fp_dname,"nbond_free=%d nbend_free=%d ntors_free=%d\n",
             bonded->bond_free[ipt].num,bonded->bend_free[ipt].num,  
             bonded->tors_free[ipt].num);
      fprintf(fp_dname,"t_ext=%g,pext=%g,stens_ext=%g\n",
             general_data->statepoint[ipt].t_ext,
             general_data->statepoint[ipt].pext,
             general_data->statepoint[ipt].stens_ext);
      fprintf(fp_dname,"cp=%d cp_wave=%d cp_lda=%d cp_lsda=%d\n", 
                      general_data->simopts.cp,general_data->simopts.cp_wave,  
                      cp->cpopts.cp_lda, cp->cpopts.cp_lsda);
      fprintf(fp_dname,"cp_sic=%d cp_norb=%d cp_nonint=%d cp_gga=%d\n",
                      cp->cpopts.cp_sic,    cp->cpopts.cp_norb,  
                      cp->cpopts.cp_nonint, cp->cpopts.cp_gga);
      fprintf(fp_dname,"nstate_up=%d nstate_dn=%d ncoef_up=%d ncoef_dn=%d\n",
                     cp->cpcoeffs_info.nstate_up,  cp->cpcoeffs_info.nstate_dn,
                      ncoef_up,ncoef_dn);
      fprintf(fp_dname,"vxc_typ=%s ggax_typ=%s\n",cp->pseudo.vxc_typ,
                                                   cp->pseudo.ggax_typ);
      fprintf(fp_dname,"ggac_typ=%s\n",cp->pseudo.ggac_typ);
      fflush(fp_dname); 
      fclose(fp_dname); 

 }/*endif : myid==0*/
 if(nproc>1){Barrier(world);}

/*==========================================================================*/
/*==========================================================================*/
/*==========================================================================*/
/* Open cp dump file                                                        */


if(myid ==0){

  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.dnamec,iptoff);
  }else{
    strcpy(tname,general_data->filenames.dnamec);
  }/*endif*/
  
 if(ibinary == 0){
  fp_dnamec = fopen(tname,"w");
 }else{
  fp_dnamec = fopen(tname,"wb");
 }/*endif*/
}

/*==========================================================================*/
/*==========================================================================*/
/* Write the header                                                         */

/*==========================================================================*/
/* Write the header                                                         */

  write_dump_header_cp(fp_dnamec,cp,general_data,myid,ibinary,ipt);

  if(nproc>1){Barrier(world);}

/*==========================================================================*/
/* write the occupation number                                              */

  write_dump_occ_cp(fp_dnamec,cp,myid,ibinary);

  if(nproc>1){Barrier(world);}

/*==========================================================================*/
/*==========================================================================*/
/* Write the coefficients                                                  */

  write_dump_coef_cp(fp_dnamec,cp,class,ibinary,ipt);
 
/*==========================================================================*/
/* Write the coefficient velocities                                         */

  write_dump_vcoef_cp(fp_dnamec,cp,class,general_data,ibinary,ipt);

/*==========================================================================*/
/* Write the extended class stuff                                         */

 write_dump_extended_cp(fp_dnamec,cp,class,general_data,ibinary,ipt);

/*==========================================================================*/
/* Done                                                                     */

   if(myid==0) {
    fflush(fp_dnamec); 
    fclose(fp_dnamec); 
   };

/*==========================================================================*/
    }/* end routine */
/*==========================================================================*/






/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_config_files_cp(CLASS *class,BONDED *bonded,
                           GENERAL_DATA *general_data, CP *cp,int ipt)

/*==========================================================================*/

{/* begin routine */

#include "../typ_defs/typ_mask.h"

  int i,n,ncoef_up,ncoef_dn;
  int is,igo,iproc;

  int cp_on            = general_data->simopts.cp;

  int cp_lsda = cp->cpopts.cp_lsda;
  FILE *fp_cpname, *fp_cvname,*fp_ccname;
  int  ncoef  = cp->cpcoeffs_info.ncoef;

 int  istate_up_st  = cp->cpcoeffs_info.istate_up_st;
 int  istate_up_end = cp->cpcoeffs_info.istate_up_end;
 int  nstate_up     = cp->cpcoeffs_info.nstate_up;
 int  nstate_up_proc= cp->cpcoeffs_info.nstate_up_proc;

 int  istate_dn_st  = cp->cpcoeffs_info.istate_dn_st;
 int  istate_dn_end = cp->cpcoeffs_info.istate_dn_end;
 int  nstate_dn     = cp->cpcoeffs_info.nstate_dn;
 int  nstate_dn_proc= cp->cpcoeffs_info.nstate_dn_proc;
 int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
 int isoff;
 
 MPI_Status stat;

/* Local pointers */
 double *cre_up_tmp = cp->cpscr.cpscr_wave.cre_up;
 double *cim_up_tmp = cp->cpscr.cpscr_wave.cim_up;
 double *cre_dn_tmp = cp->cpscr.cpscr_wave.cre_dn;
 double *cim_dn_tmp = cp->cpscr.cpscr_wave.cim_dn;
 int myid = class->communicate.myid;
 MPI_Comm world = class->communicate.world;
 int nproc      = class->communicate.np;
 NAME tname;
  int  npara_temps      = cp->cpopts.npara_temps;

/*=====================================================================*/
/* 0) */
    ncoef_up = cp->cpcoeffs_info.ncoef;
    ncoef_dn = cp->cpcoeffs_info.ncoef;
    if(cp->cpopts.cp_lda==1){ncoef_dn=0;}

/*=====================================================================*/
/* I) Write to the atm velocity config file                          */

  if(myid==0 ){
    
    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.cpname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.cpname);
    }/*endif*/
    
    if((general_data->timeinfo.itime % 
        general_data->filenames.iwrite_confp) == 0 ){

      if(general_data->filenames.iwrite_conf_binary==0){
	
	fp_cpname = cfopen(tname,"a");
	
	for(i=1;i<=(class->clatoms_info.natm_tot);i++){
	  fprintf(fp_cpname,"%.12g  %.12g  %.12g\n",class->clatoms_pos[ipt].x[i],
		  class->clatoms_pos[ipt].y[i],class->clatoms_pos[ipt].z[i]);
	}/*endfor*/
	for(i=1;i<=9;i+=3) 
	  fprintf(fp_cpname,"%g %g %g\n",general_data->cell.hmat[i],
		  general_data->cell.hmat[i+1],general_data->cell.hmat[i+2]);
	fflush(fp_cpname);
	fclose(fp_cpname);
      }/*endif*/
      
      if(general_data->filenames.iwrite_conf_binary==1){
	fp_cpname = cfopen(tname,"a");
	n=1;
	for(i=1;i<=(class->clatoms_info.natm_tot);i++){ 
	  fwrite(&(class->clatoms_pos[ipt].x)[i],sizeof(double),n,fp_cpname);
	  fwrite(&(class->clatoms_pos[ipt].y)[i],sizeof(double),n,fp_cpname);
	  fwrite(&(class->clatoms_pos[ipt].z)[i],sizeof(double),n,fp_cpname);
	}/*endfor*/ 
	for(i=1;i<=9;i+=3){ 
	  fwrite(&(general_data->cell.hmat)[i],sizeof(double),n,fp_cpname);
	  fwrite(&(general_data->cell.hmat)[i+1],sizeof(double),n,fp_cpname);
	  fwrite(&(general_data->cell.hmat)[i+2],sizeof(double),n,fp_cpname);
	}/*endfor*/ 
	fflush(fp_cpname);
	fclose(fp_cpname);
      }/*endif*/
    }
  }/* endif myid==0 */
  if(nproc>1){Barrier(world); }

/*=====================================================================*/
 /* II) Write to the atm velocity config file                          */

  if(myid==0 && cp_on == 1){
    
    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.cvname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.cvname);
    }/*endif*/

    if((general_data->timeinfo.itime % 
        general_data->filenames.iwrite_confv) == 0 
        &&(general_data->simopts.cp==1)){
   if(general_data->filenames.iwrite_conf_binary==0){
      fp_cvname = cfopen(tname,"a");
       for(i=1;i<=(class->clatoms_info.natm_tot);i++){
       fprintf(fp_cvname,"%.12g  %.12g  %.12g\n",class->clatoms_pos[ipt].vx[i],
              class->clatoms_pos[ipt].vy[i],class->clatoms_pos[ipt].vz[i]);
       }/*endfor*/
      for(i=1;i<=9;i+=3) 
       fprintf(fp_cvname,"%g %g %g\n",general_data->cell.hmat[i],
              general_data->cell.hmat[i+1],general_data->cell.hmat[i+2]);
      fflush(fp_cvname);
      fclose(fp_cvname);
    }/*endif*/
   }/*endif binary*/

   if(general_data->filenames.iwrite_conf_binary==1){
     fp_cvname = cfopen(tname,"a");
     n=1;
      for(i=1;i<=(class->clatoms_info.natm_tot);i++){ 
       fwrite(&(class->clatoms_pos[ipt].vx)[i],sizeof(double),n,fp_cvname);
       fwrite(&(class->clatoms_pos[ipt].vy)[i],sizeof(double),n,fp_cvname);
       fwrite(&(class->clatoms_pos[ipt].vz)[i],sizeof(double),n,fp_cvname);
      }/*endfor*/ 
     for(i=1;i<=9;i+=3){ 
      fwrite(&(general_data->cell.hmat)[i],sizeof(double),n,fp_cvname);
      fwrite(&(general_data->cell.hmat)[i+1],sizeof(double),n,fp_cvname);
      fwrite(&(general_data->cell.hmat)[i+2],sizeof(double),n,fp_cvname);
     }/*endfor*/ 
     fflush(fp_cvname);
     fclose(fp_cvname);
   }/*endif:binary*/


  }/* endif myid */
  if(nproc>1){Barrier(world);}

/*=====================================================================*/
 /* III) Write to the coefficient file                                 */
/*       Unformatted output is absolutely necessary here!!!!           */
  
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.ccname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.ccname);
  }/*endif*/
  
  if((general_data->timeinfo.itime%
      general_data->filenames.iwrite_confc) == 0 && cp_on == 1 ){
    if(myid==0 ) {fp_ccname = cfopen(tname,"a"); }
    if(nproc>1){Barrier(world);}
    n = ncoef;
    for(is=1;is<=nstate_up;is++){
      igo=0;
      if((is>=istate_up_st) && (is<=istate_up_end)){
	isoff=(is-istate_up_st)*ncoef;
	for(i=1;i<=ncoef;i++){
	  cre_up_tmp[i] = cp->cpcoeffs_pos[ipt].cre_up[(i+isoff)];
	  cim_up_tmp[i] = cp->cpcoeffs_pos[ipt].cim_up[(i+isoff)];
	}/* endfor */
	igo = 1;
	if(myid!=0){
	  Ssend(&(cre_up_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
	  Ssend(&(cim_up_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
	}/*endif*/
      }/* endif */
      if(myid==0&&igo==0){
	Recv(&(cre_up_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,
	     MPI_ANY_TAG,world);
	Recv(&(cim_up_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,
	     MPI_ANY_TAG,world);
      }/* endif */
      if(myid==0){
	fwrite(cre_up_tmp,sizeof(double),n,fp_ccname);
	fwrite(cim_up_tmp,sizeof(double),n,fp_ccname);
      }/* endif myid */
      if(nproc>1){Barrier(world);}
    }/*endfor:states*/
    if(cp_lsda==1 && nstate_dn != 0){
      for(is=1;is<=nstate_dn;is++){
	igo=0;
	if((is>=istate_dn_st) && (is<=istate_dn_end)){
	  isoff=(is-istate_dn_st)*ncoef;
	  for(i=1;i<=ncoef;i++){
	    cre_dn_tmp[i] = cp->cpcoeffs_pos[ipt].cre_dn[(i+isoff)];
	    cim_dn_tmp[i] = cp->cpcoeffs_pos[ipt].cim_dn[(i+isoff)];
	  }/* endfor */
	  igo = 1;
	  if(myid!=0){
	    Ssend(&(cre_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
	    Ssend(&(cim_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
	  }/*endif*/
	}/* endif */
	if(myid==0&&igo==0){
	  Recv(&(cre_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,
	       MPI_ANY_TAG,world);
	  Recv(&(cim_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,
	       MPI_ANY_TAG,world);
	}/* endif */
	if(myid==0){
	  fwrite(cre_dn_tmp,sizeof(double),n,fp_ccname);
	  fwrite(cim_dn_tmp,sizeof(double),n,fp_ccname);
	}/* endif myid */
	if(nproc>1){Barrier(world);}
      }/*endfor:states*/
    }/* endif lsda */
    if(myid==0){
      n=9;
      fwrite(general_data->cell.hmat,sizeof(double),n,fp_ccname);
      fclose(fp_ccname);
    }/* endif myid */
    if(nproc>1){Barrier(world);}
  }/*endif*/

/*==========================================================================*/
   }/* end routine */
/*==========================================================================*/





/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_inst_file_cp(CLASS *class,GENERAL_DATA *general_data, CP *cp,
                        double etot,double a,double b,double c,
                        double tac,double tab,double tbc,int ipt)

/*==========================================================================*/

{/* begin routine */

#include "../typ_defs/typ_mask.h"

  int i;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;
  double inst_div;
  FILE *fp_iname;
  NAME tname;
  int  npara_temps      = cp->cpopts.npara_temps;

/*==========================================================================*/
/*    O) settle filenames                                            */
    
    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.iname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.iname);
    }/*endif*/
/*==========================================================================*/
/*    A) Finish Averages                                            */


  inst_div    = (double)(general_data->filenames.iwrite_inst);    
  general_data->stat_avg[ipt].aikinet_cp     /= inst_div;
  general_data->stat_avg[ipt].aikinet_nhc_cp /= inst_div;
  general_data->stat_avg[ipt].aicp_ehart     /= inst_div;
  general_data->stat_avg[ipt].aicp_eext      /= inst_div;
  general_data->stat_avg[ipt].aicp_exc       /= inst_div;
  general_data->stat_avg[ipt].aicp_eke       /= inst_div;
  general_data->stat_avg[ipt].aicp_enl       /= inst_div;
  general_data->stat_avg[ipt].aikinet     /= inst_div;
  general_data->stat_avg[ipt].aikinet_v   /= inst_div;
  general_data->stat_avg[ipt].aikinet_nhc /= inst_div;
  general_data->stat_avg[ipt].aivintert   /= inst_div;
  general_data->stat_avg[ipt].aivintrat   /= inst_div;
  general_data->stat_avg[ipt].aivol       /= inst_div;
  general_data->stat_avg[ipt].aicella     /= inst_div;
  general_data->stat_avg[ipt].aicellb     /= inst_div;
  general_data->stat_avg[ipt].aicellc     /= inst_div;
  general_data->stat_avg[ipt].aicellab    /= inst_div;
  general_data->stat_avg[ipt].aicellbc    /= inst_div;
  general_data->stat_avg[ipt].aicellac    /= inst_div;
  for(i=1;i<=9;i++){general_data->stat_avg[ipt].aipten[i] /= (inst_div*PCONV);}

/*==========================================================================*/
/*   B) Write Averages                                                */

  fp_iname = cfopen(tname,"a");
  fprintf(fp_iname,"\n");
  fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g %.9g\n",
         general_data->stat_avg[ipt].aikinet,general_data->stat_avg[ipt].aikinet_v,
         general_data->stat_avg[ipt].aikinet_nhc,general_data->stat_avg[ipt].aivintert,
         general_data->stat_avg[ipt].aivintrat,general_data->stat_avg[ipt].aivol,etot);
  fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g\n",
             general_data->stat_avg[ipt].aicella,general_data->stat_avg[ipt].aicellb,
             general_data->stat_avg[ipt].aicellc,general_data->stat_avg[ipt].aicellac,
             general_data->stat_avg[ipt].aicellab,general_data->stat_avg[ipt].aicellbc);
  for(i=1;i<=9;i+=3){
   fprintf(fp_iname,"%.9g %.9g %.9g\n",general_data->stat_avg[ipt].aipten[i],
              general_data->stat_avg[ipt].aipten[i+1],
              general_data->stat_avg[ipt].aipten[i+2]);
  }
  fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g\n",
             general_data->stat_avg[ipt].kinet,general_data->stat_avg[ipt].kinet_v,
             general_data->stat_avg[ipt].kinet_nhc,general_data->stat_avg[ipt].vintert,
             general_data->stat_avg[ipt].vintrat,general_data->stat_avg[ipt].vol);
  fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g\n",a,b,c,tac,tab,tbc);
  for(i=1;i<=9;i+=3){
    fprintf(fp_iname,"%.9g %.9g %.9g\n",general_data->stat_avg[ipt].apten_out[i],
              general_data->stat_avg[ipt].apten_out[i+1],
              general_data->stat_avg[ipt].apten_out[i+2]);
  }
  fprintf(fp_iname,"%.9g %.9g %.9g %.9g %.9g %.9g %.9g\n",
               general_data->stat_avg[ipt].aikinet_cp,
               general_data->stat_avg[ipt].aikinet_nhc_cp,
               general_data->stat_avg[ipt].aicp_ehart,
               general_data->stat_avg[ipt].aicp_eext,
               general_data->stat_avg[ipt].aicp_exc,
               general_data->stat_avg[ipt].aicp_eke,
               general_data->stat_avg[ipt].aicp_enl);
  fflush(fp_iname);
  fclose(fp_iname);

/*==========================================================================*/
/*   C) Zero Averages                                               */

  general_data->stat_avg[ipt].aikinet_cp     = 0.0;
  general_data->stat_avg[ipt].aikinet_nhc_cp = 0.0;
  general_data->stat_avg[ipt].aicp_ehart     = 0.0;
  general_data->stat_avg[ipt].aicp_eext      = 0.0;
  general_data->stat_avg[ipt].aicp_exc       = 0.0;
  general_data->stat_avg[ipt].aicp_eke       = 0.0;
  general_data->stat_avg[ipt].aicp_enl       = 0.0;
  general_data->stat_avg[ipt].aikinet        = 0.0;
  general_data->stat_avg[ipt].aikinet_v      = 0.0;
  general_data->stat_avg[ipt].aikinet_nhc    = 0.0;
  general_data->stat_avg[ipt].aivintert      = 0.0;
  general_data->stat_avg[ipt].aivintrat      = 0.0;
  general_data->stat_avg[ipt].aivol          = 0.0;
  general_data->stat_avg[ipt].aicella        = 0.0;
  general_data->stat_avg[ipt].aicellb        = 0.0;
  general_data->stat_avg[ipt].aicellc        = 0.0;
  general_data->stat_avg[ipt].aicellab       = 0.0;
  general_data->stat_avg[ipt].aicellbc       = 0.0;
  general_data->stat_avg[ipt].aicellac       = 0.0;
  for(i=1;i<=9;i++){general_data->stat_avg[ipt].aipten[i]  = 0.0;}

/*==========================================================================*/
    }/* end routine */
/*==========================================================================*/



/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_dump_header_cp(FILE *fp_dnamec,CP *cp,
			  GENERAL_DATA *general_data,int myid,
                          int ibinary,int ipt)

/*==========================================================================*/

{/* begin routine */
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"

  int izero,n;
  int csize = MAXWORD;
  int str_size,i;
  NAME tname;

  int npara_temps = cp->cpopts.npara_temps;
  int iptoff      = ipt + general_data->tempering_ctrl.npara_temps_proc_off;

 char *c_array1,*c_array2,*c_array3,*c_array4;
   
 if( (ibinary == 1) && (myid == 0) ){
   c_array1  = (char *) cmalloc(csize*sizeof(char));
   c_array2  = (char *) cmalloc(csize*sizeof(char));
   c_array3  = (char *) cmalloc(csize*sizeof(char));
   c_array4  = (char *) cmalloc(csize*sizeof(char));

/* initialize string  */
   for(i=0; i< csize-1; i++){
     c_array1[i] = ' ';
     c_array2[i] = ' ';
     c_array3[i] = ' ';
     c_array4[i] = ' ';
   }
     c_array1[csize-1] = '\0';
     c_array2[csize-1] = '\0';
     c_array3[csize-1] = '\0';
     c_array4[csize-1] = '\0';
 }/*endif*/

/*==========================================================================*/
/*==========================================================================*/
/* Write the header                                                         */

if(myid==0){
 if(ibinary == 0){
    fprintf(fp_dnamec,"ncoef_up, ncoef_dn, nstate_up, nstate_dn, ");
    fprintf(fp_dnamec,"dft_typ, restart_typ, time of dump, ipt\n");
 }else{

#ifdef HP_VECLIB
   strcpy(c_array1,"hp_veclib:ncoef_up ");
#endif
#ifdef SGI_COMPLIB
   strcpy(c_array1,"sgi_complib:ncoef_up ");
#endif
#ifdef IBM_ESSL
   strcpy(c_array1,"ibm_essl:ncoef_up ");
#endif
#ifdef IBM_NOESSL
   strcpy(c_array1,"ibm_noessl:ncoef_up ");
#endif
#ifdef DEC_ALPHA
   strcpy(c_array1,"dec_alpha:ncoef_up ");
#endif
#ifdef _CRAY
   strcpy(c_array1,"cray:ncoef_up:ncoef_up ");
#endif
#ifdef SUN_COMPLIB
   strcpy(c_array1,"sun_complib:ncoef_up ");
#endif
#ifdef SUN_COMPLIB_OFF
   strcpy(c_array1,"sun_complib:ncoef_up ");
#endif
   strcpy(c_array2,"ncoef_dn, ");
   strcpy(c_array3,"nstate_up ");
   strcpy(c_array4,"nstate_dn ");

   fwrite(c_array1,sizeof(char),csize,fp_dnamec);
   fwrite(c_array2,sizeof(char),csize,fp_dnamec);
   fwrite(c_array3,sizeof(char),csize,fp_dnamec);
   fwrite(c_array4,sizeof(char),csize,fp_dnamec);

    strcpy(c_array1 ,"dft_typ,     ");
    strcpy(c_array2 ,"restart_typ  ");
    strcpy(c_array3 ,"time of dump ");

    fwrite(c_array1,sizeof(char),csize,fp_dnamec);
    fwrite(c_array2,sizeof(char),csize,fp_dnamec);
    fwrite(c_array3,sizeof(char),csize,fp_dnamec);  
 }/*endif ibinary*/


  if(cp->cpopts.cp_lda==1){
    izero = 0;
    if((general_data->simopts.cp+general_data->simopts.cp_wave)==1){
      if(cp->cpopts.cp_norb>0){
       if(ibinary == 0){
         fprintf(fp_dnamec,"%d %d %d %d lda restart_all %d norb_on %d\n",
              cp->cpcoeffs_info.ncoef,izero,
              cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_up,
              general_data->timeinfo.itime,iptoff);
       }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&izero,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);

        strcpy(c_array1,"lda");
        strcpy(c_array2,"restart_all");
        strcpy(c_array3,"norb_on");

        fwrite(c_array1,sizeof(char),csize,fp_dnamec);
        fwrite(c_array2,sizeof(char),csize,fp_dnamec);
        fwrite(&(general_data->timeinfo.itime),sizeof(int),n,fp_dnamec);
        fwrite(&iptoff,sizeof(int),n,fp_dnamec);
        fwrite(c_array3,sizeof(char),csize,fp_dnamec); 
      }/*endif ibinary*/

     }else{
      if(ibinary == 0){
        fprintf(fp_dnamec,"%d %d %d %d lda restart_all %d norb_off %d\n",
                cp->cpcoeffs_info.ncoef,izero,
                cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_up,
                general_data->timeinfo.itime,iptoff);
      }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&izero,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);

        strcpy(c_array1,"lda");
        strcpy(c_array2,"restart_all");
        strcpy(c_array3,"norb_off");

        fwrite(c_array1,sizeof(char),csize,fp_dnamec);
        fwrite(c_array2,sizeof(char),csize,fp_dnamec);
        fwrite(&general_data->timeinfo.itime,sizeof(int),n,fp_dnamec);
        fwrite(&iptoff,sizeof(int),n,fp_dnamec);
        fwrite(c_array3,sizeof(char),csize,fp_dnamec);
      }/*endif ibinary*/
     }/*endif*/
    }else{

     if(cp->cpopts.cp_norb>0){

      if(ibinary == 0){
       fprintf(fp_dnamec,"%d %d %d %d lda restart_pos %d norb_on %d\n",
              cp->cpcoeffs_info.ncoef,izero,
              cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_up,
              general_data->timeinfo.itime,iptoff);
      }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&izero,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);

	 strcpy(c_array1,"lda");
         strcpy(c_array2,"restart_pos");
         strcpy(c_array3,"norb_on");

       fwrite(c_array1,sizeof(char),csize,fp_dnamec);
       fwrite(c_array2,sizeof(char),csize,fp_dnamec);
       fwrite(&general_data->timeinfo.itime,sizeof(int),n,fp_dnamec);
       fwrite(&iptoff,sizeof(int),n,fp_dnamec);
       fwrite(c_array3,sizeof(char),csize,fp_dnamec); 
      }/*endif ibinary*/
      }else{
     if(ibinary == 0){
       fprintf(fp_dnamec,"%d %d %d %d lda restart_pos %d norb_off %d\n",
              cp->cpcoeffs_info.ncoef,izero,
              cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_up,
              general_data->timeinfo.itime,iptoff);
     }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&izero,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);

         strcpy(c_array1,"lda");
         strcpy(c_array2,"restart_pos");
         strcpy(c_array3,"norb_off");

       fwrite(c_array1,sizeof(char),csize,fp_dnamec);
       fwrite(c_array2,sizeof(char),csize,fp_dnamec);
       fwrite(&general_data->timeinfo.itime,sizeof(int),n,fp_dnamec);
       fwrite(&iptoff,sizeof(int),n,fp_dnamec);
       fwrite(c_array3,sizeof(char),csize,fp_dnamec);
     }/*endif ibinary*/

      }/*endif*/
    }/*endif*/
  }/*endif*/
  if(cp->cpopts.cp_lsda==1){
    if((general_data->simopts.cp+general_data->simopts.cp_wave)==1){
     if(cp->cpopts.cp_norb>0){
      if(ibinary == 0){
      fprintf(fp_dnamec,"%d %d %d %d lsda restart_all %d norb_on %d\n",
         cp->cpcoeffs_info.ncoef,cp->cpcoeffs_info.ncoef,
         cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_dn,
         general_data->timeinfo.itime,iptoff);
      }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_dn,sizeof(int),n,fp_dnamec);

         strcpy(c_array1,"lsda");
         strcpy(c_array2,"restart_all");
         strcpy(c_array3,"norb_on");

       fwrite(c_array1,sizeof(char),csize,fp_dnamec);
       fwrite(c_array2,sizeof(char),csize,fp_dnamec);
       fwrite(&general_data->timeinfo.itime,sizeof(int),n,fp_dnamec);
       fwrite(&iptoff,sizeof(int),n,fp_dnamec);
       fwrite(c_array3,sizeof(char),csize,fp_dnamec);
      }/*endif ibinary*/

     }else{
      if( ibinary == 0){
      fprintf(fp_dnamec,"%d %d %d %d lsda restart_all %d norb_off %d\n",
         cp->cpcoeffs_info.ncoef,cp->cpcoeffs_info.ncoef,
         cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_dn,
         general_data->timeinfo.itime,iptoff);
      }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_dn,sizeof(int),n,fp_dnamec);

        strcpy(c_array1,"lsda");
        strcpy(c_array2,"restart_all");
        strcpy(c_array3,"norb_off");

        fwrite(c_array1,sizeof(char),csize,fp_dnamec);
        fwrite(c_array2,sizeof(char),csize,fp_dnamec);
        fwrite(&general_data->timeinfo.itime,sizeof(int),n,fp_dnamec);
        fwrite(&iptoff,sizeof(int),n,fp_dnamec);
        fwrite(c_array3,sizeof(char),csize,fp_dnamec);
      }/*endif ibinary */
     }/*endif*/
    }else{
     if(cp->cpopts.cp_norb>0){
      if(ibinary == 0){
        fprintf(fp_dnamec,"%d %d %d %d lsda restart_pos %d norb_on %d\n",
          cp->cpcoeffs_info.ncoef,cp->cpcoeffs_info.ncoef,
          cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_dn,
          general_data->timeinfo.itime,iptoff);
      }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_dn,sizeof(int),n,fp_dnamec);

        strcpy(c_array1,"lsda");
        strcpy(c_array2,"restart_pos");
        strcpy(c_array3,"norb_on");

        fwrite(c_array1,sizeof(char),csize,fp_dnamec);
        fwrite(c_array2,sizeof(char),csize,fp_dnamec);
        fwrite(&general_data->timeinfo.itime,sizeof(int),n,fp_dnamec);
        fwrite(&iptoff,sizeof(int),n,fp_dnamec);
        fwrite(c_array3,sizeof(char),csize,fp_dnamec);
      }/*endif ibinary*/
     }else{
      if(ibinary == 0){
        fprintf(fp_dnamec,"%d %d %d %d lsda restart_pos %d norb_off %d\n",
          cp->cpcoeffs_info.ncoef,cp->cpcoeffs_info.ncoef,
          cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_dn,
          general_data->timeinfo.itime,iptoff);
      }else{
        n = 1;
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.ncoef,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_up,sizeof(int),n,fp_dnamec);
        fwrite(&cp->cpcoeffs_info.nstate_dn,sizeof(int),n,fp_dnamec);

        strcpy(c_array1,"lsda");
        strcpy(c_array2,"restart_pos");
        strcpy(c_array3,"norb_off");

        fwrite(c_array1,sizeof(char),csize,fp_dnamec);
        fwrite(c_array2,sizeof(char),csize,fp_dnamec);
        fwrite(&general_data->timeinfo.itime,sizeof(int),n,fp_dnamec);
        fwrite(&iptoff,sizeof(int),n,fp_dnamec);
        fwrite(c_array3,sizeof(char),csize,fp_dnamec);
      }/*endif ibinary*/
     }/*endif*/
    }/*endif*/
  }/*endif*/
}/*endif:myid==0*/

 if( (ibinary == 1) && (myid == 0)){
   cfree(c_array1);
   cfree(c_array2);
   cfree(c_array3); 
   cfree(c_array4);  
 }/*endif*/


/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_dump_occ_cp(FILE *fp_dnamec,CP *cp,int myid,int ibinary)

/*==========================================================================*/

{/* begin routine */
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"

  int i,n;
  int nstate;
  double occ_temp; /* for binary write option */

  char *c_array1,*c_array2;
  int csize = MAXWORD;

  NAME tname;

  if( (ibinary == 1) && (myid == 0) ){
    c_array1 = (char *) cmalloc(csize*sizeof(char ));
    c_array2 = (char *) cmalloc(csize*sizeof(char ));
  /* initialize arrays  */
    for(i=0 ; i< csize-1; i++){
      c_array1[i] = ' ';
      c_array2[i] = ' ';
    }
      c_array1[csize -1] = '\0';
      c_array2[csize -1] = '\0';
  }/*endif*/

/*==========================================================================*/
/* write the occupation number                                              */

 if(myid == 0){

  nstate  = MAX(cp->cpcoeffs_info.nstate_up,cp->cpcoeffs_info.nstate_dn);

  if(ibinary == 0){
   fprintf(fp_dnamec,"up occupation    dn occupation\n");
  }else{
    strcpy(c_array1,"up occupation");
    strcpy(c_array2,"dn occupation");

    fwrite(c_array1,sizeof(char),csize,fp_dnamec);
    fwrite(c_array2,sizeof(char),csize,fp_dnamec);

  }/*endif ibinary*/

  for(i=1;i<=nstate;i++){
   if(cp->cpopts.cp_lsda==1){
    if(ibinary == 0){
    fprintf(fp_dnamec,"%g %g\n",cp->cpopts.occ_up[i],cp->cpopts.occ_dn[i]);
    }else{
     n = 1;
     fwrite(&(cp->cpopts.occ_up[i]),sizeof(double),n,fp_dnamec);
     fwrite(&(cp->cpopts.occ_dn[i]),sizeof(double),n,fp_dnamec);
    }/*endif ibinary */

   }else{
    if(ibinary == 0){
    fprintf(fp_dnamec,"%g %g\n",(cp->cpopts.occ_up[i]-cp->cpopts.occ_dn[i]),
                                cp->cpopts.occ_dn[i]);
    }else{
     n = 1;
     occ_temp = (cp->cpopts.occ_up[i]-cp->cpopts.occ_dn[i]);
     fwrite(&occ_temp,sizeof(double),n,fp_dnamec);
     fwrite(&(cp->cpopts.occ_dn[i]),sizeof(double),n,fp_dnamec);

    }/*endif ibinary*/
   }/*endif*/
  }/*endfor*/

}/*endif:myid==0*/

/* free locally assigned memory  */
 if( (myid == 0) && (ibinary == 1)){
        cfree(c_array1);
        cfree(c_array2);  
 }

/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_kseigs_file_cp(GENERAL_DATA *general_data,CP *cp,int ipt)

/*==========================================================================*/
{/* begin routine */
/*=======================================================================*/
/*            Local variable declarations                                */

#include "../typ_defs/typ_mask.h"

 int ip,ipp,is,irecv;

 int pi_beads      = cp->cpcoeffs_info.pi_beads;
 int pi_beads_proc = cp->cpcoeffs_info.pi_beads_proc;
 int nstate_up     = cp->cpcoeffs_info.nstate_up;
 int nstate_dn     = cp->cpcoeffs_info.nstate_dn;
 int ip_start      = cp->cpcoeffs_info.pi_beads_proc_st;
 int ip_end        = cp->cpcoeffs_info.pi_beads_proc_end;
 int npara_temps   = cp->cpopts.npara_temps;
 int cp_lsda       = cp->cpopts.cp_lsda;

 double *kseig_tmp = cp->cpscr.cpscr_ovmat.state_vec1;

 int myid          = cp->communicate.myid;
 int myid_state    = cp->communicate.myid_state;
 MPI_Comm world    = cp->communicate.world;

 int iptoff        = ipt + general_data->tempering_ctrl.npara_temps_proc_off;

 FILE *fp_kseigs;
 double *kseig;
 double ks_offset_tmp;
 NAME tname;


/*==========================================================================*/
/*    settle filenames                                            */
    
  if(npara_temps>1){
    sprintf(tname,"%s.%d",general_data->filenames.ksname,iptoff);
  }else{
    strcpy(tname,general_data->filenames.ksname);
  }/*endif*/

/*==========================================================================*/
/* Open dump file                                                           */

  if(myid==0){
    fp_kseigs = cfopen(tname,"a");
  }/* endif myid */

/*==========================================================================*/
/* Write KS eigenvalues for up states                                       */

  for(ip=1;ip<=pi_beads;ip++){

    irecv = 1;
    if(ip >= ip_start && ip <= ip_end && myid_state == 0){
       ipp = (ipt-1)*pi_beads_proc + ip-ip_start+1;
       irecv=0;
       kseig          = cp->cpcoeffs_pos[ipp].ksmat_eig_up;
       ks_offset_tmp  = cp->cpcoeffs_pos[ipp].ks_offset;
       for(is=1;is<=nstate_up;is++){
         kseig_tmp[is] = kseig[is];
       }/* endfor */
       if(myid != 0) {
         Ssend(&(kseig_tmp[1]),nstate_up,MPI_DOUBLE,0,0,world);
         Ssend(&(ks_offset_tmp),1,MPI_DOUBLE,0,0,world);
       }/* endif myid_bead */
    }/* endif ip */

    if(myid == 0){
      if(irecv != 0){
        Recv(&(kseig_tmp[1]),nstate_up,MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
             world);
        Recv(&(ks_offset_tmp),1,MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,world);
      }/* endif */
      for(is=1;is<=nstate_up;is++){
        fprintf(fp_kseigs,"%d  %.6g \n",is,kseig_tmp[is]);
      }/* endfor is */
      fprintf(fp_kseigs,"ks_offset %.6g\n",ks_offset_tmp);
    }/* endif myid */

  }/* endfor ip */


/*==========================================================================*/
/* Write KS eigenvalues for dn states                                       */

 if(cp_lsda == 1){

   for(ip=1;ip<=pi_beads;ip++){
     irecv = 1;
     if(ip >= ip_start && ip <= ip_end && myid_state == 0){
        ipp = (ipt-1)*pi_beads_proc + ip-ip_start+1;
        irecv=0;
        kseig          = cp->cpcoeffs_pos[ipp].ksmat_eig_dn;
        ks_offset_tmp  = cp->cpcoeffs_pos[ipp].ks_offset;
        for(is=1;is<=nstate_dn;is++){
          kseig_tmp[is] = kseig[is];
        }/* endfor */
        if(myid != 0) {
          Ssend(&(kseig_tmp[1]),nstate_dn,MPI_DOUBLE,0,0,world);
          Ssend(&(ks_offset_tmp),1,MPI_DOUBLE,0,0,world);
        }/* endif myid_bead */
     }/* endif ip */
     if(myid == 0){
      if(irecv != 0){
        Recv(&(kseig_tmp[1]),nstate_dn,MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
             world);
        Recv(&(ks_offset_tmp),1,MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,world);
      }/* endif */
      for(is=1;is<=nstate_dn;is++){
        fprintf(fp_kseigs,"%d  %.6g \n",is,kseig_tmp[is]);
      }/* endfor is */
      fprintf(fp_kseigs,"%.6g\n",ks_offset_tmp);
    }/* endif myid */
   }/* endfor ip */

 }/* endif cp_lsda */

/*==========================================================================*/
/* Close file                                                              */

  if(myid==0){
    fflush(fp_kseigs);
    fclose(fp_kseigs);
  }/* endif */

/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_elf_file_cp(GENERAL_DATA *general_data,CP *cp,int ipt)

/*==========================================================================*/
{/* begin routine */
/*=======================================================================*/
/*            Local variable declarations                                */

#include "../typ_defs/typ_mask.h"

 int index,ka,kb,kc;
 int count;
 int nkf1,nkf2,nkf3;
 int kb_str,kb_end;
 int skc_fft_ka_proc;
 int ekc_fft_ka_proc;
 int skb_fft_ka_proc;
 int ekb_fft_ka_proc;
 int skc_fft_ka_proc_t;
 int ekc_fft_ka_proc_t;
 int skb_fft_ka_proc_t;
 int ekb_fft_ka_proc_t;
 int nfft2_proc_t;
 int skc_use;
 int iadd_c,iadd_b,kb_off,dkb;

 int nfft            =    cp->cp_para_fft_pkg3d_lg.nfft;
 int nfft_proc       =    cp->cp_para_fft_pkg3d_lg.nfft_proc;
 int nfft2           =    nfft/2;
 int nfft2_proc      =    nfft_proc/2;
 int nfft_proc_dens_cp_box;
 int nfft2_proc_dens_cp_box;
 int i;
 int iproc;
 static int iopen_flag=1;

 int itag;
 int itag1;
 int itag2;
 int itag3;
 int itag4;

 int myid             = cp->communicate.myid;
 int myid_state       = cp->communicate.myid_state;
 int np_states        = cp->communicate.np_states;
 int cp_lsda          = cp->cpopts.cp_lsda;
 int cp_ngrid_skip    = cp->cpopts.cp_ngrid_skip;
 int *kmax_cp;
 double *cp_elf_up    = cp->electronic_properties[ipt].cp_elf_up;
 double *cp_elf_dn    = cp->electronic_properties[ipt].cp_elf_dn;
 double *cp_elf_tmp   = cp->cpscr.cpscr_rho.rho_up;
 FILE *fp_elf;
 MPI_Comm world       = cp->communicate.world;
 MPI_Comm comm_states = cp->communicate.comm_states;
 
 NAME tname;
  int  npara_temps      = cp->cpopts.npara_temps;
  int iptoff = ipt + general_data->tempering_ctrl.npara_temps_proc_off;


/*==========================================================================*/
/*    O) settle filenames                                            */
    
    if(npara_temps>1){
      sprintf(tname,"%s.%d",general_data->filenames.elfname,iptoff);
    }else{
      strcpy(tname,general_data->filenames.elfname);
    }/*endif*/

/*==========================================================================*/
/* Useful constants                                                         */

 if(cp->cpopts.cp_dual_grid_opt >= 1){
   kmax_cp         = cp->cpewald.kmax_cp_dens_cp_box;
   skc_fft_ka_proc = cp->cp_para_fft_pkg3d_dens_cp_box.skc_fft_ka_proc;
   ekc_fft_ka_proc = cp->cp_para_fft_pkg3d_dens_cp_box.ekc_fft_ka_proc;
   skb_fft_ka_proc = cp->cp_para_fft_pkg3d_dens_cp_box.skb_fft_ka_proc;
   ekb_fft_ka_proc = cp->cp_para_fft_pkg3d_dens_cp_box.ekb_fft_ka_proc;
 } else {
   kmax_cp         = cp->cpewald.kmax_cp;
   skc_fft_ka_proc = cp->cp_para_fft_pkg3d_lg.skc_fft_ka_proc;
   ekc_fft_ka_proc = cp->cp_para_fft_pkg3d_lg.ekc_fft_ka_proc;
   skb_fft_ka_proc = cp->cp_para_fft_pkg3d_lg.skb_fft_ka_proc;
   ekb_fft_ka_proc = cp->cp_para_fft_pkg3d_lg.ekb_fft_ka_proc;
 } /*endif dual grid opt on */

 if(cp->cpopts.cp_dual_grid_opt >= 1){
   nfft_proc_dens_cp_box  = cp->cp_para_fft_pkg3d_dens_cp_box.nfft_proc;
   nfft2_proc_dens_cp_box = nfft_proc_dens_cp_box/2;
   nfft2_proc             = nfft2_proc_dens_cp_box;
 }/*endif cp_dual_grid_opt*/

  nkf1 = 4*(kmax_cp[1]+1);
  nkf2 = 4*(kmax_cp[2]+1);
  nkf3 = 4*(kmax_cp[3]+1);

/*==========================================================================*/
/* Check commensurability                                                   */

   if(((nkf1 % cp_ngrid_skip) != 0) || ((nkf2 % cp_ngrid_skip) != 0) ||
      ((nkf3 % cp_ngrid_skip) != 0)){
     if(myid_state==0){
       printf("@@@@@@@@@@@@@@@@@@@@-ERROR-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
       printf("The grid skip value, cp_ngrid_skip, must be commensurate\n");
       printf("with the number of points along each direction\n");
       printf("nx = %d, ny = %d, nz = %d, grid skip = %d\n",nkf1,nkf2,nkf3,cp_ngrid_skip);
       printf("@@@@@@@@@@@@@@@@@@@@-ERROR-@@@@@@@@@@@@@@@@@@@@@@@@@@@@@\n");
     }/* endif myid */
       if(np_states>1){Barrier(comm_states);}
       Finalize();
       exit(1);
   }/* endif */
 

/*==========================================================================*/
/* Open elf file                                                           */

 if(iopen_flag == 1){
   if(myid_state==0){
      fp_elf = cfopen(tname,"w");
      fprintf(fp_elf,"%d %d %d %d\n",
          nkf1,nkf2,nkf3,cp_ngrid_skip);
   }/* endif myid */
   iopen_flag=0;
 } else {
   if(myid_state==0){
      fp_elf = cfopen(tname,"a");
   }/* endif myid */
 }/* endif iopen_flag */

/*==========================================================================*/
/* Write the ELF for the up electrons                                       */

  if(np_states == 1){

    for(kc=1;kc<=nkf3;kc+=cp_ngrid_skip){
      for(kb=1;kb<=nkf2;kb+=cp_ngrid_skip){
        for(ka=1;ka<=nkf1;ka+=cp_ngrid_skip){
          i = (ka-1) + (kb-1)*nkf1 + (kc-1)*nkf1*nkf2 + 1;
          fprintf(fp_elf,"%.5e\n",cp_elf_up[i]);
        }/* endfor */
      }/* endfor */
    }/* endfor */

  } else {

    /*---------------*/
    /* output proc 0 */
    if(myid_state == 0){ 
      iadd_c = ((skc_fft_ka_proc-1) % cp_ngrid_skip);
      dkb    = nkf2-skb_fft_ka_proc+1;
      for(kc=skc_fft_ka_proc+iadd_c;kc<=ekc_fft_ka_proc;kc+=cp_ngrid_skip){
        kb_str = (kc==skc_fft_ka_proc ? skb_fft_ka_proc : 1);
        kb_end = (kc==ekc_fft_ka_proc ? ekb_fft_ka_proc : nkf2);
        kb_off = (kc==skc_fft_ka_proc ? 0 : dkb);
        if(kc>skc_fft_ka_proc+1){kb_off += (kc-skc_fft_ka_proc-1)*nkf2;}
        iadd_b = ((kb_str-1) % cp_ngrid_skip);
        for(kb=kb_str+iadd_b;kb<=kb_end;kb+=cp_ngrid_skip){
          for(ka=1;ka<=nkf1;ka+=cp_ngrid_skip){
             i = (ka-1) + (kb-kb_str+kb_off)*nkf1 + 1;
             fprintf(fp_elf,"%.5e\n",cp_elf_up[i]);
          }/* endfor */
        }/* endfor */
      }/* endfor */
    }/* endif myid_state == 0 */

    Barrier(comm_states);
    Barrier(comm_states);

    for(iproc=1;iproc<np_states;iproc++){
      itag = 10*iproc;
      itag1= itag+1;
      itag2= itag+2;
      itag3= itag+3;
      itag4= itag+4;
      /*---------------*/
      /* output proc = iproc */
      if(myid_state == iproc){
          Ssend(&nfft2_proc,1,MPI_INT,0,itag,comm_states);
          Ssend(&skc_fft_ka_proc,1,MPI_INT,0,itag1,comm_states);
          Ssend(&ekc_fft_ka_proc,1,MPI_INT,0,itag2,comm_states);
          Ssend(&skb_fft_ka_proc,1,MPI_INT,0,itag3,comm_states);
          Ssend(&ekb_fft_ka_proc,1,MPI_INT,0,itag4,comm_states);
          Ssend(&cp_elf_up[1],nfft2_proc,MPI_DOUBLE,0,0,comm_states);
      } /* endif myid_state == iproc */
      if(myid_state == 0){
          nfft2_proc_t=0;
          Recv(&nfft2_proc_t,1,MPI_INT,MPI_ANY_SOURCE,itag,comm_states);
          Recv(&skc_fft_ka_proc_t,1,MPI_INT,MPI_ANY_SOURCE,itag1,comm_states);
          Recv(&ekc_fft_ka_proc_t,1,MPI_INT,MPI_ANY_SOURCE,itag2,comm_states);
          Recv(&skb_fft_ka_proc_t,1,MPI_INT,MPI_ANY_SOURCE,itag3,comm_states);
          Recv(&ekb_fft_ka_proc_t,1,MPI_INT,MPI_ANY_SOURCE,itag4,comm_states);
          Recv(&cp_elf_tmp[1],nfft2_proc_t,MPI_DOUBLE,MPI_ANY_SOURCE,0,comm_states);
      }/* endif myid_state == 0 */
      Barrier(comm_states);
      Barrier(comm_states);

      if(myid_state == 0){
         iadd_c = ((skc_fft_ka_proc_t-1) % cp_ngrid_skip);
         dkb    = nkf2-skb_fft_ka_proc_t+1;
         for(kc=skc_fft_ka_proc_t+iadd_c;kc<=ekc_fft_ka_proc_t;kc+=cp_ngrid_skip){
           kb_str = (kc==skc_fft_ka_proc_t ? skb_fft_ka_proc_t : 1);
           kb_end = (kc==ekc_fft_ka_proc_t ? ekb_fft_ka_proc_t : nkf2);
           iadd_b = ((kb_str-1) % cp_ngrid_skip);
           kb_off = (kc==skc_fft_ka_proc_t ? 0 : dkb);
           if(kc>skc_fft_ka_proc_t+1){kb_off += (kc-skc_fft_ka_proc_t-1)*nkf2;}
           for(kb=kb_str+iadd_b;kb<=kb_end;kb+=cp_ngrid_skip){
             for(ka=1;ka<=nkf1;ka+=cp_ngrid_skip){
               i = (ka-1) + (kb-kb_str+kb_off)*nkf1 + 1;
               fprintf(fp_elf,"%.5e\n",cp_elf_tmp[i]);
             }/* endfor */
           }/* endfor */
         }/* endfor */
      }/* endif myid_state == 0 */
      Barrier(comm_states);
      Barrier(comm_states);

    }/* endfor iproc */

  }/* endif np_states */


/*==========================================================================*/
/* Write the ELF for the down electrons if necessary                        */

 if(cp_lsda == 1){
  if(np_states == 1){
    for(kc=1;kc<=nkf3;kc+=cp_ngrid_skip){
      for(kb=1;kb<=nkf2;kb+=cp_ngrid_skip){
        for(ka=1;ka<=nkf1;ka+=cp_ngrid_skip){
          i = (ka-1) + (kb-1)*nkf1 + (kc-1)*nkf1*nkf2 + 1;
          fprintf(fp_elf,"%.5e\n",cp_elf_dn[i]);
        }/* endfor */
     }/* endfor */
    }/* endfor */

   } else {

    for(iproc=0;iproc<np_states;iproc++){
      if(iproc==0){
        if(myid_state == 0){ 
           for(kc=skc_fft_ka_proc;kc<=ekc_fft_ka_proc;kc+=cp_ngrid_skip){
            kb_str = (kc==skc_fft_ka_proc ? skb_fft_ka_proc : 1);
            kb_end = (kc==ekc_fft_ka_proc ? ekb_fft_ka_proc : nkf2);
            for(kb=kb_str;kb<=kb_end;kb+=cp_ngrid_skip){
             for(ka=1;ka<=nkf1;ka+=cp_ngrid_skip){
              i = (ka-1) + (kb-kb_str)*nkf1 
                         + (kc-skc_fft_ka_proc)*nkf1*(kb_end-kb_str+1) + 1;
              fprintf(fp_elf,"%.5e\n",cp_elf_dn[i]);
             }/* endfor */
            }/* endfor */
           }/* endfor */
        }/* endif myid_state == 0 */
      }/* endif iproc == 0 */
      if(np_states>1){Barrier(comm_states);}
      if(iproc != 0){
	if(myid_state == iproc){
          Ssend(&cp_elf_dn[1],nfft2_proc,MPI_DOUBLE,0,0,comm_states);
          Ssend(&skc_fft_ka_proc,1,MPI_INT,0,1,comm_states);
          Ssend(&ekc_fft_ka_proc,1,MPI_INT,0,2,comm_states);
          Ssend(&skb_fft_ka_proc,1,MPI_INT,0,3,comm_states);
          Ssend(&ekb_fft_ka_proc,1,MPI_INT,0,4,comm_states);
        } /* endif myid_state == iproc */
        if(myid_state == 0){
          Recv(&cp_elf_tmp[1],nfft2_proc,MPI_DOUBLE,MPI_ANY_SOURCE,0,comm_states);
          Recv(&skc_fft_ka_proc,1,MPI_INT,MPI_ANY_SOURCE,1,comm_states);
          Recv(&ekc_fft_ka_proc,1,MPI_INT,MPI_ANY_SOURCE,2,comm_states);
          Recv(&skb_fft_ka_proc,1,MPI_INT,MPI_ANY_SOURCE,3,comm_states);
          Recv(&ekb_fft_ka_proc,1,MPI_INT,MPI_ANY_SOURCE,4,comm_states);
           skc_use = kc;
           for(kc=skc_use;kc<=ekc_fft_ka_proc;kc+=cp_ngrid_skip){
            kb_str = (kc==skc_use ? skb_fft_ka_proc : 1);
            kb_end = (kc==ekc_fft_ka_proc ? ekb_fft_ka_proc : nkf2);
            for(kb=kb_str;kb<=kb_end;kb+=cp_ngrid_skip){
             for(ka=1;ka<=nkf1;ka+=cp_ngrid_skip){
              i = (ka-1) + (kb-kb_str)*nkf1 
                         + (kc-skc_fft_ka_proc)*nkf1*(kb_end-kb_str+1) + 1;
              fprintf(fp_elf,"%.5e\n",cp_elf_tmp[i]);
             }/* endfor */
            }/* endfor */
           }/* endfor */
        }/* endif myid_state == 0 */
      }/* endif iproc != 0 */
      if(np_states>1){Barrier(comm_states);}
   }/* endfor iproc */
  }/* endif np_states */
 }/* endif cp_lsda */

/*==========================================================================*/
/* Close the file                                                           */

  if(myid_state==0){fclose(fp_elf);}



/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_dump_coef_cp(FILE *fp_dnamec,CP *cp,CLASS *class,int ibinary,int ipt)

/*==========================================================================*/

{/* begin routine */
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"

 int  ncoef  = cp->cpcoeffs_info.ncoef;
 int  istate_up_st  = cp->cpcoeffs_info.istate_up_st;
 int  istate_up_end = cp->cpcoeffs_info.istate_up_end;
 int  nstate_up     = cp->cpcoeffs_info.nstate_up;
 int  nstate_up_proc= cp->cpcoeffs_info.nstate_up_proc;

 int  istate_dn_st  = cp->cpcoeffs_info.istate_dn_st;
 int  istate_dn_end = cp->cpcoeffs_info.istate_dn_end;
 int  nstate_dn     = cp->cpcoeffs_info.nstate_dn;
 int  nstate_dn_proc= cp->cpcoeffs_info.nstate_dn_proc;
 int cp_lsda        =cp->cpopts.cp_lsda;
 int nrecv,isoff;
 int is,igo;
 int i,n; 
 float cre_dum,cim_dum;

 char *c_array1,*c_array2;  /*for binary write */
 int csize = MAXWORD; 

 MPI_Status stat;

/* Local pointers */
 double *cre_up_tmp = cp->cpscr.cpscr_wave.cre_up;
 double *cim_up_tmp = cp->cpscr.cpscr_wave.cim_up;
 double *cre_dn_tmp = cp->cpscr.cpscr_wave.cre_dn;
 double *cim_dn_tmp = cp->cpscr.cpscr_wave.cim_dn;

 int myid       = class->communicate.myid;
 int myid_m     = class->communicate_m.myid;
 int np_states  = class->communicate.np_states;
 int nproc      = class->communicate.np;
 MPI_Comm world = class->communicate.world;

 NAME tname;
  int  npara_temps      = cp->cpopts.npara_temps;

/*=======================================================================*/
  if( (myid == 0) && (ibinary == 1)){
    c_array1 = (char *) cmalloc(csize*sizeof(char ));
    c_array2 = (char *) cmalloc(csize*sizeof(char ));
  /* initialize array */
    for(i=0; i< csize-1; i++){
     c_array1[i] = ' ';
     c_array2[i] = ' ';
    }
     c_array1[csize -1] = '\0';
     c_array2[csize -1] = '\0';

  }/*endif */

/*==========================================================================*/
/* Write the coefficients                                                  */

/*-------------------------------------------------------------------------*/
/* Up states                                                               */
  printf("ipt: %d, myid: %d\n",ipt,myid_m);
   if(myid==0){
     if(ibinary == 0){
       fprintf(fp_dnamec,"Up_State_Real         Up_State_Imag\n");
     }else{
       strcpy(c_array1,"Up_State_Real ");
       strcpy(c_array2,"Up_State_Imag ");
       fwrite(c_array1,sizeof(char),csize,fp_dnamec);
       fwrite(c_array2,sizeof(char),csize,fp_dnamec);
     }/*endif ibinary */
   }/*endif myid*/
   if(nproc>1){Barrier(world);}
     for(is=1;is<=nstate_up;is++){
       igo=0;
       if((is>=istate_up_st) && (is<=istate_up_end)){
          isoff=(is-istate_up_st)*ncoef;
          for(i=1;i<=ncoef;i++){
            cre_up_tmp[i] = cp->cpcoeffs_pos[ipt].cre_up[(i+isoff)];
            cim_up_tmp[i] = cp->cpcoeffs_pos[ipt].cim_up[(i+isoff)];
          }/* endfor */
          igo = 1;
          if(myid!=0){
            Ssend(&(cre_up_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
            Ssend(&(cim_up_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
          }/*endif*/
       }/* endif */
       if(myid==0&&igo==0){
         Recv(&(cre_up_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
         Recv(&(cim_up_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
        }/* endif */
        if(myid==0){
         n = 1;
         for(i=1;i<=ncoef;i++){
         if(ibinary == 0){
          fprintf(fp_dnamec,"%.8g %.8g\n",cre_up_tmp[i],cim_up_tmp[i]);
         }else{
           cre_dum = (float)cre_up_tmp[i];
           cim_dum = (float)cim_up_tmp[i];
           fwrite(&(cre_dum),sizeof(float),n,fp_dnamec);
           fwrite(&(cim_dum),sizeof(float),n,fp_dnamec);
         }/*endif ibinary */
         }/*endfor: write*/
        }/* endif myid */
        if(nproc>1){Barrier(world);}
     }/*endfor:states*/

/*-------------------------------------------------------------------------*/
/* Dn states                                                               */

  if(cp->cpopts.cp_lsda==1){
   if(myid==0){
     if(ibinary == 0){
      fprintf(fp_dnamec,"Dn_State_Real         Dn_State_Imag\n");
     }else{
       strcpy(c_array1,"Dn_State_Real ");
       strcpy(c_array2,"Dn_State_Imag ");
       fwrite(c_array1,sizeof(char),csize,fp_dnamec);
       fwrite(c_array2,sizeof(char),csize,fp_dnamec);
     }/*endif ibinary */
   }/*endif myid*/
   if(nproc>1){Barrier(world);}
     for(is=1;is<=nstate_dn;is++){
       igo=0;
       if((is>=istate_dn_st) && (is<=istate_dn_end)){
          isoff=(is-istate_dn_st)*ncoef;
          for(i=1;i<=ncoef;i++){
            cre_dn_tmp[i] = cp->cpcoeffs_pos[ipt].cre_dn[(i+isoff)];
            cim_dn_tmp[i] = cp->cpcoeffs_pos[ipt].cim_dn[(i+isoff)];
          }/* endfor */
          igo = 1;
          if(myid!=0){
            Ssend(&(cre_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
            Ssend(&(cim_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
          }/*endif*/
       }/* endif */
       if(myid==0&&igo==0){
         Recv(&(cre_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
         Recv(&(cim_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
        }/* endif */
        if(myid==0){
          n = 1;
         for(i=1;i<=ncoef;i++){
        if(ibinary == 0){
          fprintf(fp_dnamec,"%.8g %.8g\n",(float)cre_dn_tmp[i],(float)cim_dn_tmp[i]);
         }else{
           cre_dum = (float) cre_dn_tmp[i];
           cim_dum = (float) cim_dn_tmp[i];
           fwrite(&(cre_dum),sizeof(float),n,fp_dnamec);
           fwrite(&(cim_dum),sizeof(float),n,fp_dnamec);
         }/*endif ibinary */
         }/*endfor: write*/
        }/* endif myid */
        if(nproc>1){Barrier(world);}
     }/*endfor:states*/
  }/*endif:lsda*/

/* free locally assigned memory */
  if( (myid == 0) && (ibinary == 1)){
        cfree(c_array1);
        cfree(c_array2); 
  }/*endif */

/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/




/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_dump_vcoef_cp(FILE *fp_dnamec,CP *cp,CLASS *class,
                         GENERAL_DATA *general_data,int ibinary,int ipt)

/*==========================================================================*/

{/* begin routine */
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"

 int  ncoef  = cp->cpcoeffs_info.ncoef;
 int  istate_up_st  = cp->cpcoeffs_info.istate_up_st;
 int  istate_up_end = cp->cpcoeffs_info.istate_up_end;
 int  nstate_up     = cp->cpcoeffs_info.nstate_up;
 int  nstate_up_proc= cp->cpcoeffs_info.nstate_up_proc;

 int  istate_dn_st  = cp->cpcoeffs_info.istate_dn_st;
 int  istate_dn_end = cp->cpcoeffs_info.istate_dn_end;
 int  nstate_dn     = cp->cpcoeffs_info.nstate_dn;
 int  nstate_dn_proc= cp->cpcoeffs_info.nstate_dn_proc;
 int cp_lsda        =cp->cpopts.cp_lsda;
 int nrecv,isoff;
 int is,igo;
 int i,n; 
 float cre_dum,cim_dum; 

 MPI_Status stat;

/* Local pointers */
 double *cre_up_tmp = cp->cpscr.cpscr_wave.cre_up;
 double *cim_up_tmp = cp->cpscr.cpscr_wave.cim_up;
 double *cre_dn_tmp = cp->cpscr.cpscr_wave.cre_dn;
 double *cim_dn_tmp = cp->cpscr.cpscr_wave.cim_dn;

 int myid       = class->communicate.myid;
 int np_states  = class->communicate.np_states;
 int nproc      = class->communicate.np;
 MPI_Comm world = class->communicate.world;

 char *c_array1,*c_array2;
 int csize = MAXWORD;

 NAME tname;

  if( (myid == 0) && (ibinary == 1)){
    c_array1 = (char *) cmalloc(csize*sizeof(char ));
    c_array2 = (char *) cmalloc(csize*sizeof(char ));
  /* initialize array */
   for(i=0 ; i< csize-1; i++){
    c_array1[i] = ' ';
    c_array2[i] = ' ';
   }
    c_array1[csize-1] = '\0';
    c_array2[csize-1] = '\0';
  }/*endif*/

/*==========================================================================*/
/* Write the coefficient velocities                                         */

/*-------------------------------------------------------------------------*/
/* Up states                                                               */

 if((general_data->simopts.cp+general_data->simopts.cp_wave)==1){

   if(myid==0){
     if(ibinary == 0){
     fprintf(fp_dnamec,"V_Up_State_Real         V_Up_State_Imag\n");
     }else{
       strcpy(c_array1,"V_UP_State_Real");
       strcpy(c_array2,"V_UP_State_Imag");
       fwrite(c_array1,sizeof(char),csize,fp_dnamec);
       fwrite(c_array2,sizeof(char),csize,fp_dnamec);
     }/*endif ibinary */
   }/*endif myid*/
   if(nproc>1){Barrier(world);}
     for(is=1;is<=nstate_up;is++){
       igo=0;
       if((is>=istate_up_st) && (is<=istate_up_end)){
          isoff=(is-istate_up_st)*ncoef;
          for(i=1;i<=ncoef;i++){
            cre_up_tmp[i] = cp->cpcoeffs_pos[ipt].vcre_up[(i+isoff)];
            cim_up_tmp[i] = cp->cpcoeffs_pos[ipt].vcim_up[(i+isoff)];
          }/* endfor */
          igo = 1;
          if(myid!=0){
            Ssend(&(cre_up_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
            Ssend(&(cim_up_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
          }/*endif*/
       }/* endif */
       if(myid==0&&igo==0){
         Recv(&(cre_up_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
         Recv(&(cim_up_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
        }/* endif */
        if(myid==0){
         for(i=1;i<=ncoef;i++){
        if(ibinary == 0){
          fprintf(fp_dnamec,"%.8g %.8g\n",cre_up_tmp[i],cim_up_tmp[i]);
        }else{
          n = 1;
         cre_dum = (float) cre_up_tmp[i];
         cim_dum = (float) cim_up_tmp[i];
          fwrite(&(cre_dum),sizeof(float),n,fp_dnamec);
          fwrite(&(cim_dum),sizeof(float),n,fp_dnamec);
        }/*endif ibinary*/
         }/*endfor: write*/
        }/* endif myid */
        if(nproc>1){Barrier(world);}
     }/*endfor:states*/

/*-------------------------------------------------------------------------*/
/* Dn states                                                               */

  if(cp->cpopts.cp_lsda==1){
    if(myid==0){
     if(ibinary == 0){
     fprintf(fp_dnamec,"V_Dn_State_Real         V_Dn_State_Imag\n");
     }else{
       strcpy(c_array1,"V_Dn_State_Real");
       strcpy(c_array2,"V_Dn_State_Imag");
       fwrite(c_array1,sizeof(char),csize,fp_dnamec);
       fwrite(c_array2,sizeof(char),csize,fp_dnamec);
     }/*endif ibinary*/
    }/*endif myid*/
    if(nproc>1){Barrier(world);}
     for(is=1;is<=nstate_dn;is++){
       igo=0;
       if((is>=istate_dn_st) && (is<=istate_dn_end)){
          isoff=(is-istate_dn_st)*ncoef;
          for(i=1;i<=ncoef;i++){
            cre_dn_tmp[i] = cp->cpcoeffs_pos[ipt].vcre_dn[(i+isoff)];
            cim_dn_tmp[i] = cp->cpcoeffs_pos[ipt].vcim_dn[(i+isoff)];
          }/* endfor */
          igo = 1;
          if(myid!=0){
            Ssend(&(cre_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
            Ssend(&(cim_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,0,0,world);
          }/*endif*/
       }/* endif */
       if(myid==0&&igo==0){
         Recv(&(cre_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
         Recv(&(cim_dn_tmp[0]),(ncoef+1),MPI_DOUBLE,MPI_ANY_SOURCE,MPI_ANY_TAG,
               world);
        }/* endif */
        if(myid==0){
         for(i=1;i<=ncoef;i++){
         if(ibinary == 0){
          fprintf(fp_dnamec,"%.8g %.8g\n",cre_dn_tmp[i],cim_dn_tmp[i]);
         }else{
           n = 1;
           cre_dum = (float) cre_dn_tmp[i];
           cim_dum = (float) cim_dn_tmp[i];
           fwrite(&(cre_dum),sizeof(float),n,fp_dnamec);
           fwrite(&(cim_dum),sizeof(float),n,fp_dnamec);
         }/*endif ibinary*/
         }/*endfor: write*/
        }/* endif myid */
        if(nproc>1){Barrier(world);}
     }/*endfor:states*/
  }/*endif:lsda*/

 }/*endif:write the velocities*/

/* free locally assigned memory */
  if( (myid == 0) && (ibinary == 1)){
     c_array1 = (char *) cmalloc(csize*sizeof(char ));
     c_array2 = (char *) cmalloc(csize*sizeof(char ));  
  }/*endif*/

/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/


/*==========================================================================*/
/*cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc*/
/*==========================================================================*/

void write_dump_extended_cp(FILE *fp_dnamec,CP *cp,CLASS *class,
                            GENERAL_DATA *general_data,int ibinary,int ipt)

/*==========================================================================*/

{/* begin routine */
/*=======================================================================*/
/*            Local variable declarations                                */
#include "../typ_defs/typ_mask.h"

 int i,j,ncoef_up,ncoef_dn;
 int ichain,inhc ;
 int pi_beads = class->clatoms_info.pi_beads;
 int iproc,ioff_re,ioff_im;
 int nstate_proc_now;

 int  ncoef  = cp->cpcoeffs_info.ncoef;

 int  nstate_up     = cp->cpcoeffs_info.nstate_up;
 int  nstate_up_proc= cp->cpcoeffs_info.nstate_up_proc;
 int  nstate_dn     = cp->cpcoeffs_info.nstate_dn;
 int  nstate_dn_proc= cp->cpcoeffs_info.nstate_dn_proc;

 int  num_c_nhc_proc=cp->cptherm_info.num_c_nhc_proc;
 int  num_c_nhc     =cp->cptherm_info.num_c_nhc;
 int  len_c_nhc     =cp->cptherm_info.len_c_nhc;
 int cp_lsda        =cp->cpopts.cp_lsda;
 int nrecv,isoff;
 int is,igo;

 float cre_dum,cim_dum;
 
 MPI_Status stat;

/* Local pointers */
 double *cre_up_tmp = cp->cpscr.cpscr_wave.cre_up;
 double *cim_up_tmp = cp->cpscr.cpscr_wave.cim_up;
 double *cre_dn_tmp = cp->cpscr.cpscr_wave.cre_dn;
 double *cim_dn_tmp = cp->cpscr.cpscr_wave.cim_dn;
 int myid       = class->communicate.myid;
 int np_states  = class->communicate.np_states;
 int nproc      = class->communicate.np;
 MPI_Comm world = class->communicate.world;

 char *c_array1,*c_array2;
 int csize = MAXWORD;
 int n;

 NAME tname;

  if( (myid == 0) && (ibinary == 1)){
     c_array1 = (char *) cmalloc(csize*sizeof(char ));
     c_array2 = (char *) cmalloc(csize*sizeof(char ));
  for(i=0; i< csize -1; i++){
     c_array1[i] = ' ';
     c_array2[i] = ' ';
  }  
     c_array1[csize -1] = '\0';
     c_array2[csize -1] = '\0';
  }/*endif*/

/*==========================================================================*/
/* Write the extended class stuff                                         */

  if((general_data->simopts.cp+general_data->simopts.cp_wave)==1){
   if(myid==0){
    if(ibinary == 0){
    fprintf(fp_dnamec,"Number of chains    Length of chains \n");
    fprintf(fp_dnamec,"%d %d\n",cp->cptherm_info.num_c_nhc,
                                cp->cptherm_info.len_c_nhc);
    fprintf(fp_dnamec,"Chain velocities\n");
    }else{
     strcpy(c_array1,"Number of chains ");
     strcpy(c_array2,"Length of chains ");
     fwrite(c_array1,sizeof(char),csize,fp_dnamec);
     fwrite(c_array2,sizeof(char),csize,fp_dnamec);
       n = 1;
     fwrite(&(cp->cptherm_info.num_c_nhc),sizeof(int),n,fp_dnamec);
     fwrite(&(cp->cptherm_info.len_c_nhc),sizeof(int),n,fp_dnamec);
     strcpy(c_array1,"Chain velocities ");
     fwrite(c_array1,sizeof(char),csize,fp_dnamec);
   }/*endif ibinary */
   }/* endif : myid==0 */

   for(ichain=1;ichain<=len_c_nhc;ichain++){

     if(cp->cptherm_info.istate_nhc_opt==4){
       for(iproc=0;iproc<np_states;iproc++){
         nstate_proc_now=0;
         if(myid==iproc){         
           if(myid!=0){Ssend(&(nstate_up_proc),1,MPI_INT,0,0,world);}
           nstate_proc_now=nstate_up_proc;
        }/*endif*/
         if(myid==0&&iproc!=0){         
           Recv(&(nstate_proc_now),1,MPI_INT,MPI_ANY_SOURCE,MPI_ANY_TAG,world);
        }/*endif*/
        for(is=1;is<=nstate_proc_now;is++){
           if(myid==iproc){
             ioff_re = (is-1)*ncoef;
             ioff_im = (nstate_proc_now+is-1)*ncoef;
             for(inhc=1;inhc<=ncoef;inhc++){
               cre_up_tmp[inhc] = 
                          cp->cptherm_pos[ipt].vc_nhc[ichain][inhc+ioff_re];
             }/* endfor */
             for(inhc=1;inhc<=ncoef;inhc++){
               cre_up_tmp[inhc+ncoef] = 
                           cp->cptherm_pos[ipt].vc_nhc[ichain][inhc+ioff_im];
             }/* endfor */
             if(myid!=0){
               Ssend(&(cre_up_tmp[0]),(2*ncoef+1),MPI_DOUBLE,0,0,world);
             } /* endif */
           }/* endif myid==iproc */
           if(myid==0 && iproc != 0){
             Recv(&(cre_up_tmp[0]),(2*ncoef+1),MPI_DOUBLE,
                                        MPI_ANY_SOURCE,MPI_ANY_TAG,world);
           }/* endif */
           if(myid==0){
             for(inhc=1;inhc<=2*ncoef;inhc++){
	      if(ibinary == 0){
               fprintf(fp_dnamec,"%.8g\n",cre_up_tmp[inhc]);
              }else{
               n = 1;
               cre_dum = (float) cre_up_tmp[inhc];
               fwrite(&(cre_dum),sizeof(float),n,fp_dnamec);  
              }/*endif ibinary */
             }/*endfor*/
           }/* endif */
        }/*endfor : is*/
         if(cp_lsda==1){
           nstate_proc_now=0;
           if(myid==iproc){         
             if(myid!=0){Ssend(&(nstate_dn_proc),1,MPI_INT,0,0,world);}
             nstate_proc_now=nstate_dn_proc;
           }/*endif*/
           if(myid==0&&iproc!=0){         
             Recv(&(nstate_proc_now),1,MPI_INT,MPI_ANY_SOURCE,MPI_ANY_TAG,
                  world);
           }/*endif*/
           for(is=1;is<=nstate_proc_now;is++){
             if(myid==iproc){
               ioff_re = (is-1+nstate_up_proc*2)*ncoef;
               ioff_im = (nstate_proc_now+is-1+nstate_up_proc*2)*ncoef;
               for(inhc=1;inhc<=ncoef;inhc++){
                 cre_up_tmp[inhc] = 
                     cp->cptherm_pos[ipt].vc_nhc[ichain][inhc+ioff_re];
               }/* endfor */
               for(inhc=1;inhc<=ncoef;inhc++){
                 cre_up_tmp[inhc+ncoef] = 
                           cp->cptherm_pos[ipt].vc_nhc[ichain][inhc+ioff_im];
               }/* endfor */
               if(myid!=0){
                 Ssend(&(cre_up_tmp[0]),(2*ncoef+1),MPI_DOUBLE,0,0,world);
               } /* endif */
             }/* endif myid==iproc */
             if(myid==0 && iproc != 0){
               Recv(&(cre_up_tmp[0]),(2*ncoef+1),MPI_DOUBLE,
                                          MPI_ANY_SOURCE,MPI_ANY_TAG,world);
             }/* endif */
             if(myid==0){
               for(inhc=1;inhc<=2*ncoef;inhc++){
                if(ibinary == 0){
                 fprintf(fp_dnamec,"%.8g\n",cre_up_tmp[inhc]);
                }else{
                 n = 1;
                 cre_dum = (float) cre_up_tmp[inhc];
                 fwrite(&(cre_dum),sizeof(float),n,fp_dnamec);
                }/*endif ibinary*/
               }/*endfor*/
             }/* endif */
           }/*endfor : is*/
         }/*endif : lsda*/
         if(nproc>1){Barrier(world);}
       }/* endfor : iproc*/
     }/*endif:istate_nhc_opt*/

     if(cp->cptherm_info.istate_nhc_opt<=3&&myid==0){
       for(inhc=1;inhc<=num_c_nhc;inhc++){
	 if(ibinary == 0){
          fprintf(fp_dnamec,"%.8g\n",cp->cptherm_pos[ipt].vc_nhc[ichain][inhc]);
         }else{
          n = 1;
          cre_dum = (float) cp->cptherm_pos[ipt].vc_nhc[ichain][inhc];
          fwrite(&(cre_dum),sizeof(float),n,fp_dnamec);
         }/*endif ibinary*/
       }/*endfor*/
     }/*endif:istate_nhc_opt*/

   }/*endfor:ichain*/

  }/*endif:write extended*/

/* free locally assigned memory */
  if( (myid == 0) && (ibinary == 1)){
     cfree(c_array1);
     cfree(c_array2);  
  }/*endif*/

/*==========================================================================*/
 }/* end routine */
/*==========================================================================*/



